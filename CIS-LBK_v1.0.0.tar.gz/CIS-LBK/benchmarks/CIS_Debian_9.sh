#!/bin/bash
##################################################
# Platform Remediation Script for Debian 9       #
# This Remediation script is for                 #
# CIS Debian Linux 9 Benchmark v1.0.0            #
# Written by Eric Pinnell                        #
# for the Center for Internet Security (CIS)     #
# This script is the property of CIS             #
################################################## 

####################
# Global Variables #
####################

GCFL=/boot/grub/grub.cfg
# OSN=$(egrep "^\s*ID=\S+$" /etc/os-release | cut -d= -f2 | sed "s/\"//g")
# OSV=$(egrep "^\s*VERSION_ID=\S+\$" /etc/os-release | cut -d= -f2 | sed "s/\"//g")
# OSP=$OSN$OSV

###########################
# End of Global Variables #
###########################

#######################################################
# Start of functions to preform Benchmark Remediation #
#######################################################

# 1.1.1.1 Ensure mounting of freevxfs filesystems is disabled
# Scored, Level 1, Server and Workstation
R1.1.1.1()
{
	RN=1.1.1.1
	RNA="Ensure mounting of freevxfs filesystems is disabled"
	. $FDIR/RF00097.sh
	RF00097
}
# End of Ensure mounting of freevxfs filesystems is disabled

# 1.1.1.2 Ensure mounting of jffs2 filesystems is disabled
# Scored, Level 1, Server and Workstation
R1.1.1.2()
{
	RN=1.1.1.2
	RNA="Ensure mounting of jffs2 filesystems is disabled"
	. $FDIR/RF00098.sh
	RF00098
}
# End of Ensure mounting of jffs2 filesystems is disabled

# 1.1.1.3 Ensure mounting of hfs filesystems is disabled
# Scored, Level 1, Server and Workstation
R1.1.1.3()
{
	RN=1.1.1.3
	RNA="Ensure mounting of hfs filesystems is disabled"
	. $FDIR/RF00099.sh
	RF00099
}
# End of Ensure mounting of hfs filesystems is disabled

# 1.1.1.4 Ensure mounting of hfsplus filesystems is disabled
# Scored, Level 1, Server and Workstation
R1.1.1.4()
{
	RN=1.1.1.4
	RNA="Ensure mounting of hfsplus filesystems is disabled"
	. $FDIR/RF00100.sh
	RF00100
}
# End of Ensure mounting of hfsplus filesystems is disabled

# 1.1.1.5 Ensure mounting of udf filesystems is disabled
# Scored, Level 1, Server and Workstation
R1.1.1.5()
{
	RN=1.1.1.5
	RNA="Ensure mounting of udf filesystems is disabled"
	. $FDIR/RF00101.sh
	RF00101
}
# End of Ensure mounting of udf filesystems is disabled

# 1.1.2 Ensure /tmp is configured
# Scored, Level 1, Server and Workstation
R1.1.2()
{
	RN=1.1.2
	RNA="Ensure /tmp is configured"
	. $FDIR/RF00102.sh
	RF00102
}
# End of Ensure /tmp is configured

# 1.1.3 Ensure nodev option set on /tmp partition
# Scored, Level 1, Server and Workstation
R1.1.3()
{
	RN=1.1.3
	RNA="Ensure nodev option set on /tmp partition"
	. $FDIR/RF00103.sh
	RF00103
}
# End of 1.1.3 Ensure nodev option set on /tmp partition

# 1.1.4 Ensure nosuid option set on /tmp partition
# Scored, Level 1, Server and Workstation
R1.1.4()
{
	RN=1.1.4
	RNA="Ensure nosuid option set on /tmp partition"
	. $FDIR/RF00104.sh
	RF00104
}
# End of 1.1.4 Ensure nosuid option set on /tmp partition

# 1.1.5 Ensure nosuid option set on /tmp partition
# Scored, Level 1, Server and Workstation
R1.1.5()
{
	RN=1.1.5
	RNA="Ensure nosuid option set on /tmp partition"
	. $FDIR/RF00105.sh
	RF00105
}
# End of 1.1.5 Ensure nosuid option set on /tmp partition

# 1.1.6 Ensure separate partition exists for /var
# Scored, Level 2, Server and Workstation
R1.1.6()
{
	RN=1.1.6
	RNA="Ensure separate partition exists for /var"
	. $FDIR/RF00106.sh
	RF00106
}
# End of 1.1.6 Ensure separate partition exists for /var

# 1.1.7 Ensure separate partition exists for /var/tmp
# Scored, Level 2, Server and Workstation
R1.1.7()
{
	RN=1.1.7
	RNA="Ensure separate partition exists for /var/tmp"
	. $FDIR/RF00107.sh
	RF00107
}
# End of 1.1.7 Ensure separate partition exists for /var/tmp

# 1.1.8 Ensure nodev option set on /var/tmp partition
# Scored, Level 1, Server and Workstation
R1.1.8()
{
	RN=1.1.8
	RNA="Ensure nodev option set on /var/tmp partition"
	. $FDIR/RF00108.sh
	RF00108
}
# End of 1.1.8 Ensure nodev option set on /var/tmp partition

# 1.1.9 Ensure nosuid option set on /var/tmp partition
# Scored, Level 1, Server and Workstation
R1.1.9()
{
	RN=1.1.9
	RNA="Ensure nosuid option set on /var/tmp partition"
	. $FDIR/RF00109.sh
	RF00109
}
# End of 1.1.9 Ensure nosuid option set on /var/tmp partition

# 1.1.10 Ensure noexec option set on /var/tmp partition
# Scored, Level 1, Server and Workstation
R1.1.10()
{
	RN=1.1.10
	RNA="Ensure noexec option set on /var/tmp partition"
	. $FDIR/RF00110.sh
	RF00110
}
# End of 1.1.10 Ensure nosuid option set on /var/tmp partition

# 1.1.11 Ensure separate partition exists for /var/log
# Scored, Level 2, Server and Workstation
R1.1.11()
{
	RN=1.1.11
	RNA="Ensure separate partition exists for /var/log"
	. $FDIR/RF00111.sh
	RF00111
}
# End of 1.1.11 Ensure separate partition exists for /var/log

# 1.1.12 Ensure separate partition exists for /var/log/audit
# Scored, Level 2, Server and Workstation
R1.1.12()
{
	RN=1.1.12
	RNA="Ensure separate partition exists for /var/log/audit"
	. $FDIR/RF00112.sh
	RF00112
}
# End of 1.1.12 Ensure separate partition exists for /var/log/audit

# 1.1.13 Ensure separate partition exists for /home
# Scored, Level 2, Server and Workstation
R1.1.13()
{
	RN=1.1.13
	RNA="Ensure separate partition exists for /home"
	. $FDIR/RF00113.sh
	RF00113
}
# End of 1.1.13 Ensure separate partition exists for /home

# 1.1.14 Ensure nodev option set on /home partition
# Scored, Level 1, Server and Workstation
R1.1.14()
{
	RN=1.1.14
	RNA="Ensure nodev option set on /home partition"
	. $FDIR/RF00114.sh
	RF00114
}
# End of 1.1.14 Ensure nodev option set on /home partition

# 1.1.15 Ensure nodev option set on /dev/shm partition
# Scored, Level 1, Server and Workstation
R1.1.15()
{
	RN=1.1.15
	RNA="Ensure nodev option set on /dev/shm partition"
	. $FDIR/RF00115.sh
	RF00115
}
# End of 1.1.15 Ensure nodev option set on /dev/shm partition

# 1.1.16 Ensure nosuid option set on /dev/shm partition
# Scored, Level 1, Server and Workstation
R1.1.16()
{
	RN=1.1.16
	RNA="Ensure nosuid option set on /dev/shm partition"
	. $FDIR/RF00116.sh
	RF00116
}
# End of 1.1.16 Ensure nosuid option set on /dev/shm partition

# 1.1.17 Ensure noexec option set on /dev/shm partition
# Scored, Level 1, Server and Workstation
R1.1.17()
{
	RN=1.1.17
	RNA="Ensure noexec option set on /dev/shm partition"
	. $FDIR/RF00117.sh
	RF00117
}
# End of 1.1.17 Ensure noexec option set on /dev/shm partition

# 1.1.18 Ensure nodev option set on removable media partitions
# Not Scored
R1.1.18()
{
	RN=1.1.18
	RNA="Ensure nodev option set on removable media partitions"
	NSR
}
# End of 1.1.18 Ensure nodev option set on removable media partitions

# 1.1.19 Ensure nosuid option set on removable media partitions
# Not Scored
R1.1.19()
{
	RN=1.1.19
	RNA="Ensure nosuid option set on removable media partitions"
	NSR
}
# End of 1.1.19 Ensure nosuid option set on removable media partitions

# 1.1.20 Ensure noexec option set on removable media partitions
# Not Scored
R1.1.20()
{
	RN=1.1.20
	RNA="Ensure noexec option set on removable media partitions"
	NSR
}
# End of 1.1.20 Ensure noexec option set on removable media partitions

# 1.1.21 Ensure sticky bit is set on all world-writable directories
# Scored, Level 1, Server and Workstation
R1.1.21()
{
	RN=1.1.21
	RNA="Ensure sticky bit is set on all world-writable directories"
	. $FDIR/RF00121.sh
	RF00121
}
# End of 1.1.21 Ensure sticky bit is set on all world-writable directories

# 1.1.22 Disable Automounting
# Scored, Level 1 Server, Level 2 Workstation
R1.1.22()
{
	RN=1.1.22
	RNA="Disable Automounting"
	. $FDIR/RF00122.sh
	RF00122
}
# End of 1.1.22 Disable Automounting

# Section 1.2 Configure Software Updates

# 1.2.1 Ensure package manager repositories are configured
# Not Scored, Level 1 Server and Workstation
R1.2.1()
{
	RN=1.2.1
	RNA="Ensure package manager repositories are configured"
	NSR
}
# End of 1.2.1 Ensure package manager repositories are configured

# 1.2.2 Ensure GPG keys are configured
# Not Scored, Level 1, Server and Workstation
R1.2.2()
{
	RN=1.2.2
	RNA="Ensure GPG keys are configured"
	NSR
}
# End of 1.2.2 Ensure GPG keys are configured

#Section 1.3 Filesystem Integrity Checking

# 1.3.1 Ensure AIDE is installed
# Scored, Level 1 Server and Workstation
R1.3.1()
{
	RN=1.3.1
	RNA="Ensure AIDE is installed"
	. $FDIR/RF00131.sh
	RF00131
}
# End of 1.3.1 Ensure AIDE is installed

# 1.3.2 Ensure filesystem integrity is regularly checked
# Scored, Level 1, Server and Workstation
R1.3.2()
{
	RN=1.3.2
	RNA="Ensure filesystem integrity is regularly checked"
	. $FDIR/RF00132.sh
	RF00132
}
# End of 1.3.2 Ensure filesystem integrity is regularly checked

# Section 1.4 Secure Boot Settings

# 1.4.1 Ensure permissions on bootloader config are configured
# Scored, Level 1 Server and Workstation
R1.4.1()
{
	RN=1.4.1
	RNA="Ensure permissions on bootloader config are configured"
	. $FDIR/RF00141.sh
	RF00141
}
# End of 1.4.1 Ensure permissions on bootloader config are configured

# 1.4.2 Ensure bootloader password is set
# Scored, Level 1 Server and Workstation
R1.4.2()
{
	RN=1.4.2
	RNA="Ensure bootloader password is set"
	. $FDIR/RF00142.sh
	RF00142
}
# End of 1.4.2 Ensure bootloader password is set

# 1.4.3 Ensure authentication required for single user mode
# Scored, Level 1, Server and Workstation
R1.4.3()
{
	RN=1.4.3
	RNA="Ensure authentication required for single user mode"
	. $FDIR/RF00143.sh
	RF00143
}
# End of 1.4.3 Ensure authentication required for single user mode

# 1.5 Additional Process Hardening

# 1.5.1 Ensure core dumps are restricted
# Scored, Level 1, Server and Workstation
R1.5.1()
{
	RN=1.5.1
	RNA="Ensure core dumps are restricted"
	. $FDIR/RF00151.sh
	RF00151
}
# End of 1.5.1 Ensure core dumps are restricted

# 1.5.2 Ensure XD/NX support is enabled
# Not Scored, Level 1, Server and Workstation
R1.5.2()
{
	RN=1.5.2
	RNA="Ensure XD/NX support is enabled"
	NSR
}
# End of 1.5.2 Ensure XD/NX support is enabled

# 1.5.3 Ensure address space layout randomization (ASLR) is enabled
# Scored, Level 1, Server and Workstation
R1.5.3()
{
	RN=1.5.3
	RNA="Ensure address space layout randomization (ASLR) is enabled"
	. $FDIR/RF00153.sh
	RF00153
}
# End of 1.5.3 Ensure address space layout randomization (ASLR) is enabled

# 1.5.4 Ensure prelink is disabled
# Scored, Level 1, Server and Workstation
R1.5.4()
{
	RN=1.5.4
	RNA="Ensure prelink is disabled"
	. $FDIR/RF00154.sh
	RF00154
}
# End of 1.5.4 Ensure prelink is disabled

# 1.6 Mandatory Access Control

# 1.6.1 Configure SELinux

# 1.6.1.1 Ensure SELinux is enabled in the bootloader configuration
# Scored, Level 2, Server and Workstation
R1.6.1.1()
{
	RN=1.6.1.1
	RNA="Ensure SELinux is enabled in the bootloader configuration"
	. $FDIR/RF00161.sh
	RF00161
}
# End of 1.6.1.1 Ensure SELinux is enabled in the bootloader configuration

# 1.6.1.2 Ensure the SELinux state is enforcing
# Scored, Level 2, Server and Workstation
# This will only work for a Debian Family Distrobution
R1.6.1.2()
{
	RN=1.6.1.2
	RNA="Ensure the SELinux state is enforcing"
	. $FDIR/RF00162.sh
	RF00162
}
# End of 1.6.1.2 Ensure the SELinux state is enforcing

# 1.6.1.3 Ensure SELinux policy is configured
# Scored, Level 2, Server and Workstation
R1.6.1.3()
{
	RN=1.6.1.3
	RNA="Ensure SELinux policy is configured"
	. $FDIR/RF00163.sh
	RF00163
}
# End of 1.6.1.3 Ensure SELinux policy is configured

# 1.6.1.4 Ensure no unconfined daemons exist
# Scored, Level 2, Server and Workstation
R1.6.1.4()
{
	RN=1.6.1.4
	RNA="Ensure no unconfined daemons exist"
	. $FDIR/RF00164.sh
	RF00164
}
# End of 1.6.1.4 Ensure no unconfined daemons exist

# 1.6.2 Configure AppArmor

# 1.6.2.1 Ensure AppArmor is enabled in the bootloader configuration
# Scored, Level 2, Server and Workstation
R1.6.2.1()
{
	RN=1.6.2.1
	RNA="Ensure AppArmor is enabled in the bootloader configuration"
	. $FDIR/RF00165.sh
	RF00165
}
# End of 1.6.2.1 Ensure AppArmor is enabled in the bootloader configuration

# 1.6.2.2 Ensure all AppArmor Profiles are enforcing
# Scored, Level 2, Server and Workstation
R1.6.2.2()
{
	RN=1.6.2.2
	RNA="Ensure all AppArmor Profiles are enforcing"
	. $FDIR/RF00166.sh
	RF00166
}
# End of 1.6.2.2 Ensure all AppArmor Profiles are enforcing

# 1.6.3 Ensure SELinux or AppArmor are installed
# Scored, Level 2, Server and Workstation
R1.6.3()
{
	RN=1.6.3
	RNA="Ensure SELinux or AppArmor are installed"
	. $FDIR/RF00167.sh
	RF00167
}
# End of 1.6.3 Ensure SELinux or AppArmor are installed

# 1.7 Warning Banners

# 1.7.1 Command Line Warning Banners

# 1.7.1.1 Ensure message of the day is configured properly
# Scored, Level 1, Server and Workstation
R1.7.1.1()
{
	RN=1.7.1.1
	RNA="Ensure message of the day is configured properly"
	. $FDIR/RF00171.sh
	RF00171
}
# End of 1.7.1.1 Ensure message of the day is configured properly

# 1.7.1.2 Ensure local login warning banner is configured properly
# Scored, Level 1, Server and Workstation
R1.7.1.2()
{
	RN=1.7.1.2
	RNA="Ensure local login warning banner is configured properly"
	. $FDIR/RF00172.sh
	RF00172
}
# End of 1.7.1.2 Ensure local login warning banner is configured properly

# 1.7.1.3 Ensure remote login warning banner is configured properly
# Scored, Level 1, Server and Workstation
R1.7.1.3()
{
	RN=1.7.1.3
	RNA="Ensure remote login warning banner is configured properly"
	. $FDIR/RF00173.sh
	RF00173
}
# End of 1.7.1.3 Ensure remote login warning banner is configured properly

# 1.7.1.4 Ensure permissions on /etc/motd are configured
# Scored, Level 1, Server and Workstation
R1.7.1.4()
{
	RN=1.7.1.4
	RNA="Ensure permissions on /etc/motd are configured"
	. $FDIR/RF00174.sh
	RF00174
}
#End of 1.7.1.4 Ensure permissions on /etc/motd are configured

# 1.7.1.5 Ensure permissions on /etc/issue are configured
# Scored, Level 1, Server and Workstation
R1.7.1.5()
{
	RN=1.7.1.5
	RNA="Ensure permissions on /etc/issue are configured"
	. $FDIR/RF00175.sh
	RF00175
}
#1.7.1.5 End of Ensure permissions on /etc/issue are configured

# 1.7.1.6 Ensure permissions on /etc/issue.net are configured
# Scored, Level 1, Server and Workstation
R1.7.1.6()
{
	RN=1.7.1.6
	RNA="Ensure permissions on /etc/issue.net are configured"
	. $FDIR/RF00176.sh
	RF00176
}
#End of 1.7.1.6 Ensure permissions on /etc/issue.net are configured

# 1.7.2 Ensure GDM login banner is configured
# Scored, Level 1, Server and Workstation
R1.7.2()
{
	RN=1.7.2
	RNA="Ensure GDM login banner is configured"
	. $FDIR/RF00177.sh
	RF00177
}
#End of 1.7.2 Ensure GDM login banner is configured

# 1.8 Ensure updates, patches, and additional security software are installed
# Not Scored, Level 1, Server and Workstation
R1.8()
{
	RN=1.8
	RNA="Ensure updates, patches, and additional security software are installed"
	NSR
}
# End of 1.8 Ensure updates, patches, and additional security software are installed

# 2 Services

# 2.1 inetd Services

# 2.1.1 Ensure xinetd is not installed
# Scored, Level 1, Server and Workstation
R2.1.1()
{
	RN=2.1.1
	RNA="Ensure xinetd is not installed"
	. $FDIR/RF00201.sh
	RF00201
}
# End of 2.1.1 Ensure xinetd is not installed

# 2.1.2 Ensure openbsd-inetd is not installed
# Scored, Level 1, Server and Workstation
R2.1.2()
{
	RN=2.1.2
	RNA="Ensure openbsd-inetd is not installed"
	. $FDIR/RF00202.sh
	RF00202
}
# End of 2.1.2 Ensure openbsd-inetd is not installed

# 2.2 Special Purpose Services

# 2.2.1 Time Synchronization

# 2.2.1.1 Ensure time synchronization is in use
# Not Scored, Level 1, Server and Workstation
R2.2.1.1()
{
	RN=2.2.1.1
	RNA="Ensure time synchronization is in use"
	. $FDIR/RF00203.sh
	RF00203
}
# End of 2.2.1.1 Ensure time synchronization is in use

# 2.2.1.2 Ensure ntp is configured
# Scored, Level 1, Server and Workstation
R2.2.1.2()
{
	RN=2.2.1.2
	RNA="Ensure ntp is configured"
	. $FDIR/RF00204.sh
	RF00204
}
# End of 2.2.1.2 Ensure ntp is configured

# 2.2.1.3 Ensure chrony is configured
# Scored, Level 1, Server and Workstation
R2.2.1.3()
{
	RN=2.2.1.3
	RNA="Ensure chrony is configured"
	. $FDIR/RF00205.sh
	RF00205
}
# End of 2.2.1.3 Ensure chrony is configured

# 2.2.2 Ensure X Window System is not installed
# Scored, Level 1, Server
R2.2.2()
{
	RN=2.2.2
	RNA="Ensure X Window System is not installed"
	. $FDIR/RF00206.sh
	RF00206
}
# End of 2.2.2 Ensure X Window System is not installed

# 2.2.3 Ensure Avahi Server is not enabled
# Scored, Level 1, Server and Workstation
R2.2.3()
{
	RN=2.2.3
	RNA="Ensure Avahi Server is not enabled"
	. $FDIR/RF00207.sh
	RF00207
}
# End of 2.2.3 Ensure Avahi Server is not enabled

# 2.2.4 Ensure CUPS is not enabled
# Scored, Level 1 Server, Level 2 Workstation
R2.2.4()
{
	RN=2.2.4
	RNA="Ensure CUPS is not enabled"
	. $FDIR/RF00208.sh
	RF00208
}
# End of 2.2.4 Ensure CUPS is not enabled

# 2.2.5 Ensure DHCP Server is not enabled
# Scored, Level 1, Server and Workstation
R2.2.5()
{
	RN=2.2.5
	RNA="Ensure DHCP Server is not enabled"
	. $FDIR/RF00209.sh
	RF00209
}
# End of 2.2.5 Ensure DHCP Server is not enabled

# 2.2.6 Ensure LDAP server is not enabled
# Scored, Level 1, Server and Workstation
R2.2.6()
{
	RN=2.2.6
	RNA="Ensure LDAP server is not enabled"
	. $FDIR/RF00210.sh
	RF00210
}
# End of 2.2.6 Ensure LDAP Server is not enabled

# 2.2.7 Ensure NFS and RPC are not enabled
# Scored, Level 1, Server and Workstation
R2.2.7()
{
	RN=2.2.7
	RNA="Ensure NFS and RPC are not enabled"
	. $FDIR/RF00211.sh
	RF00211
}
# End of 2.2.7 Ensure NFS and RPC are not enabled

# 2.2.8 Ensure DNS Server is not enabled
# Scored, Level 1, Server and Workstation
R2.2.8()
{
	RN=2.2.8
	RNA="Ensure DNS Server is not enabled"
	. $FDIR/RF00212.sh
	RF00212
}
# End of 2.2.8 Ensure DNS Server is not enabled

# 2.2.9 Ensure FTP Server is not enabled
# Scored, Level 1, Server and Workstation
R2.2.9()
{
	RN=2.2.9
	RNA="Ensure FTP Server is not enabled"
	. $FDIR/RF00213.sh
	RF00213
}
# End of 2.2.9 Ensure FTP Server is not enabled

# 2.2.10 Ensure HTTP server is not enabled
# Scored, Level 1, Server and Workstation
R2.2.10()
{
	RN=2.2.10
	RNA="Ensure HTTP server is not enabled"
	. $FDIR/RF00214.sh
	RF00214
}
# End of 2.2.10 Ensure HTTP server is not enabled

# 2.2.11 Ensure IMAP and POP3 server is not enabled
# Scored, Level 1, Server and Workstation
R2.2.11()
{
	RN=2.2.11
	RNA="Ensure IMAP and POP3 server is not enabled"
	. $FDIR/RF00215.sh
	RF00215
}
# End of 2.2.11 Ensure IMAP and POP3 server is not enabled

# 2.2.12 Ensure Samba is not enabled
# Scored, Level 1, Server and Workstation
R2.2.12()
{
	RN=2.2.12
	RNA="Ensure Samba is not enabled"
	. $FDIR/RF00216.sh
	RF00216
}
# End of 2.2.12 Ensure Samba is not enabled

# 2.2.13 Ensure HTTP Proxy Server is not enabled
# Scored, Level 1, Server and Workstation
R2.2.13()
{
	RN=2.2.13
	RNA="Ensure HTTP Proxy Server is not enabled"
	. $FDIR/RF00217.sh
	RF00217
}
# End of 2.2.13 Ensure HTTP Proxy Server is not enabled

# 2.2.14 Ensure SNMP Server is not enabled
# Scored, Level 1, Server and Workstation
R2.2.14()
{
	RN=2.2.14
	RNA="Ensure SNMP Server is not enabled"
	. $FDIR/RF00218.sh
	RF00218
}
# End of 2.2.14 Ensure SNMP Server is not enabled

# 2.2.15 Ensure mail transfer agent is configured for local-only mode
# Scored, Level 1, Server and Workstation
R2.2.15()
{
	RN=2.2.15
	RNA="Ensure mail transfer agent is configured for local-only mode"
	. $FDIR/RF00219.sh
	RF00219
}
# End of 2.2.15 Ensure mail transfer agent is configured for local-only mode

# 2.2.16 Ensure rsync service is not enabled
# Scored, Level 1, Server and Workstation
R2.2.16()
{
	RN=2.2.16
	RNA="Ensure rsync service is not enabled"
	. $FDIR/RF00220.sh
	RF00220
}
# End of 2.2.16 Ensure rsync service is not enabled

# 2.2.17 Ensure NIS Server is not enabled
# Scored, Level 1, Server and Workstation
R2.2.17()
{
	RN=2.2.17
	RNA="Ensure NIS Server is not enabled"
	. $FDIR/RF00221.sh
	RF00221
}
# End of 2.2.17 Ensure NIS Server is not enabled

# 2.3 Service Clients

# 2.3.1 Ensure NIS Client is not installed
# Scored, Level 1, Server and Workstation
R2.3.1()
{
	RN=2.3.1
	RNA="Ensure NIS Client is not installed"
	. $FDIR/RF00231.sh
	RF00231
}
# End of 2.3.1 Ensure NIS Client is not installed

# 2.3.2 Ensure rsh client is not installed
# Scored, Level 1, Server and Workstation
R2.3.2()
{
	RN=2.3.2
	RNA="Ensure Ensure rsh client is not installed"
	. $FDIR/RF00232.sh
	RF00232
}
# End of 2.3.2 Ensure rsh client is not installed

# 2.3.3 Ensure talk client is not installed
# Scored, Level 1, Server and Workstation
R2.3.3()
{
	RN=2.3.3
	RNA="Ensure talk client is not installed"
	. $FDIR/RF00233.sh
	RF00233
}
# End of 2.3.3 Ensure talk client is not installed

# 2.3.4 Ensure telnet client is not installed
# Scored, Level 1, Server and Workstation
R2.3.4()
{
	RN=2.3.4
	RNA="Ensure telnet client is not installed"
	. $FDIR/RF00234.sh
	RF00234
}
# End of 2.3.4 Ensure telnet client is not installed

# 2.3.5 Ensure LDAP client is not installed
# Scored, Level 1, Server and Workstation
R2.3.5()
{
	RN=2.3.5
	RNA="Ensure LDAP client is not installed"
	. $FDIR/RF00235.sh
	RF00235
}
# End of 2.3.5 Ensure LDAP client is not installed

# 3 Network Configuration

# 3.1 Network Parameters (Host Only)

# 3.1.1 Ensure IP forwarding is disabled
# Scored, Level 1, Server and Workstation
R3.1.1()
{
	RN=3.1.1
	RNA="Ensure IP forwarding is disabled"
	. $FDIR/RF00301.sh
	RF00301
}
# End of 3.1.1 Ensure IP forwarding is disabled

# 3.1.2 Ensure packet redirect sending is disabled
# Scored, Level 1, Server and Workstation
R3.1.2()
{
	RN=3.1.2
	RNA="Ensure packet redirect sending is disabled"
	. $FDIR/RF00302.sh
	RF00302
}
# End of 3.1.2 Ensure packet redirect sending is disabled

# 3.2 Network Parameters (Host and Router)

# 3.2.1 Ensure source routed packets are not accepted
# Scored, Level 1, Server and Workstation
R3.2.1()
{
	RN=3.2.1
	RNA="Ensure source routed packets are not accepted"
	. $FDIR/RF00321.sh
	RF00321
}
# End of 3.2.1 Ensure source routed packets are not accepted

# 3.2.2 Ensure ICMP redirects are not accepted
# Scored, Level 1, Server and Workstation
R3.2.2()
{
	RN=3.2.2
	RNA="Ensure ICMP redirects are not accepted"
	. $FDIR/RF00322.sh
	RF00322
}
# End of 3.2.2 Ensure ICMP redirects are not accepted

# 3.2.3 Ensure secure ICMP redirects are not accepted
# Scored, Level 1, Server and Workstation
R3.2.3()
{
	RN=3.2.3
	RNA="Ensure secure ICMP redirects are not accepted"
	. $FDIR/RF00323.sh
	RF00323
}
# End of 3.2.3 Ensure secure ICMP redirects are not accepted

# 3.2.4 Ensure suspicious packets are logged
# Scored, Level 1, Server and Workstation
R3.2.4()
{
	RN=3.2.4
	RNA="Ensure suspicious packets are logged"
	. $FDIR/RF00324.sh
	RF00324
}
# End of 3.2.4 Ensure suspicious packets are logged

# 3.2.5 Ensure broadcast ICMP requests are ignored
# Scored, Level 1, Server and Workstation
R3.2.5()
{
	RN=3.2.5
	RNA="Ensure broadcast ICMP requests are ignored"
	. $FDIR/RF00325.sh
	RF00325
}
# End of 3.2.5 Ensure broadcast ICMP requests are ignored

# 3.2.6 Ensure bogus ICMP responses are ignored
# Scored, Level 1, Server and Workstation
R3.2.6()
{
	RN=3.2.6
	RNA="Ensure bogus ICMP responses are ignored"
	. $FDIR/RF00326.sh
	RF00326
}
# End of 3.2.6 Ensure bogus ICMP responses are ignored

# 3.2.7 Ensure Reverse Path Filtering is enabled
# Scored, Level 1, Server and Workstation
R3.2.7()
{
	RN=3.2.7
	RNA="Ensure Reverse Path Filtering is enabled"
	. $FDIR/RF00327.sh
	RF00327
}
# End of 3.2.7 Ensure Reverse Path Filtering is enabled

# 3.2.8 Ensure TCP SYN Cookies is enabled
# Scored, Level 1, Server and Workstation
R3.2.8()
{
	RN=3.2.8
	RNA="Ensure TCP SYN Cookies is enabled"
	. $FDIR/RF00328.sh
	RF00328
}
# End of 3.2.8 Ensure TCP SYN Cookies is enabled

# 3.2.9 Ensure IPv6 router advertisements are not accepted
# Scored, Level 1, Server and Workstation
R3.2.9()
{
	RN=3.2.9
	RNA="Ensure IPv6 router advertisements are not accepted"
	. $FDIR/RF00329.sh
	RF00329
}
# End of 3.2.9 Ensure IPv6 router advertisements are not accepted

# 3.3 TCP Wrappers

# 3.3.1 Ensure TCP Wrappers is installed
# Scored, Level 1, Server and Workstation
R3.3.1()
{
	RN=3.3.1
	RNA="Ensure TCP Wrappers is installed"
	. $FDIR/RF00331.sh
	RF00331
}
# End of 3.3.1 Ensure TCP Wrappers is installed

# 3.3.2 Ensure /etc/hosts.allow is configured
# Not Scored, Level 1, Server and Workstation
R3.3.2()
{
	RN=3.3.2
	RNA="Ensure /etc/hosts.allow is configured"
	NSR
}
# End of 3.3.2 Ensure /etc/hosts.allow is configured

# 3.3.3 Ensure /etc/hosts.deny is configured
# Not Scored, Level 1, Server and Workstation
R3.3.3()
{
	RN=3.3.3
	RNA="Ensure /etc/hosts.deny is configured"
	NSR
}
# End of 3.3.3 Ensure /etc/hosts.deny is configured

# 3.3.4 Ensure permissions on /etc/hosts.allow are configured
# Scored, Level 1, Server and Workstation
R3.3.4()
{
	RN=3.3.4
	RNA="Ensure permissions on /etc/hosts.allow are configured"
	. $FDIR/RF00334.sh
	RF00334
}
# End of 3.3.4 Ensure permissions on /etc/hosts.allow are configured

# 3.3.5 Ensure permissions on /etc/hosts.deny are configured
# Scored, Level 1, Server and Workstation
R3.3.5()
{
	RN=3.3.5
	RNA="Ensure permissions on /etc/hosts.deny are configured"
	. $FDIR/RF00335.sh
	RF00335
}
# End of 3.3.5 Ensure permissions on /etc/hosts.deny are configured

# 3.4 Uncommon Network Protocols

# 3.4.1 Ensure DCCP is disabled
# Not Scored, Level 1, Server and Workstation
R3.4.1()
{
	RN=3.4.1
	RNA="Ensure DCCP is disabled"
	. $FDIR/RF00341.sh
	RF00341
}
# End of 3.4.1 Ensure DCCP is disabled

# 3.4.2 Ensure SCTP is disabled
# Not Scored, Level 1, Server and Workstation
R3.4.2()
{
	RN=3.4.2
	RNA="Ensure SCTP is disabled"
	. $FDIR/RF00342.sh
	RF00342
}
# End of 3.4.2 Ensure SCTP is disabled

# 3.4.3 Ensure RDS is disabled
# Not Scored, Level 1, Server and Workstation
R3.4.3()
{
	RN=3.4.3
	RNA="Ensure RDS is disabled"
	. $FDIR/RF00343.sh
	RF00343
}
# End of 3.4.3 Ensure RDS is disabled

# 3.4.4 Ensure TIPC is disabled
# Not Scored, Level 1, Server and Workstation
R3.4.4()
{
	RN=3.4.4
	RNA="Ensure TIPC is disabled"
	. $FDIR/RF00344.sh
	RF00344
}
# End of 3.4.4 Ensure TIPC is disabled

# 3.5 Firewall Configuration

# 3.5.1 Configure IPv4 iptables

# 3.5.1.1 Ensure default deny firewall policy
# Scored, Level 1, Server and Workstation
R3.5.1.1()
{
	RN=3.5.1.1
	RNA="Ensure default deny firewall policy"
	. $FDIR/RF00351.sh
	RF00351
}
# End of 3.5.1.1 Ensure default deny firewall policy

# 3.5.1.2 Ensure loopback traffic is configured
# Scored, Level 1, Server and Workstation
R3.5.1.2()
{
	RN=3.1.5.2
	RNA="Ensure loopback traffic is configured"
	. $FDIR/RF00352.sh
	RF00352
}
# End of 3.5.1.2 Ensure loopback traffic is configured

# 3.5.1.3 Ensure outbound and established connections are configured
# Not Scored, Level 1, Server and Workstation
R3.5.1.3()
{
	RN=3.5.1.3
	RNA="Ensure outbound and established connections are configured"
	NSR
}
# End of 3.5.1.3 Ensure outbound and established connections are configured

# 3.5.1.4 Ensure firewall rules exist for all open ports
# Scored, Level 1, Server and Workstation
R3.5.1.4()
{
	RN=3.5.1.4
	RNA="Ensure firewall rules exist for all open ports"
	. $FDIR/RF00354.sh
	RF00354
}
# End of 3.5.1.4 Ensure firewall rules exist for all open ports

# 3.5.2 Configure IPv6 ip6tables

# 3.5.2.1 Ensure IPv6 default deny firewall policy
# Scored, Level 1 Server and Work
R3.5.2.1()
{
	RN=3.5.2.1
	RNA="Ensure IPv6 default deny firewall policy"
	. $FDIR/RF00355.sh
	RF00355
}
# End of 3.5.2.1 Ensure IPv6 default deny firewall policy

# 3.5.2.2 Ensure IPv6 loopback traffic is configured
# Scored, Level 1, Server and Workstation
R3.5.2.2()
{
	RN=3.5.2.2
	RNA="Ensure IPv6 loopback traffic is configured"
	. $FDIR/RF00356.sh
	RF00356
}
# End of 3.5.2.2 Ensure IPv6 loopback traffic is configured

# 3.5.2.3 Ensure IPv6 outbound and established connections are configured
# Not Scored, Level 1, Server and Workstation
R3.5.2.3()
{
	RN=3.5.2.3
	RNA="Ensure IPv6 outbound and established connections are configured"
	NSR
}
# End of 3.5.2.3 Ensure IPv6 outbound and established connections are configured

# 3.5.2.4 Ensure IPv6 firewall rules exist for all open ports
# Not Scored, Level 1, Server and Workstation
R3.5.2.4()
{
	RN=3.5.2.4
	RNA="Ensure IPv6 firewall rules exist for all open ports"
	NSR
}
# End of 3.5.2.4 Ensure IPv6 firewall rules exist for all open ports

# 3.5.3 Ensure iptables is installed
#Scored, Level 1, Server and Workstation
R3.5.3()
{
	RN=3.5.3
	RNA="Ensure iptables is installed"
	. $FDIR/RF00357.sh
	RF00357
}
# End of 3.5.3 Ensure iptables is installed

# 3.6 Ensure wireless interfaces are disabled
# Not Scored, Level 1, Server and Workstation
R3.6()
{
	RN=3.6
	RNA="Ensure wireless interfaces are disabled"
	NSR
}
# End of 3.6 Ensure wireless interfaces are disabled

# 3.7 Disable IPv6
# Not Scored, Level 2, Server and Workstation
R3.7()
{
	RN=3.7
	RNA="Disable IPv6"
	. $FDIR/RF00370.sh
	RF00370
}
# End of 3.7 Disable IPv6

# 4 Logging and Auditing

# 4.1 Configure System Accounting (auditd)

# 4.1.1 Configure Data Retention

# 4.1.1.1 Ensure audit log storage size is configured
# Not Scored, Level 2, Server and Workstation
R4.1.1.1()
{
	RN=4.1.1.1
	RNA="Ensure audit log storage size is configured"
	NSR
}
# End of 4.1.1.1 Ensure audit log storage size is configured

# 4.1.1.2 Ensure system is disabled when audit logs are full
# Scored, Level 2, Server and Workstation
R4.1.1.2()
{
	RN=4.1.1.2
	RNA="Ensure system is disabled when audit logs are full"
	. $FDIR/RF00402.sh
	RF00402
}
# End of 4.1.1.2 Ensure system is disabled when audit logs are full

# 4.1.1.3 Ensure audit logs are not automatically deleted
# Scored, Level 2, Server and Workstation
R4.1.1.3()
{
	RN=4.1.1.3
	RNA="Ensure audit logs are not automatically deleted"
	. $FDIR/RF00403.sh
	RF00403
}
# End of 4.1.1.3 Ensure audit logs are not automatically deleted

# 4.1.2 Ensure auditd service is enabled
# Scored, Level 2, Server and Workstation
R4.1.2()
{
	RN=4.1.2
	RNA="Ensure auditd service is enabled"
	. $FDIR/RF00404.sh
	RF00404
}
# End of 4.1.2 Ensure auditd service is enabled

# 4.1.3 Ensure auditing for processes that start prior to auditd is enabled
# Scored, Level 2, Server and Workstation
R4.1.3()
{
	RN=4.1.3
	RNA="Ensure auditing for processes that start prior to auditd is enabled"
	. $FDIR/RF00405.sh
	RF00405
}
# End of 4.1.3 Ensure auditing for processes that start prior to auditd is enabled

# 4.1.4 Ensure events that modify date and time information are collected
# Scored, Level 2, Server and Workstation
R4.1.4()
{
	RN=4.1.4
	RNA="Ensure events that modify date and time information are collected"
	. $FDIR/RF00406.sh
	RF00406
}
# End of 4.1.4 Ensure events that modify date and time information are collected

# 4.1.5 Ensure events that modify user/group information are collected
# Scored, Level 2, Server and Workstation
R4.1.5()
{
	RN=4.1.5
	RNA="Ensure events that modify user/group information are collected"
	. $FDIR/RF00407.sh
	RF00407
}
# End of 4.1.5 Ensure events that modify user/group information are collected

# 4.1.6 Ensure events that modify the system's network environment are collected
# Scored, Level 2, Server and Workstation
R4.1.6()
{
	RN=4.1.6
	RNA="Ensure events that modify the system's network environment are collected"
	. $FDIR/RF00408.sh
	RF00408
}
# End of 4.1.6 Ensure events that modify the system's network environment are collected

# 4.1.7 Ensure events that modify the system's Mandatory Access Controls are collected
# Scored, Level 2, Server and Workstation
R4.1.7()
{
	RN=4.1.7
	RNA="Ensure events that modify the system's Mandatory Access Controls are collected"
	. $FDIR/RF00409.sh
	RF00409
}
# End of 4.1.7 Ensure events that modify the system's Mandatory Access Controls are collected

# 4.1.8 Ensure login and logout events are collected
# Scored, Level 2, Server and Workstation
R4.1.8()
{
	RN=4.1.8
	RNA="Ensure login and logout events are collected"
	. $FDIR/RF00410.sh
	RF00410
}
# End of 4.1.8 Ensure login and logout events are collected

# 4.1.9 Ensure session initiation information is collected
# Scored, Level 2, Server and Workstation
R4.1.9()
{
	RN=4.1.9
	RNA="Ensure session initiation information is collected"
	. $FDIR/RF00411.sh
	RF00411
}
# End of 4.1.9 Ensure session initiation information is collected

# 4.1.10 Ensure discretionary access control permission modification events are collected
# Scored, Level 2, Server and Workstation
R4.1.10()
{
	RN=4.1.10
	RNA="Ensure discretionary access control permission modification events are collected"
	. $FDIR/RF00412.sh
	RF00412
}
# End of 4.1.10 Ensure discretionary access control permission modification events are collected

# 4.1.11 Ensure unsuccessful unauthorized file access attempts are collected
# Scored, Level 2, Server and Workstation
R4.1.11()
{
	RN=4.1.11
	RNA="Ensure unsuccessful unauthorized file access attempts are collected"
	. $FDIR/RF00413.sh
	RF00413
}
# End of 4.1.11 Ensure unsuccessful unauthorized file access attempts are collected

# 4.1.12 Ensure use of privileged commands is collected
# Scored, Level 2, Server and Workstation
R4.1.12()
{
	RN=4.1.12
	RNA="Ensure unsuccessful unauthorized file access attempts are collected"
	. $FDIR/RF00414.sh
	RF00414
}
# End of 4.1.12 Ensure use of privileged commands is collected

# 4.1.13 Ensure successful file system mounts are collected
# Scored, Level 2, Server and Workstation
R4.1.13()
{
	RN=4.1.13
	RNA="Ensure successful file system mounts are collected"
	. $FDIR/RF00415.sh
	RF00415
}
# End of 4.1.13 Ensure successful file system mounts are collected

# 4.1.14 Ensure file deletion events by users are collected
# Scored, Level 2, Server and Workstation
R4.1.14()
{
	RN=4.1.14
	RNA="Ensure file deletion events by users are collected"
	. $FDIR/RF00416.sh
	RF00416
}
# End of 4.1.14 Ensure file deletion events by users are collected

# 4.1.15 Ensure changes to system administration scope (sudoers) is collected
# Scored, Level 2, Server and Workstation
R4.1.15()
{
	RN=4.1.15
	RNA="Ensure changes to system administration scope (sudoers) is collected"
	. $FDIR/RF00417.sh
	RF00417
}
# End of 4.1.15 Ensure changes to system administration scope (sudoers) is collected

# 4.1.16 Ensure system administrator actions (sudolog) are collected
# Scored, Level 2, Server and Workstation
R4.1.16()
{
	RN=4.1.16
	RNA="Ensure system administrator actions (sudolog) are collected"
	. $FDIR/RF00418.sh
	RF00418
}
# End of 4.1.16 Ensure system administrator actions (sudolog) are collected

# 4.1.17 Ensure kernel module loading and unloading is collected
# Scored, Level 2, Server and Workstation
R4.1.17()
{
	RN=4.1.17
	RNA="Ensure kernel module loading and unloading is collected"
	. $FDIR/RF00419.sh
	RF00419
}
# End of 4.1.17 Ensure kernel module loading and unloading is collected

# 4.1.18 Ensure the audit configuration is immutable
# Scored, Level 2, Server and Workstation
R4.1.18()
{
	RN=4.1.18
	RNA="Ensure the audit configuration is immutable"
	. $FDIR/RF00420.sh
	RF00420
}
# End of 4.1.18 Ensure the audit configuration is immutable

# 4.2 Configure Logging

# 4.2.1 Configure rsyslog

# 4.2.1.1 Ensure rsyslog Service is enabled
# Scored, Level 1, Server and Workstation
R4.2.1.1()
{
	RN=4.2.1.1
	RNA="Ensure rsyslog Service is enabled"
	. $FDIR/RF00421.sh
	RF00421
}
# End of 4.2.1.1 Ensure rsyslog Service is enabled

# 4.2.1.2 Ensure logging is configured
# Not Scored, Level 1, Server and Workstation
R4.2.1.2()
{
	RN=4.2.1.2
	RNA="Ensure logging is configured"
	. $FDIR/RF00422.sh
	RF00422
}
# End of 4.2.1.2 Ensure logging is configured

# 4.2.1.3 Ensure rsyslog default file permissions configured
# Scored, Level 1, Server and Workstation
R4.2.1.3()
{
	RN=4.2.1.3
	RNA="Ensure rsyslog default file permissions configured"
	. $FDIR/RF00423.sh
	RF00423
}
# End of 4.2.1.3 Ensure rsyslog default file permissions configured

# 4.2.1.4 Ensure rsyslog is configured to send logs to a remote log host
# Scored, Level 1, Server and Workstation
R4.2.1.4()
{
	RN=4.2.1.4
	RNA="Ensure rsyslog is configured to send logs to a remote log host"
	. $FDIR/RF00424.sh
	RF00424
}
# End of 4.2.1.4 Ensure rsyslog is configured to send logs to a remote log host

# 4.2.1.5 Ensure remote rsyslog messages are only accepted on designated log hosts
# Not Scored
R4.2.1.5()
{
	RN=4.2.1.5
	RNA="Ensure remote rsyslog messages are only accepted on designated log hosts"
	. $FDIR/RF00425.sh
	RF00425
}
# End of 4.2.1.5 Ensure remote rsyslog messages are only accepted on designated log hosts

# 4.2.2 Configure syslog-ng

# 4.2.2.1 Ensure syslog-ng service is enabled
# Scored, Level 1, Server and Workstation
R4.2.2.1()
{
	RN=4.2.2.1
	RNA="Ensure syslog-ng service is enabled"
	. $FDIR/RF00427.sh
	RF00427
}
# End of 4.2.2.1 Ensure syslog-ng service is enabled

# 4.2.2.2 Ensure logging is configured
# Not Scored, Level 1, Server and Workstation
R4.2.2.2()
{
	RN=4.2.2.2
	RNA="Ensure logging is configured"
	. $FDIR/RF00428.sh
	RF00428
}
# End of 4.2.2.2 Ensure logging is configured

# 4.2.2.3 Ensure syslog-ng default file permissions configured
# Scored, Level 1, Server and Workstation
R4.2.2.3()
{
	RN=4.2.2.3
	RNA="Ensure syslog-ng default file permissions configured"
	. $FDIR/RF00429.sh
	RF00429
}
# End of 4.2.2.3 Ensure syslog-ng default file permissions configured

# 4.2.2.4 Ensure syslog-ng is configured to send logs to a remote log host
# Not Scored, Level 1, Server and Workstation
R4.2.2.4()
{
	RN=4.2.2.4
	RNA="Ensure syslog-ng is configured to send logs to a remote log host"
	. $FDIR/RF00430.sh
	RF00430
}
# End of 4.2.2.4 Ensure syslog-ng is configured to send logs to a remote log host

# 4.2.2.5 Ensure remote syslog-ng messages are only accepted on designated log hosts
# Not Scored, Level 1, Server and Workstation
R4.2.2.5()
{
	RN=4.2.2.5
	RNA="Ensure remote syslog-ng messages are only accepted on designated log hosts"
	. $FDIR/RF00431.sh
	RF00431
}
# End of 4.2.2.5 Ensure remote syslog-ng messages are only accepted on designated log hosts

# 4.2.3 Ensure rsyslog or syslog-ng is installed
# Scored, Level 1, Server or Workstation
R4.2.3()
{
	RN=4.2.3
	RNA="Ensure rsyslog or syslog-ng is installed"
	. $FDIR/RF00433.sh
	RF00433
}
# End of 4.2.3 Ensure rsyslog or syslog-ng is installed

# 4.2.4 Ensure permissions on all logfiles are configured
# Scored, Level 1, Server and Workstation
R4.2.4()
{
	RN=4.2.4
	RNA="Ensure permissions on all logfiles are configured"
	. $FDIR/RF00434.sh
	RF00434
}
# End of 4.2.4 Ensure permissions on all logfiles are configured

# 4.3 Ensure logrotate is configured
# Not Scored, Level 1, Server and Workstation
R4.3()
{
	RN=4.3
	RNA="Ensure logrotate is configured"
	NSR
}
# End of 4.3 Ensure logrotate is configured

# 5 Access, Authentication and Authorization

# 5.1 Configure cron

# 5.1.1 Ensure cron daemon is enabled
# Scored, Level 1, Server and Workstation
R5.1.1()
{
	RN=5.1.1
	RNA="Ensure cron daemon is enabled"
	. $FDIR/RF00501.sh
	RF00501
}
# End of 5.1.1 Ensure cron daemon is enabled

# 5.1.2 Ensure permissions on /etc/crontab are configured
# Scored, Level 1, Server and Workstation
R5.1.2()
{
	RN=5.1.2
	RNA="Ensure permissions on /etc/crontab are configured"
	. $FDIR/RF00502.sh
	RF00502
}
# End of 5.1.2 Ensure permissions on /etc/crontab are configured

# 5.1.3 Ensure permissions on /etc/cron.hourly are configured
# Scored, Level 1, Server and Workstation
R5.1.3()
{
	RN=5.1.3
	RNA="Ensure permissions on /etc/cron.hourly are configured"
	. $FDIR/RF00503.sh
	RF00503
}
# End of 5.1.3 Ensure permissions on /etc/cron.hourly are configured

# 5.1.4 Ensure permissions on /etc/cron.daily are configured
# Scored, Level 1, Server and Workstation
R5.1.4()
{
	RN=5.1.4
	RNA="Ensure permissions on /etc/cron.daily are configured"
	. $FDIR/RF00504.sh
	RF00504
}
# End of 5.1.4 Ensure permissions on /etc/cron.daily are configured

# 5.1.5 Ensure permissions on /etc/cron.weekly are configured
# Scored, Level 1, Server and Workstation
R5.1.5()
{
	RN=5.1.5
	RNA="Ensure permissions on /etc/cron.weekly are configured"
	. $FDIR/RF00505.sh
	RF00505
}
# End of 5.1.5 Ensure permissions on /etc/cron.weekly are configured

# 5.1.6 Ensure permissions on /etc/cron.monthly are configured
# Scored, Level 1, Server and Workstation
R5.1.6()
{
	RN=5.1.6
	RNA="Ensure permissions on /etc/cron.monthly are configured"
	. $FDIR/RF00506.sh
	RF00506
}
# End of 5.1.6 Ensure permissions on /etc/cron.monthly are configured

# 5.1.7 Ensure permissions on /etc/cron.d are configured
# Scored, Level 1, Server and Workstation
R5.1.7()
{
	RN=5.1.7
	RNA="Ensure permissions on /etc/cron.d are configured"
	. $FDIR/RF00507.sh
	RF00507
}
# End of 5.1.7 Ensure permissions on /etc/cron.d are configured are configured

# 5.1.8 Ensure at/cron is restricted to authorized users
# Scored, Level 1, Server and Workstation
R5.1.8()
{
	RN=5.1.8
	RNA="Ensure at/cron is restricted to authorized users"
	. $FDIR/RF00508.sh
	RF00508
}
# End of 5.1.8 Ensure at/cron is restricted to authorized users

# 5.2 SSH Server Configuration

# 5.2.1 Ensure permissions on /etc/ssh/sshd_config are configured
# Scored, Level 1, Server and Workstation
R5.2.1()
{
	RN=5.2.1
	RNA="Ensure permissions on /etc/ssh/sshd_config are configured"
	. $FDIR/RF00521.sh
	RF00521
}
# End of 5.2.1 Ensure permissions on /etc/ssh/sshd_config are configured

# 5.2.2 Ensure permissions on SSH private host key files are configured
# Scored, Level 1, Server and Workstation
R5.2.2()
{
	RN=5.2.2
	RNA="Ensure permissions on SSH private host key files are configured"
	. $FDIR/RF00522.sh
	RF00522
}
# End of 5.2.2 Ensure permissions on SSH private host key files are configured

# 5.2.3 Ensure permissions on SSH public host key files are configured
# Scored, Level 1, Server and Workstation
R5.2.3()
{
	RN=5.2.3
	RNA="Ensure permissions on SSH public host key files are configured"
	. $FDIR/RF00523.sh
	RF00523
}
# End of 5.2.3 Ensure permissions on SSH public host key files are configured

# 5.2.4 Ensure SSH Protocol is set to 2
# Scored, Level 1, Server and Workstation
R5.2.4()
{
	RN=5.2.4
	RNA="Ensure SSH Protocol is set to 2"
	. $FDIR/RF00524.sh
	RF00524
}
# End of 5.2.4 Ensure SSH Protocol is set to 2

# 5.2.5 Ensure SSH LogLevel is appropriate
# Scored, Level 1, Server and Workstation
R5.2.5()
{
	RN=5.2.5
	RNA="Ensure SSH LogLevel is appropriate"
	. $FDIR/RF00525.sh
	RF00525
}
# End of 5.2.5 Ensure SSH LogLevel is appropriate

# 5.2.6 Ensure SSH X11 forwarding is disabled
# Scored, Level 2 Server, Level 1 Workstation
R5.2.6()
{
	RN=5.2.6
	RNA="Ensure SSH X11 forwarding is disabled"
	. $FDIR/RF00526.sh
	RF00526
}
# End of 5.2.6 Ensure SSH X11 forwarding is disabled

# 5.2.7 Ensure SSH MaxAuthTries is set to 4 or less
# Scored, Level 1, Server and Workstation
R5.2.7()
{
	RN=5.2.7
	RNA="Ensure SSH MaxAuthTries is set to 4 or less"
	. $FDIR/RF00527.sh
	RF00527
}
# 5.2.7 Ensure SSH MaxAuthTries is set to 4 or less

# 5.2.8 Ensure SSH IgnoreRhosts is enabled
# Scored, Level 1, Server and Workstation
R5.2.8()
{
	RN=5.2.8
	RNA="Ensure SSH IgnoreRhosts is enabled"
	. $FDIR/RF00528.sh
	RF00528
}
# End of 5.2.8 Ensure SSH IgnoreRhosts is enabled

# 5.2.9 Ensure SSH HostbasedAuthentication is disabled
# Scored, Level 1, Server and Workstation
R5.2.9()
{
	RN=5.2.9
	RNA="Ensure SSH HostbasedAuthentication is disabled"
	. $FDIR/RF00529.sh
	RF00529
}
# End of 5.2.9 Ensure SSH HostbasedAuthentication is disabled

# 5.2.10 Ensure SSH root login is disabled
# Scored, Level 1, Server and Workstation
R5.2.10()
{
	RN=5.2.10
	RNA="Ensure SSH root login is disabled"
	. $FDIR/RF00530.sh
	RF00530
}
# End of 5.2.10 Ensure SSH root login is disabled

# 5.2.11 Ensure SSH PermitEmptyPasswords is disabled
# Scored, Level 1, Server and Workstation
R5.2.11()
{
	RN=5.2.11
	RNA="Ensure SSH PermitEmptyPasswords is disabled"
	. $FDIR/RF00531.sh
	RF00531
}
# 5.2.11 Ensure SSH PermitEmptyPasswords is disabled

# 5.2.12 Ensure SSH PermitUserEnvironment is disabled
# Scored, Level 1, Server and Workstation
R5.2.12()
{
	RN=5.2.12
	RNA="Ensure SSH PermitUserEnvironment is disabled"
	. $FDIR/RF00532.sh
	RF00532
}
# End of 5.2.12 Ensure SSH PermitUserEnvironment is disabled

# 5.2.13 Ensure only strong ciphers are used
# Scored, Level 1, Server and Workstation
R5.2.13()
{
	# Black list and whit list are maintained as seporate files for ease of updating in case of changes
	RN=5.2.13
	RNA="Ensure only strong ciphers are used"
	. $FDIR/RF00533.sh
	RF00533
}
# End of 5.2.13 Ensure only strong ciphers are used

# 5.2.14 Ensure only strong MAC algorithms are used
# Scored, Level 1, Server and Workstation
R5.2.14()
{
	# Black list and whit list are maintained as seporate files for ease of updating in case of changes
	RN=5.2.14
	RNA="Ensure only strong MAC algorithms are used"
	. $FDIR/RF00534.sh
	RF00534
}
# End of 5.2.14 Ensure only strong MAC algorithms are used

# 5.2.15 Ensure only strong Key Exchange algorithms are used
# Scored, Level 1, Server and Workstation
R5.2.15()
{
	# Black list and whit list are maintained as seporate files for ease of updating in case of changes
	RN=5.2.15
	RNA="Ensure only strong Key Exchange algorithms are used"
	. $FDIR/RF00535.sh
	RF00535
}
# End of 5.2.15 Ensure only strong Key Exchange algorithms are used

# 5.2.16 Ensure SSH Idle Timeout Interval is configured
# Scored, Level 1, Server and Workstation
R5.2.16()
{
	RN=5.2.16
	RNA="Ensure SSH Idle Timeout Interval is configured"
	. $FDIR/RF00536.sh
	RF00536
}
# End of 5.2.16 Ensure SSH Idle Timeout Interval is configured

# 5.2.17 Ensure SSH LoginGraceTime is set to one minute or less
# Scored, Level 1, Server and Workstation
R5.2.17()
{
	RN=5.2.17
	RNA="Ensure SSH LoginGraceTime is set to one minute or less"
	. $FDIR/RF00537.sh
	RF00537
}
# End of 5.2.17 Ensure SSH LoginGraceTime is set to one minute or less

# 5.2.18 Ensure SSH access is limited
# Scored, Level 1, Server and Workstation
R5.2.18()
{
	RN=5.2.18
	RNA="Ensure SSH access is limited"
	. $FDIR/RF00538.sh
	RF00538
}
# End of 5.2.18 Ensure SSH access is limited

# 5.2.19 Ensure SSH warning banner is configured
# Scored, Level 1, Server and Workstation
R5.2.19()
{
	RN=5.2.19
	RNA="Ensure SSH warning banner is configured"
	. $FDIR/RF00539.sh
	RF00539
}
# End of 5.2.19 Ensure SSH warning banner is configured

# 5.3 Configure PAM

# 5.3.1 Ensure password creation requirements are configured
# Scored, Level 1, Server and Workstation
R5.3.1()
{
	RN=5.3.1
	RNA="Ensure password creation requirements are configured"
	. $FDIR/RF00541.sh
	RF00541
}
# End of 5.3.1 Ensure password creation requirements are configured

# 5.3.2 Ensure lockout for failed password attempts is configured
# Scored, Level 1, Server and Workstation
R5.3.2()
{
	RN=5.3.2
	RNA="Ensure password creation requirements are configured"
	. $FDIR/RF00542.sh
	RF00542
}
# End of 5.3.2 Ensure lockout for failed password attempts is configured

# 5.3.3 Ensure password reuse is limited
# Scored, Level 1, Server and Workstation
R5.3.3()
{
	RN=5.3.3
	RNA="Ensure password reuse is limited"
	. $FDIR/RF00543.sh
	RF00543
}
# End of 5.3.3 Ensure password reuse is limited

# 5.3.4 Ensure password hashing algorithm is SHA-512
# Scored, Level 1, Server and Workstation
R5.3.4()
{
	RN=5.3.4
	RNA="Ensure password hashing algorithm is SHA-512"
	. $FDIR/RF00544.sh
	RF00544
}
# End of 5.3.4 Ensure password hashing algorithm is SHA-512

# 5.4 User Accounts and Environment

# 5.4.1 Set Shadow Password Suite Parameters

# 5.4.1.1 Ensure password expiration is 365 days or less
# Scored, Level 1, Server and Workstation
R5.4.1.1()
{
	RN=5.4.1.1
	RNA="Ensure password expiration is 365 days or less"
	. $FDIR/RF00545.sh
	RF00545
}
# End of 5.4.1.1 Ensure password expiration is 365 days or less

# 5.4.1.2 Ensure minimum days between password changes is 7 or more
# Scored, Level 1, Server and Workstation
R5.4.1.2()
{
	RN=5.4.1.2
	RNA="Ensure minimum days between password changes is 7 or more"
	. $FDIR/RF00546.sh
	RF00546
}
# End of 5.4.1.2 Ensure minimum days between password changes is 7 or more

# 5.4.1.3 Ensure password expiration warning days is 7 or more
# Scored, Level 1, Server and Workstation
R5.4.1.3()
{
	RN=5.4.1.3
	RNA="Ensure password expiration warning days is 7 or more"
	. $FDIR/RF00547.sh
	RF00547
}
# End of 5.4.1.3 Ensure password expiration warning days is 7 or more

# 5.4.1.4 Ensure inactive password lock is 30 days or less
# Scored, Level 1, Server and Workstation
R5.4.1.4()
{
	RN=5.4.1.4
	RNA="Ensure inactive password lock is 30 days or less"
	. $FDIR/RF00548.sh
	RF00548
}
# End of 5.4.1.4 Ensure inactive password lock is 30 days or less

# 5.4.1.5 Ensure all users last password change date is in the past
# Scored, Level 1, Server and Workstation
R5.4.1.5()
{
	RN=5.4.1.5
	RNA="Ensure all users last password change date is in the past"
	. $FDIR/RF00549.sh
	RF00549
}
# End of 5.4.1.5 Ensure all users last password change date is in the past

# 5.4.2 Ensure system accounts are non-login
# Scored, Level 1, Server and Workstation
R5.4.2()
{
	RN=5.4.2
	RNA="Ensure system accounts are non-login"
	. $FDIR/RF00550.sh
	RF00550
}
# End of 5.4.2 Ensure system accounts are non-login

# 5.4.3 Ensure default group for the root account is GID 0
# Scored, Level 1, Server and Workstation
R5.4.3()
{
	RN=5.4.3
	RNA="Ensure default group for the root account is GID 0"
	. $FDIR/RF00551.sh
	RF00551
}
# End of 5.4.3 Ensure default group for the root account is GID 0

# 5.4.4 Ensure default user umask is 027 or more restrictive
# Scored, Level 1, Server and Workstation
R5.4.4()
{
	RN=5.4.4
	RNA="Ensure default user umask is 027 or more restrictive"
	. $FDIR/RF00552.sh
	RF00552
}
# End of 5.4.4 Ensure default user umask is 027 or more restrictive

# 5.4.5 Ensure default user shell timeout is 900 seconds or less
# Scored, Level 2, Server and Workstation
R5.4.5()
{
	RN=5.4.5
	RNA="Ensure default user shell timeout is 900 seconds or less"
	. $FDIR/RF00553.sh
	RF00553
}
# End of 5.4.5 Ensure default user shell timeout is 900 seconds or less

# 5.5 Ensure root login is restricted to system console
# Not Scored, Level 1, Server and Workstation
R5.5()
{
	RN=5.5
	RNA="Ensure root login is restricted to system console"
	NSR
}
# End of 5.5 Ensure root login is restricted to system console

# 5.6 Ensure access to the su command is restricted
# Scored, Level 1, Server and Workstation
R5.6()
{
	RN=5.6
	RNA="Ensure access to the su command is restricted"
	. $FDIR/RF00554.sh
	RF00554
}
# End of 5.6 Ensure access to the su command is restricted

# 6 System Maintenance

# 6.1 System File Permissions

# 6.1.1 Audit system file permissions
# Not Scored, Level 2, Server and Workstation
R6.1.1()
{
	RN=6.1.1
	RNA="Audit system file permissions"
	NSR
}
# 6.1.1 Audit system file permissions

# 6.1.2 Ensure permissions on /etc/passwd are configured
# Scored, Level 1, Server and Workstation
R6.1.2()
{
	RN=6.1.2
	RNA="Ensure permissions on /etc/passwd are configured"
	. $FDIR/RF00602.sh
	RF00602
}
# End of 6.1.2 Ensure permissions on /etc/passwd are configured

# 6.1.3 Ensure permissions on /etc/shadow are configured
# Scored, Level 1, Server and Workstation
R6.1.3()
{
	RN=6.1.3
	RNA="Ensure permissions on /etc/shadow are configured"
	. $FDIR/RF00603.sh
	RF00603
}
# End of 6.1.3 Ensure permissions on /etc/shadow are configured

# 6.1.4 Ensure permissions on /etc/group are configured
# Scored, Level 1, Server and Workstation
R6.1.4()
{
	RN=6.1.4
	RNA="Ensure permissions on /etc/group are configured"
	. $FDIR/RF00604.sh
	RF00604
}
# End of 6.1.4 Ensure permissions on /etc/group are configured

# 6.1.5 Ensure permissions on /etc/gshadow are configured
# Scored, Level 1, Server and Workstation
R6.1.5()
{
	RN=6.1.5
	RNA="Ensure permissions on /etc/gshadow are configured"
	. $FDIR/RF00605.sh
	RF00605
}
# 6.1.5 Ensure permissions on /etc/gshadow are configured

# 6.1.6 Ensure permissions on /etc/passwd- are configured
# Scored, Level 1, Server and Workstation
R6.1.6()
{
	RN=6.1.6
	RNA="Ensure permissions on /etc/passwd- are configured"
	. $FDIR/RF00606.sh
	RF00606
}
# End of 6.1.6 Ensure permissions on /etc/passwd- are configured

# 6.1.7 Ensure permissions on /etc/shadow- are configured
# Scored, Level 1, Server and Workstation
R6.1.7()
{
	RN=6.1.7
	RNA="Ensure permissions on /etc/shadow- are configured"
	. $FDIR/RF00607.sh
	RF00607
}
# End of 6.1.7 Ensure permissions on /etc/shadow- are configured

# 6.1.8 Ensure permissions on /etc/group- are configured
# Scored, Level 1, Server and Workstation
R6.1.8()
{
	RN=6.1.8
	RNA="Ensure permissions on /etc/group- are configured"
	. $FDIR/RF00608.sh
	RF00608
}
# End of 6.1.8 Ensure permissions on /etc/group- are configured

# 6.1.9 Ensure permissions on /etc/gshadow- are configured
# Scored, Level 1, Server and Workstation
R6.1.9()
{
	RN=6.1.9
	RNA="Ensure permissions on /etc/gshadow- are configured"
	. $FDIR/RF00609.sh
	RF00609
}
# End of 6.1.9 Ensure permissions on /etc/gshadow- are configured

# 6.1.10 Ensure no world writable files exist
# Scored, Level 1, Server and Workstation
R6.1.10()
{
	RN=6.1.10
	RNA="Ensure no world writable files exist"
	. $FDIR/RF00610.sh
	RF00610
}
# End of 6.1.10 Ensure no world writable files exist

# 6.1.11 Ensure no unowned files or directories exist
# Scored, Level 1, Server and Workstation
R6.1.11()
{
	RN=6.1.11
	RNA="Ensure no unowned files or directories exist"
	. $FDIR/RF00611.sh
	RF00611
}
# End of 6.1.11 Ensure no unowned files or directories exist

# 6.1.12 Ensure no ungrouped files or directories exist
# Scored, Level 1, Server and Workstation
R6.1.12()
{
	RN=6.1.11
	RNA="Ensure no ungrouped files or directories exist"
	. $FDIR/RF00612.sh
	RF00612
}
# End of 6.1.12 Ensure no ungrouped files or directories exist

# 6.1.13 Audit SUID executables
# Not Scored
R6.1.13()
{
	RN=6.1.13
	RNA="Audit SUID executables"
	NSR
}
# End of 6.1.13 Audit SUID executables

# 6.1.14 Audit SGID executables
# Not Scored
R6.1.14()
{
	RN=6.1.14
	RNA="Audit SGID executables"
	NSR
}
# End of 6.1.14 Audit SGID executables

# 6.2 User and Group Settings

# 6.2.1 Ensure password fields are not empty
# Scored, Level 1, Server and Workstation
R6.2.1()
{
	RN=6.2.1
	RNA="Ensure password fields are not empty"
	. $FDIR/RF00621.sh
	RF00621
}
# End of 6.2.1 Ensure password fields are not empty

# 6.2.2 Ensure no legacy "+" entries exist in /etc/passwd
# Scored, Level 1, Server and Workstation
R6.2.2()
{
	RN=6.2.2
	RNA="Ensure no legacy \"+\" entries exist in $SFN"
	. $FDIR/RF00622.sh
	RF00622
}
# End of 6.2.2 Ensure no legacy "+" entries exist in $SFN

# 6.2.3 Ensure no legacy "+" entries exist in /etc/shadow
# Scored, Level 1, Server and Workstation
R6.2.3()
{
	RN=6.2.3
	RNA="Ensure no legacy \"+\" entries exist in /etc/shadow"
	. $FDIR/RF00623.sh
	RF00623
}
# End of 6.2.3 Ensure no legacy "+" entries exist in /etc/shadow

# 6.2.4 Ensure no legacy "+" entries exist in /etc/group
# Scored, Level 1, Server and Workstation
R6.2.4()
{
	RN=6.2.4
	RNA="Ensure no legacy \"+\" entries exist in /etc/group"
	. $FDIR/RF00624.sh
	RF00624
}
# End of 6.2.4 Ensure no legacy "+" entries exist in /etc/group

# 6.2.5 Ensure root is the only UID 0 account
# Scored, Level 1, Server and Workstation
R6.2.5()
{
	RN=6.2.5
	RNA="Ensure root is the only UID 0 account"
	. $FDIR/RF00625.sh
	RF00625
}
# End of 6.2.5 Ensure root is the only UID 0 account

# 6.2.6 Ensure root PATH Integrity
# Scored, Level 1, Server and Workstation
R6.2.6()
{
	RN=6.2.6
	RNA="Ensure root PATH Integrity"
	. $FDIR/RF00626.sh
	RF00626
}
# End of 6.2.6 Ensure root PATH Integrity

# 6.2.7 Ensure all users' home directories exist
# Scored, Level 1, Server and Workstation
R6.2.7()
{
	RN=6.2.7
	RNA="Ensure all users' home directories exist"
	. $FDIR/RF00627.sh
	RF00627
}
# End of 6.2.7 Ensure all users' home directories exist

# 6.2.8 Ensure users' home directories permissions are 750 or more restrictive
# Scored, Level 1, Server and Workstation
R6.2.8()
{
	RN=6.2.8
	RNA="Ensure users' home directories permissions are 750 or more restrictive"
	. $FDIR/RF00628.sh
	RF00628
}
# End of 6.2.8 Ensure users' home directories permissions are 750 or more restrictive

# 6.2.9 Ensure users own their home directories
# Scored, Level 1, Server and Workstation
R6.2.9()
{
	RN=6.2.9
	RNA="Ensure users own their home directories"
	. $FDIR/RF00629.sh
	RF00629
}
# End of 6.2.9 Ensure users own their home directories

# 6.2.10 Ensure users' dot files are not group or world writable
# Scored, Level 1, Server and Workstation
R6.2.10()
{
	RN=6.2.10
	RNA="Ensure users' dot files are not group or world writable"
	. $FDIR/RF00630.sh
	RF00630
}
# End of 6.2.10 Ensure users' dot files are not group or world writable

# 6.2.11 Ensure no users have .forward files
# Scored, Level 1, Server and Workstation
R6.2.11()
{
	RN=6.2.11
	RNA="Ensure no users have .forward files"
	. $FDIR/RF00631.sh
	RF00631
}
# End of 6.2.11 Ensure no users have .forward files

# 6.2.12 Ensure no users have .netrc files
# Scored, Level 1, Server and Workstation
R6.2.12()
{
	RN=6.2.12
	RNA="Ensure no users have .netrc files"
	. $FDIR/RF00632.sh
	RF00632
}
# End of 6.2.12 Ensure no users have .netrc files

# 6.2.13 Ensure users' .netrc Files are not group or world accessible
# Scored, Level 1, Server and Workstation
R6.2.13()
{
	RN=6.2.13
	RNA="Ensure users' .netrc Files are not group or world accessible"
	. $FDIR/RF00633.sh
	RF00633
}
# End of 6.2.13 Ensure users' .netrc Files are not group or world accessible

# 6.2.14 Ensure no users have .rhosts files
# Scored, Level 1, Server and Workstation
R6.2.14()
{
	RN=6.2.14
	RNA="Ensure no users have .rhosts files"
	. $FDIR/RF00634.sh
	RF00634
}
# End of 6.2.14 Ensure no users have .rhosts files

# 6.2.15 Ensure all groups in /etc/passwd exist in /etc/group
# Scored, Level 1, Server and Workstation
R6.2.15()
{
	RN=6.2.15
	RNA="Ensure all groups in /etc/passwd exist in /etc/group"
	. $FDIR/RF00635.sh
	RF00635
}
# End of 6.2.15 Ensure all groups in /etc/passwd exist in /etc/group

# 6.2.16 Ensure no duplicate UIDs exist
# Scored, Level 1, Server and Workstation
R6.2.16()
{
	RN=6.2.16
	RNA="Ensure no duplicate UIDs exist"
	. $FDIR/RF00636.sh
	RF00636
}
# End of 6.2.16 Ensure no duplicate UIDs exist

# 6.2.17 Ensure no duplicate GIDs exist
# Scored, Level 1, Server and Workstation
R6.2.17()
{
	RN=6.2.17
	RNA="Ensure no duplicate GIDs exist"
	. $FDIR/RF00637.sh
	RF00637
}
# End of 6.2.17 Ensure no duplicate GIDs exist

# 6.2.18 Ensure no duplicate user names exist
# Scored, Level 1, Server and Workstation
R6.2.18()
{
	RN=6.2.18
	RNA="Ensure no duplicate user names exist"
	. $FDIR/RF00638.sh
	RF00638
}
# End of 6.2.18 Ensure no duplicate user names exist

# 6.2.19 Ensure no duplicate group names exist
# Scored, Level 1, Server and Workstation
R6.2.19()
{
	RN=6.2.19
	RNA="Ensure no duplicate group names exist"
	. $FDIR/RF00639.sh
	RF00639
}
# End of 6.2.19 Ensure no duplicate group names exist

# 6.2.20 Ensure shadow group is empty
# Scored, Level 1, Server and Workstation
R6.2.20()
{
	RN=6.2.20
	RNA="Ensure shadow group is empty"
	. $FDIR/RF00640.sh
	RF00640
}
# End of 6.2.20 Ensure shadow group is empty

#####################################################
# End of functions to preform Benchmark Remediation #
#####################################################

##############################
# Start of Profile Functions #
##############################

# Function for Level 1 Server Profile
FSL1()
{
	LTTM="
	R1.1.1.1
	R1.1.1.2
	R1.1.1.3
	R1.1.1.4
	R1.1.1.5
	R1.1.2
	R1.1.3
	R1.1.4
	R1.1.5
	R1.1.8
	R1.1.9
	R1.1.10
	R1.1.14
	R1.1.15
	R1.1.16
	R1.1.17
	R1.1.18
	R1.1.19
	R1.1.20
	R1.1.21
	R1.1.22
	R1.2.1
	R1.2.2
	R1.3.1
	R1.3.2
	R1.4.1
	R1.4.2
	R1.4.3
	R1.5.1
	R1.5.2
	R1.5.3
	R1.5.4
	R1.7.1.1
	R1.7.1.2
	R1.7.1.3
	R1.7.1.4
	R1.7.1.5
	R1.7.1.6
	R1.7.2
	R1.8
	R2.1.1
	R2.1.2
	R2.2.1.1
	R2.2.1.2
	R2.2.1.3
	R2.2.2
	R2.2.3
	R2.2.4
	R2.2.5
	R2.2.6
	R2.2.7
	R2.2.8
	R2.2.9
	R2.2.10
	R2.2.11
	R2.2.12
	R2.2.13
	R2.2.14
	R2.2.15
	R2.2.16
	R2.2.17
	R2.3.1
	R2.3.2
	R2.3.3
	R2.3.4
	R2.3.5
	R3.1.1
	R3.1.2
	R3.2.1
	R3.2.2
	R3.2.3
	R3.2.4
	R3.2.5
	R3.2.6
	R3.2.7
	R3.2.8
	R3.2.9
	R3.3.1
	R3.3.2
	R3.3.3
	R3.3.4
	R3.3.5
	R3.4.1
	R3.4.2
	R3.4.3
	R3.4.4
	R3.5.1.1
	R3.5.1.2
	R3.5.1.3
	R3.5.1.4
	R3.5.2.1
	R3.5.2.2
	R3.5.2.3
	R3.5.2.4
	R3.5.3
	R3.6
	R4.2.1.1
	R4.2.1.2
	R4.2.1.3
	R4.2.1.4
	R4.2.1.5
	R4.2.2.1
	R4.2.2.2
	R4.2.2.3
	R4.2.2.4
	R4.2.2.5
	R4.2.3
	R4.2.4
	R4.3
	R5.1.1
	R5.1.2
	R5.1.3
	R5.1.4
	R5.1.5
	R5.1.6
	R5.1.7
	R5.1.8
	R5.2.1
	R5.2.2
	R5.2.3
	R5.2.4
	R5.2.5
	R5.2.7
	R5.2.8
	R5.2.9
	R5.2.10
	R5.2.11
	R5.2.12
	R5.2.13
	R5.2.14
	R5.2.15
	R5.2.16
	R5.2.17
	R5.2.18
	R5.2.19
	R5.3.1
	R5.3.2
	R5.3.3
	R5.3.4
	R5.4.1.1
	R5.4.1.2
	R5.4.1.3
	R5.4.1.4
	R5.4.1.5
	R5.4.2
	R5.4.3
	R5.4.4
	R5.5
	R5.6
	R6.1.2
	R6.1.3
	R6.1.4
	R6.1.5
	R6.1.6
	R6.1.7
	R6.1.8
	R6.1.9
	R6.1.10
	R6.1.11
	R6.1.12
	R6.1.13
	R6.1.14
	R6.2.1
	R6.2.2
	R6.2.3
	R6.2.4
	R6.2.5
	R6.2.6
	R6.2.7
	R6.2.8
	R6.2.9
	R6.2.10
	R6.2.11
	R6.2.12
	R6.2.13
	R6.2.14
	R6.2.15
	R6.2.16
	R6.2.17
	R6.2.18
	R6.2.19
	R6.2.20"
	for RNBR in $(echo $LTTM)
	do
		TRN=${RNBR/R/}
		if [[ -n $(egrep "^\s*$TRN\s*$" $BDIR/exclude_recommendation.lst) ]]
		then
			WLOG "- $(date +%D-%H:%M:%S) - recommendation $TRN skipped at user request - ### Manual Remediation Required ###"
		else
			$RNBR
		fi
	done
	LTTM=""
}
# End of Function for Level 1 Server Profile

#Start of Function for Level 2 Server Profile
FSL2()
{
	LTTM="
	R1.1.1.1
	R1.1.1.2
	R1.1.1.3
	R1.1.1.4
	R1.1.1.5
	R1.1.2
	R1.1.3
	R1.1.4
	R1.1.5
	R1.1.6
	R1.1.7
	R1.1.8
	R1.1.9
	R1.1.10
	R1.1.11
	R1.1.12
	R1.1.13
	R1.1.14
	R1.1.15
	R1.1.16
	R1.1.17
	R1.1.18
	R1.1.19
	R1.1.20
	R1.1.21
	R1.1.22
	R1.2.1
	R1.2.2
	R1.3.1
	R1.3.2
	R1.4.1
	R1.4.2
	R1.4.3
	R1.5.1
	R1.5.2
	R1.5.3
	R1.5.4
	R1.6.1.1
	R1.6.1.2
	R1.6.1.3
	R1.6.1.4
	R1.6.2.1
	R1.6.2.2
	R1.6.3
	R1.7.1.1
	R1.7.1.2
	R1.7.1.3
	R1.7.1.4
	R1.7.1.5
	R1.7.1.6
	R1.7.2
	R1.8
	R2.1.1
	R2.1.2
	R2.2.1.1
	R2.2.1.2
	R2.2.1.3
	R2.2.2
	R2.2.3
	R2.2.4
	R2.2.5
	R2.2.6
	R2.2.7
	R2.2.8
	R2.2.9
	R2.2.10
	R2.2.11
	R2.2.12
	R2.2.13
	R2.2.14
	R2.2.15
	R2.2.16
	R2.2.17
	R2.3.1
	R2.3.2
	R2.3.3
	R2.3.4
	R2.3.5
	R3.1.1
	R3.1.2
	R3.2.1
	R3.2.2
	R3.2.3
	R3.2.4
	R3.2.5
	R3.2.6
	R3.2.7
	R3.2.8
	R3.2.9
	R3.3.1
	R3.3.2
	R3.3.3
	R3.3.4
	R3.3.5
	R3.4.1
	R3.4.2
	R3.4.3
	R3.4.4
	R3.5.1.1
	R3.5.1.2
	R3.5.1.3
	R3.5.1.4
	R3.5.2.1
	R3.5.2.2
	R3.5.2.3
	R3.5.2.4
	R3.5.3
	R3.6
	R3.7
	R4.1.1.1
	R4.1.1.2
	R4.1.1.3
	R4.1.2
	R4.1.3
	R4.1.4
	R4.1.5
	R4.1.6
	R4.1.7
	R4.1.8
	R4.1.9
	R4.1.10
	R4.1.11
	R4.1.12
	R4.1.13
	R4.1.14
	R4.1.15
	R4.1.16
	R4.1.17
	R4.1.18
	R4.2.1.1
	R4.2.1.2
	R4.2.1.3
	R4.2.1.4
	R4.2.1.5
	R4.2.2.1
	R4.2.2.2
	R4.2.2.3
	R4.2.2.4
	R4.2.2.5
	R4.2.3
	R4.2.4
	R4.3
	R5.1.1
	R5.1.2
	R5.1.3
	R5.1.4
	R5.1.5
	R5.1.6
	R5.1.7
	R5.1.8
	R5.2.1
	R5.2.2
	R5.2.3
	R5.2.4
	R5.2.5
	R5.2.6
	R5.2.7
	R5.2.8
	R5.2.9
	R5.2.10
	R5.2.11
	R5.2.12
	R5.2.13
	R5.2.14
	R5.2.15
	R5.2.16
	R5.2.17
	R5.2.18
	R5.2.19
	R5.3.1
	R5.3.2
	R5.3.3
	R5.3.4
	R5.4.1.1
	R5.4.1.2
	R5.4.1.3
	R5.4.1.4
	R5.4.1.5
	R5.4.2
	R5.4.3
	R5.4.4
	R5.4.5
	R5.5
	R5.6
	R6.1.1
	R6.1.2
	R6.1.3
	R6.1.4
	R6.1.5
	R6.1.6
	R6.1.7
	R6.1.8
	R6.1.9
	R6.1.10
	R6.1.11
	R6.1.12
	R6.1.13
	R6.1.14
	R6.2.1
	R6.2.2
	R6.2.3
	R6.2.4
	R6.2.5
	R6.2.6
	R6.2.7
	R6.2.8
	R6.2.9
	R6.2.10
	R6.2.11
	R6.2.12
	R6.2.13
	R6.2.14
	R6.2.15
	R6.2.16
	R6.2.17
	R6.2.18
	R6.2.19
	R6.2.20"

	for RNBR in $(echo $LTTM)
	do
		TRN=${RNBR/R/}
		if [[ -n $(egrep "^\s*$TRN\s*$" $BDIR/exclude_recommendation.lst) ]]
		then
			WLOG "- $(date +%D-%H:%M:%S) - recommendation $TRN skipped at user request - ### Manual Remediation Required ###"
		else
			$RNBR
		fi
	done
	LTTM=""	
}
# End of Function for Level 2 Server Profile

# Start of Fuction for Level 1 Workstation Profile
FWL1()
{
	LTTM="
	R1.1.1.1
	R1.1.1.2
	R1.1.1.3
	R1.1.1.4
	R1.1.1.5
	R1.1.2
	R1.1.3
	R1.1.4
	R1.1.5
	R1.1.8
	R1.1.9
	R1.1.10
	R1.1.14
	R1.1.15
	R1.1.16
	R1.1.17
	R1.1.18
	R1.1.19
	R1.1.20
	R1.1.21
	R1.2.1
	R1.2.2
	R1.3.1
	R1.3.2
	R1.4.1
	R1.4.2
	R1.4.3
	R1.5.1
	R1.5.2
	R1.5.3
	R1.5.4
	R1.7.1.1
	R1.7.1.2
	R1.7.1.3
	R1.7.1.4
	R1.7.1.5
	R1.7.1.6
	R1.7.2
	R1.8
	R2.1.1
	R2.1.2
	R2.2.1.1
	R2.2.1.2
	R2.2.1.3
	R2.2.3
	R2.2.5
	R2.2.6
	R2.2.7
	R2.2.8
	R2.2.9
	R2.2.10
	R2.2.11
	R2.2.12
	R2.2.13
	R2.2.14
	R2.2.15
	R2.2.16
	R2.2.17
	R2.3.1
	R2.3.2
	R2.3.3
	R2.3.4
	R2.3.5
	R3.1.1
	R3.1.2
	R3.2.1
	R3.2.2
	R3.2.3
	R3.2.4
	R3.2.5
	R3.2.6
	R3.2.7
	R3.2.8
	R3.2.9
	R3.3.1
	R3.3.2
	R3.3.3
	R3.3.4
	R3.3.5
	R3.4.1
	R3.4.2
	R3.4.3
	R3.4.4
	R3.5.1.1
	R3.5.1.2
	R3.5.1.3
	R3.5.1.4
	R3.5.2.1
	R3.5.2.2
	R3.5.2.3
	R3.5.2.4
	R3.5.3
	R3.6
	R4.2.1.1
	R4.2.1.2
	R4.2.1.3
	R4.2.1.4
	R4.2.1.5
	R4.2.2.1
	R4.2.2.2
	R4.2.2.3
	R4.2.2.4
	R4.2.2.5
	R4.2.3
	R4.2.4
	R4.3
	R5.1.1
	R5.1.2
	R5.1.3
	R5.1.4
	R5.1.5
	R5.1.6
	R5.1.7
	R5.1.8
	R5.2.1
	R5.2.2
	R5.2.3
	R5.2.4
	R5.2.5
	R5.2.6
	R5.2.7
	R5.2.8
	R5.2.9
	R5.2.10
	R5.2.11
	R5.2.12
	R5.2.13
	R5.2.14
	R5.2.15
	R5.2.16
	R5.2.17
	R5.2.18
	R5.2.19
	R5.3.1
	R5.3.2
	R5.3.3
	R5.3.4
	R5.4.1.1
	R5.4.1.2
	R5.4.1.3
	R5.4.1.4
	R5.4.1.5
	R5.4.2
	R5.4.3
	R5.4.4
	R5.5
	R5.6
	R6.1.2
	R6.1.3
	R6.1.4
	R6.1.5
	R6.1.6
	R6.1.7
	R6.1.8
	R6.1.9
	R6.1.10
	R6.1.11
	R6.1.12
	R6.1.13
	R6.1.14
	R6.2.1
	R6.2.2
	R6.2.3
	R6.2.4
	R6.2.5
	R6.2.6
	R6.2.7
	R6.2.8
	R6.2.9
	R6.2.10
	R6.2.11
	R6.2.12
	R6.2.13
	R6.2.14
	R6.2.15
	R6.2.16
	R6.2.17
	R6.2.18
	R6.2.19
	R6.2.20"

	for RNBR in $(echo $LTTM)
	do
		TRN=${RNBR/R/}
		if [[ -n $(egrep "^\s*$TRN\s*$" $BDIR/exclude_recommendation.lst) ]]
		then
			WLOG "- $(date +%D-%H:%M:%S) - recommendation $TRN skipped at user request - ### Manual Remediation Required ###"
		else
			$RNBR
		fi
	done
	LTTM=""
}
# End of Fuction for Level 1 Workstation Profile

# Start of Fuction for Level 2 Workstation Profile
FWL2()
{
	LTTM="
	R1.1.1.1
	R1.1.1.2
	R1.1.1.3
	R1.1.1.4
	R1.1.1.5
	R1.1.2
	R1.1.3
	R1.1.4
	R1.1.5
	R1.1.6
	R1.1.7
	R1.1.8
	R1.1.9
	R1.1.10
	R1.1.11
	R1.1.12
	R1.1.13
	R1.1.14
	R1.1.15
	R1.1.16
	R1.1.17
	R1.1.18
	R1.1.19
	R1.1.20
	R1.1.21
	R1.1.22
	R1.2.1
	R1.2.2
	R1.3.1
	R1.3.2
	R1.4.1
	R1.4.2
	R1.4.3
	R1.5.1
	R1.5.2
	R1.5.3
	R1.5.4
	R1.6.1.1
	R1.6.1.2
	R1.6.1.3
	R1.6.1.4
	R1.6.2.1
	R1.6.2.2
	R1.6.3
	R1.7.1.1
	R1.7.1.2
	R1.7.1.3
	R1.7.1.4
	R1.7.1.5
	R1.7.1.6
	R1.7.2
	R1.8
	R2.1.1
	R2.1.2
	R2.2.1.1
	R2.2.1.2
	R2.2.1.3
	R2.2.3
	R2.2.4
	R2.2.5
	R2.2.6
	R2.2.7
	R2.2.8
	R2.2.9
	R2.2.10
	R2.2.11
	R2.2.12
	R2.2.13
	R2.2.14
	R2.2.15
	R2.2.16
	R2.2.17
	R2.3.1
	R2.3.2
	R2.3.3
	R2.3.4
	R2.3.5
	R3.1.1
	R3.1.2
	R3.2.1
	R3.2.2
	R3.2.3
	R3.2.4
	R3.2.5
	R3.2.6
	R3.2.7
	R3.2.8
	R3.2.9
	R3.3.1
	R3.3.2
	R3.3.3
	R3.3.4
	R3.3.5
	R3.4.1
	R3.4.2
	R3.4.3
	R3.4.4
	R3.5.1.1
	R3.5.1.2
	R3.5.1.3
	R3.5.1.4
	R3.5.2.1
	R3.5.2.2
	R3.5.2.3
	R3.5.2.4
	R3.5.3
	R3.6
	R3.7
	R4.1.1.1
	R4.1.1.2
	R4.1.1.3
	R4.1.2
	R4.1.3
	R4.1.4
	R4.1.5
	R4.1.6
	R4.1.7
	R4.1.8
	R4.1.9
	R4.1.10
	R4.1.11
	R4.1.12
	R4.1.13
	R4.1.14
	R4.1.15
	R4.1.16
	R4.1.17
	R4.1.18
	R4.2.1.1
	R4.2.1.2
	R4.2.1.3
	R4.2.1.4
	R4.2.1.5
	R4.2.2.1
	R4.2.2.2
	R4.2.2.3
	R4.2.2.4
	R4.2.2.5
	R4.2.3
	R4.2.4
	R4.3
	R5.1.1
	R5.1.2
	R5.1.3
	R5.1.4
	R5.1.5
	R5.1.6
	R5.1.7
	R5.1.8
	R5.2.1
	R5.2.2
	R5.2.3
	R5.2.4
	R5.2.5
	R5.2.6
	R5.2.7
	R5.2.8
	R5.2.9
	R5.2.10
	R5.2.11
	R5.2.12
	R5.2.13
	R5.2.14
	R5.2.15
	R5.2.16
	R5.2.17
	R5.2.18
	R5.2.19
	R5.3.1
	R5.3.2
	R5.3.3
	R5.3.4
	R5.4.1.1
	R5.4.1.2
	R5.4.1.3
	R5.4.1.4
	R5.4.1.5
	R5.4.2
	R5.4.3
	R5.4.4
	R5.4.5
	R5.5
	R5.6
	R6.1.1
	R6.1.2
	R6.1.3
	R6.1.4
	R6.1.5
	R6.1.6
	R6.1.7
	R6.1.8
	R6.1.9
	R6.1.10
	R6.1.11
	R6.1.12
	R6.1.13
	R6.1.14
	R6.2.1
	R6.2.2
	R6.2.3
	R6.2.4
	R6.2.5
	R6.2.6
	R6.2.7
	R6.2.8
	R6.2.9
	R6.2.10
	R6.2.11
	R6.2.12
	R6.2.13
	R6.2.14
	R6.2.15
	R6.2.16
	R6.2.17
	R6.2.18
	R6.2.19
	R6.2.20"

	for RNBR in $(echo $LTTM)
	do
		TRN=${RNBR/R/}
		if [[ -n $(egrep "^\s*$TRN\s*$" $BDIR/exclude_recommendation.lst) ]]
		then
			WLOG "- $(date +%D-%H:%M:%S) - recommendation $TRN skipped at user request - ### Manual Remediation Required ###"
		else
			$RNBR
		fi
	done
	LTTM=""	
}
# End of Fuction for Level 2 Workstation Profile

############################
# End of Profile Functions #
############################