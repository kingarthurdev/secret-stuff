#!/bin/bash
######################################
# CIS Linux Build Kit (LBK) CIS-LBK  # 
# This build kit is the property of  #
# Center for Internet Security (CIS) #
######################################

############################
# CIS-LBK Global Variables #
############################

if [ ! "$BASH_VERSION" ] ; then
	    exec /bin/bash "$0" "$@"
fi

BDIR="$(dirname "$(readlink -f "$0")")"
SDIR=$BDIR/benchmarks
FDIR=$BDIR/fns
LDIR=$BDIR/logs
MDIR=$BDIR/misc
RDIR=$BDIR/backup
DTG=$(date +%m_%d_%Y_%H%M)
mkdir $LDIR/$DTG
mkdir $RDIR/$DTG
LOGDIR=$LDIR/$DTG
BKDIR=$RDIR/$DTG
LOG=$LOGDIR/CIS-LBK.log
WRNL=$LOGDIR/CIS-LBK_warrning.log
BFE=".bk.cis"
BKFL=$LOGDIR/CIS-LBK_bk_files.log
MOFL=$LOGDIR/CIS-LBK_mod_files.log

# Variables Defined in Bencmark Specific Scripts
# [[ `egrep "^\s*ID=\S+$" /etc/os-release` =~ ^\s*ID=(\"centos\"|\"rhel\"|\"al2\")\s*$ ]] && GCFL=/boot/grub2/grub.cfg # !!! This is for Fedora Family Distrobutions only
# [[ `egrep "^\s*ID=\S+$" /etc/os-release` =~ ^\s*ID=(debian|ubuntu)\s*$ ]] && GCFL=/boot/grub/grub.cfg # !!! This is for Debian Family Distros Write function to establish this variable !!!

# OSN=$(egrep "^\s*ID=\S+$" /etc/os-release | cut -d= -f2 | sed "s/\"//g")
# OSV=$(egrep "^\s*VERSION_ID=\S+\$" /etc/os-release | cut -d= -f2 | sed "s/\"//g")
# OSP=$OSN$OSV

###########################
# End of Global Variables #
###########################

#################### 
# Called Functions #
####################

# Load Called functions
. $FDIR/MLOG.sh
. $FDIR/WLOG.sh
. $FDIR/BANR.sh
. $FDIR/FBNR.sh
. $FDIR/CONFIRM.sh
. $FDIR/WARBNR.sh
. $FDIR/FDTOU.sh
. $FDIR/PLATFORM.sh
. $FDIR/ROOTUSRCK.sh
. $FDIR/FUGC.sh
. $FDIR/FLOSP.sh
. $FDIR/FFBK.sh
. $FDIR/FSCK.sh
. $FDIR/PECK.sh
. $FDIR/POCK.sh
. $FDIR/RCKSL.sh
. $FDIR/RCKSC.sh
. $FDIR/RPKGE.sh
. $FDIR/FIPKG.sh
. $FDIR/FCMGC.sh
. $FDIR/FMACDEC.sh
. $FDIR/MACTPE.sh
. $FDIR/FNSEL.sh
. $FDIR/FNAPAR.sh
. $FDIR/FWBU.sh
. $FDIR/FBFP.sh
# . $FDIR/FTADEC.sh
. $FDIR/FTSTPE.sh
. $FDIR/FTESD.sh
. $FDIR/FTDSD.sh
. $FDIR/FIPV6D.sh
. $FDIR/FIPV6S.sh
. $FDIR/FSSCP.sh
. $FDIR/FMNL.sh
. $FDIR/FSACFP.sh
. $FDIR/FCADR.sh
. $FDIR/FDLP.sh
. $FDIR/FCCDP.sh
. $FDIR/FSSHS.sh
. $FDIR/FDOSV.sh
. $FDIR/FCUMP.sh
. $FDIR/NSR.sh
. $FDIR/FPLD.sh
. $FDIR/FFBMS.sh
. $FDIR/FRELD.sh

###########################
# End of Called Functions #
###########################

########################
# Start of main script #
########################

MLOG "- $(date +%D-%H:%M:%S) - Starting - CIS-LBK"
FBNR
ROOTUSRCK # Verifies that CIS-LBK is being run by root
FDTOU
BANR 
WARBNR # Display the warning baner
FFBMS # Determine which Benchmark to run
. $BSTR
FPLD
FRELD # Runs end of script functions
MLOG "- $(date +%D-%H:%M:%S) - Completed - CIS-LBK"

######################
# End of main script #
######################
