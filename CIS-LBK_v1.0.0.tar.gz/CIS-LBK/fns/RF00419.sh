# Ensure kernel module loading and unloading is collected
RF00419()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	ARN="-w /sbin/insmod -p x -k modules"
	VRX="^\s*-w\s+\/sbin\/insmod\s+-p\s+x\s+-k\s+modules\s*(#.*)?$"
	FCADR
	ARN="-w /sbin/rmmod -p x -k modules"
	VRX="^\s*-w\s+\/sbin\/rmmod\s+-p\s+x\s+-k\s+modules\s*(#.*)?$"
	FCADR
	ARN="-w /sbin/modprobe -p x -k modules"
	VRX="^\s*-w\s+\/sbin\/modprobe\s+-p\s+x\s+-k\s+modules\s*(#.*)?$"
	FCADR
	if [[ `arch` = x86_64 ]]
	then
		ARN="-a always,exit -F arch=b64 -S init_module -S delete_module -k modules"
		VRX="^\s*-a\s+always,exit\s+-F\s+arch=b64\s+-S\s+init_module\s+-S\s+delete_module\s+-k\s+modules\s*(#.*)?$"
		FCADR
	else
		ARN="-a always,exit -F arch=b32 -S init_module -S delete_module -k modules"
		VRX="^\s*-a\s+always,exit\s+-F\s+arch=b32\s+-S\s+init_module\s+-S\s+delete_module\s+-k\s+modules\s*(#.*)?$"
		FCADR
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure kernel module loading and unloading is collected