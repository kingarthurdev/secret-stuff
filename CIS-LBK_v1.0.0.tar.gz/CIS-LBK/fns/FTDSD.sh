# Function to disable a systemd daemon
FTDSD()
{
	# RN={Recomendation Number}
	# RNA={Recomendation Name}
	# DAEN={daemon name}
	MLOG "- $(date +%D-%H:%M:%S) - Starting - Disable  \"$DAEN\""
	if [[ ! $(systemctl is-enabled $DAEN) = enabled ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - $DAEN is not enabled - Skipping"
	else
		MLOG "- $(date +%D-%H:%M:%S) - $DAEN is enabled - Remediating"
		systemctl disable $DAEN
		[[ ! $(systemctl is-enabled $DAEN) = enabled ]] && MLOG "- $(date +%D-%H:%M:%S) - $DAEN remediation successful" || WLOG "- $(date +%D-%H:%M:%S) - $DAEN remediation failed - $RN $RNA - ### Manual Remediation Required ###"
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - Disable  \"$DAEN\""
}
# End of Function to disable a systemd daemon