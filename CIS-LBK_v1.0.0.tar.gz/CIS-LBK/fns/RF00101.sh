# Ensure mounting of udf filesystems is disabled
RF00101()
{
	# RN=1.1.1.5
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	FN=udf
	FSCK
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure mounting of udf filesystems is disabled