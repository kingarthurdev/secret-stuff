# Ensure broadcast ICMP requests are ignored
RF00325()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	SPN=net.ipv4.icmp_echo_ignore_broadcasts
	SPS=1
	SPF=net.ipv4.route.flush=1
	FSSCP
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure broadcast ICMP requests are ignored