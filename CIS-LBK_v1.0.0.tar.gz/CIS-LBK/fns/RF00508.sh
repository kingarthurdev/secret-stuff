# Ensure at/cron is restricted to authorized users
RF00508()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	SFN=/etc/cron.deny
	if [[ ! -f $SFN ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - $SFN doesn't exist - Skipping"
	else
		MLOG "- $(date +%D-%H:%M:%S) - $SFN exists - remediating"
		FFBK
		rm $SFN
		[[ ! -f $SFN ]] && MLOG "- $(date +%D-%H:%M:%S) - Successful - removed $SFN" || WLOG "- $(date +%D-%H:%M:%S) - Failed - $SFN not removed - $RN $RNA - ### Manual Remediation Required ###"
	fi
	SFN=/etc/at.deny
	if [[ ! -f $SFN ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - $SFN doesn't exist - Skipping"
	else
		MLOG "- $(date +%D-%H:%M:%S) - $SFN exists - remediating"
		FFBK
		rm $SFN
		[[ ! -f $SFN ]] && MLOG "- $(date +%D-%H:%M:%S) - Successful - removed $SFN" || WLOG "- $(date +%D-%H:%M:%S) - Failed - $SFN not removed - $RN $RNA - ### Manual Remediation Required ###"
	fi
	SFN=/etc/cron.allow
	if [[ -f $SFN ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - $SFN exists - checking owner, grop, and permissions"
		if [[ -n `stat $SFN | egrep -i "^\s*Access\:\s+\(0[642]00\/-[-r][-w]-------\)\s+Uid\:\s+\(\s+0\/\s+root\)\s+Gid\:\s+\(\s+0\/\s+root\)\s*$"` ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - Owner, Group, and permissions set correctly on $SFN - Skipping"
		else
			MLOG "- $(date +%D-%H:%M:%S) - Owner, Group, and permissions not set correctly on $SFN - Remediating"
			chown root:root $SFN
			chmod og-rwx $SFN
			if [[ -n `stat $SFN | egrep -i "^\s*Access\:\s+\(0[642]00\/-[-r][-w]-------\)\s+Uid\:\s+\(\s+0\/\s+root\)\s+Gid\:\s+\(\s+0\/\s+root\)\s*$"` ]]
			then
				MLOG "- $(date +%D-%H:%M:%S) - Successful - Setting Owner, Group, and permissions on $SFN"
			else
				WLOG "- $(date +%D-%H:%M:%S) - Failed - Setting Owner, Group, and permissions on $SFN - $RN $RNA - ### Maunal Remediation Required ###"
			fi
		fi
	else
		MLOG "- $(date +%D-%H:%M:%S) - $SFN doesn't exist - creating $SFN and setting owner, grop, and permissions"
		touch $SFN
		chmod og-rwx $SFN
		chown root:root $SFN
		if [[ -f $SFN ]] && [[ -n `stat $SFN | egrep -i "^\s*Access\:\s+\(0[642]00\/-[-r][-w]-------\)\s+Uid\:\s+\(\s+0\/\s+root\)\s+Gid\:\s+\(\s+0\/\s+root\)\s*$"` ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - Successful - Creating $SFN and Setting Owner, Group, and permissions"
		else
			WLOG "- $(date +%D-%H:%M:%S) - Failed - Creating $SFN and/or Setting Owner, Group, and permissions - $RN $RNA - ### Maunal Remediation Required ###"
		fi
	fi
	SFN=/etc/at.allow
	if [[ -f $SFN ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - $SFN exists - checking owner, grop, and permissions"
		if [[ -n `stat $SFN | egrep -i "^\s*Access\:\s+\(0[642]00\/-[-r][-w]-------\)\s+Uid\:\s+\(\s+0\/\s+root\)\s+Gid\:\s+\(\s+0\/\s+root\)\s*$"` ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - Owner, Group, and permissions set correctly on $SFN - Skipping"
		else
			MLOG "- $(date +%D-%H:%M:%S) - Owner, Group, and permissions not set correctly on $SFN - Remediating"
			chown root:root $SFN
			chmod og-rwx $SFN
			if [[ -n `stat $SFN | egrep -i "^\s*Access\:\s+\(0[642]00\/-[-r][-w]-------\)\s+Uid\:\s+\(\s+0\/\s+root\)\s+Gid\:\s+\(\s+0\/\s+root\)\s*$"` ]]
			then
				MLOG "- $(date +%D-%H:%M:%S) - Successful - Setting Owner, Group, and permissions on $SFN"
			else
				WLOG "- $(date +%D-%H:%M:%S) - Failed - Setting Owner, Group, and permissions on $SFN - $RN $RNA - ### Maunal Remediation Required ###"
			fi
		fi
	else
		MLOG "- $(date +%D-%H:%M:%S) - $SFN doesn't exist - creating $SFN and setting owner, grop, and permissions"
		touch $SFN
		chmod og-rwx $SFN
		chown root:root $SFN
		if [[ -f $SFN ]] && [[ -n `stat $SFN | egrep -i "^\s*Access\:\s+\(0[642]00\/-[-r][-w]-------\)\s+Uid\:\s+\(\s+0\/\s+root\)\s+Gid\:\s+\(\s+0\/\s+root\)\s*$"` ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - Successful - Creating $SFN and Setting Owner, Group, and permissions"
		else
			WLOG "- $(date +%D-%H:%M:%S) - Failed - Creating $SFN and/or Setting Owner, Group, and permissions - $RN $RNA - ### Maunal Remediation Required ###"
		fi
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure at/cron is restricted to authorized users