# Ensure FTP Server is not enabled
RF00213()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	DAEN=vsftpd
	FTDSD
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure FTP Server is not enabled