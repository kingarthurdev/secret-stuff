# Ensure no unconfined daemons exist
RF00164()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	MACTPE # Function to ensure that the MACDEC variable is set
	if [[ ! $MACDEC = SEL ]]
	then
		FNSEL
	else
		if [[ -z `ps -eZ | egrep "initrc" | egrep -vw "tr|ps|egrep|bash|awk" | tr ':' ' ' | awk '{ print $NF }'` ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - No unconfined daemons exist - skipping"
		else
			WLOG "- $(date +%D-%H:%M:%S) - unconfined daemons exist - writting the list of unconfined daemons to the warning log - ### Manual Remediation Required ###"
			echo "- $(date +%D-%H:%M:%S) - List of unconfined daemons:" >> $WRNL
			echo "`ps -eZ | egrep "initrc" | egrep -vw "tr|ps|egrep|bash|awk" | tr ':' ' ' | awk '{ print $NF }'`" >> $WRNL
			echo "- $(date +%D-%H:%M:%S) - End of List of unconfined daemons" >> $WRNL
		fi
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure no unconfined daemons exist