# Ensure DHCP Server is not enabled
RF00209()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	DAEN=isc-dhcp-server
	FTDSD
	DAEN=isc-dhcp-server6
	FTDSD
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure DHCP Server is not enabled