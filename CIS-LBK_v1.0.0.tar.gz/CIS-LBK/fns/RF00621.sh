# Ensure password fields are not empty
RF00621()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	if [[ -z $(cat /etc/shadow | awk -F: '($2 == "" ) { print $1 " does not have a password "}') ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - Password fields are not empty - Skipping"
	else
		for UPF in $(cat /etc/shadow | awk -F: '($2 == "" ) {print $1}')
		do
			MLOG "- $(date +%D-%H:%M:%S) - $UPF does not have a password - Remediating"
			passwd -l $UPF
			[[ -n $(passwd -S $UPF | awk -F ' ' '($2 == "L" ) {print $1}') ]] && MLOG "- $(date +%D-%H:%M:%S) - Successful - User $UPF account locked" || WLOG "- $(date +%D-%H:%M:%S) - Successful - User $UPF account not locked - $RN $RNA - ### Manual Remediation Required ###"
		done
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure password fields are not empty