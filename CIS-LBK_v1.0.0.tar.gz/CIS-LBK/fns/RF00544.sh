# Ensure password hashing algorithm is SHA-512
RF00544()
{
	SFN=/etc/pam.d/common-password
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	if [[ -n `egrep -i "^\s*(password\s+)(\S+\s+)*(pam_unix\.so\s*)(\S+\s+)*(sha512\s*)(\S+\s+)*(\s+#.*)?$" $SFN` ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - password hashing algorithm is SHA-512 - Skipping"
	else
		MLOG "- $(date +%D-%H:%M:%S) - password hashing algorithm is not SHA-512 - Remediating"
		FFBK
		[[ -n `egrep -i "^\s*(password\s+)((\S+\s+)*)(pam_unix\.so\s*)((\S+\s+)*)((\S+\s+)*)(\s+#.*)?$" $SFN` ]] && sed -ri "s/^\s*(password\s+)((\S+\s+)*)(pam_unix\.so\s*)((\S+\s+)*)((\S+\s+)*)(\s+#.*)?$/\1\2\4sha512\6/" $SFN || echo "password success=1 default=ignore pam_unix.so sha512" >> $SFN
		
		if [[ -n `egrep -i "^\s*(password\s+)(\S+\s+)*(pam_unix\.so\s*)(\S+\s+)*(sha512\s*)(\S+\s+)*(\s+#.*)?$" $SFN` ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - Successful - password hashing algorithm changed to SHA-512"
			WLOG "- $(date +%D-%H:%M:%S) - $RN $RNA - ### Manual Remediation Required ###"
			WLOG "- $(date +%D-%H:%M:%S) - password hashing algorithm changed to SHA-512 - Please run \`cat /etc/passwd | awk -F: '( $3 >= 1000 && $1 != "nfsnobody" ) { print $1 }' | xargs -n 1 chage -d 0\` to expire passwords not using the SHA-512 algorithm."
			WLOG "- $(date +%D-%H:%M:%S) - Any system accounts that need to be expired should be carefully done separately by the system administrator to prevent any potential problems."
		else
			WLOG "- $(date +%D-%H:%M:%S) - Failed - password hashing algorithm not changed to SHA-512 - $RN $RNA - ### Manual Remediation Required ###"
		fi
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure password hashing algorithm is SHA-512