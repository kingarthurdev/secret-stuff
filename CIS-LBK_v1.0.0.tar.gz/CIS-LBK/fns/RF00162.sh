# Ensure the SELinux state is enforcing
# This will only work for a Debian Family Distrobution
RF00162()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	MACTPE # Function to ensure that the MACDEC variable is set
	if [[ ! $MACDEC = SEL ]]
	then
		FNSEL
	else
		if [[ -n `grep -i SELINUX=enforcing /etc/selinux/config` ]] && [[ -n `selinux | egrep "^SELinux\s+status\:\s+enabled\s*$"` ]] && [[ -n `selinux | egrep "^Current\s+mode\:\s+enforcing\s*$"` ]] && [[ -n `selinux | egrep "^Mode\s+from\s+config\s+file\:\s+enforcing\s*$"` ]] && [[ -n `egrep "^GRUB_CMDLINE_LINUX=\".*(\benforcing=1\b).*\"\s*$" /etc/dfeault/grub` ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - SELinux state is enforcing - Skipping"
		else
			MLOG "- $(date +%D-%H:%M:%S) - SELinux state is not enforcing - Remediating"
			SFN=/etc/selinux/config
			MLOG "- $(date +%D-%H:%M:%S) -Starting - Checking $SFN"
			if [[ -n `grep -i SELINUX=enforcing $SFN` ]]
			then
				MLOG "- $(date +%D-%H:%M:%S) - SELinux is set to enforcing in $SFN - skipping"
			else
				MLOG "- $(date +%D-%H:%M:%S) - SELinux is not set to enforcing in $SFN - updating $SFN"
				FFBK
				[[ -n `egrep "^SELINUX=\S+\s*$" $SFN` ]] && sed -ri "s/^(\s*)(SELINUX=)(\S+)(\s*)$/\1\2enforcing/" $SFN || echo "SELINUX=enforcing" >> $SFN
				[[ -n `grep -i SELINUX=enforcing $SFN` ]] && MLOG "- $(date +%D-%H:%M:%S) - set SELINUX to enforcing in $SFN successful" || WLOG "- $(date +%D-%H:%M:%S) - ### WARNING ### - failed to set SELINUX to enforcing in $SFN - ### Manual Remediation Required ###"
			fi
			MLOG "- $(date +%D-%H:%M:%S) - Completed - Checking $SFN"
			SFN=/etc/default/grub
			MLOG "- $(date +%D-%H:%M:%S) -Starting - Checking $SFN"
			if [[ -n $(egrep "^GRUB_CMDLINE_LINUX=\".*(\benforcing=1\b).*\"\s*$" $SFN) ]] && [[ -z $(egrep "^GRUB_CMDLINE_LINUX_DEFAULT=\".*(\benforcing=[0-9]\b).*\"\s*$" $SFN) ]]
			then 
				MLOG "- $(date +%D-%H:%M:%S) - SELinux is set to enforcing in $SFN - skipping"
			else
				MLOG "- $(date +%D-%H:%M:%S) - SELinux is not set to enforcing in $SFN - Adding options to $SFN"
				FFBK
				[[ -n `egrep "^GRUB_CMDLINE_LINUX=\".*(\benforcing=0\b).*\"\s*$" $SFN` ]] && sed -ri "s/^(GRUB_CMDLINE_LINUX=\")(.*)(\benforcing=[0,1]\b)(.*)(\")\s*$/\1\2enforcing=1 \4\5/" $SFN || sed -ri "s/^(GRUB_CMDLINE_LINUX=\")(.*)(\")\s*$/\1enforcing=1 \2\3/" $SFN
				[[ -n `egrep "^GRUB_CMDLINE_LINUX_DEFAULT=\".*(\benforcing=[0-9]\b).*\"\s*$" $SFN` ]] && sed -ri "s/^(GRUB_CMDLINE_LINUX_DEFAULT=\")(.*)(\benforcing=[0-9]\b)(.*)(\")\s*$/\1\2\4\5/" $SFN
				[[ -n `egrep "^GRUB_CMDLINE_LINUX=\".*(\benforcing=1\b).*\"\s*$" $SFN` ]] && MLOG "- $(date +%D-%H:%M:%S) - enforcing=1 successfully added to $SFN" || WLOG "- $(date +%D-%H:%M:%S) - ### WARNING ### - adding enforcing=1 to $SFN failed - ### Manual Remediation Required ###"
				MLOG "- $(date +%D-%H:%M:%S) - Completed - Adding options to $SFN - Setting flag to update grub(2) configuration"
#				MLOG "- $(date +%D-%H:%M:%S) - Starting - update the grub2 configuration"
#				if [[ $OSN =~ (debian|ubuntu) ]]
#				then
#					update-grub
#				elif [[ $OSN =~ (rhel|centos|al2) ]]
#				then
#					grub2-mkconfig -o /boot/grub2/grub.cfg
#				else
#					WLOG "- $(date +%D-%H:%M:%S) - Unable to update grub(2) configuration - $RN $RNA - ### Manual Remediation Required ###"
#				fi
#				MLOG "- $(date +%D-%H:%M:%S) - Completed - update the grub2 configuration"
#				FUGC
				UG2C=y
			fi
			MLOG "- $(date +%D-%H:%M:%S) - Completed - Checking $SFN"
		fi
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure the SELinux state is enforcing