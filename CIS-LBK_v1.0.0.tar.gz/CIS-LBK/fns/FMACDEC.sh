# Function to determine Mandatory Access Control Decision
FMACDEC()
{
	# Sub function to determine which MAC to install
	FMACCH()
	{
		clear
		echo "  Neither AppArmor or SELinux is installed on this system"
		echo "  Please select which Mandatory Access Control (MAC) you would like installed"
		echo ""
		echo "  Please enter 1 for AppArmor"
		echo "  Please enter 2 for SELinux"
		echo "  Please enter 0 if you don't want either MAC Installed"
#		echo "  : "
		echo ""
		read -p " : " -r
		#$REPLY
#		read ANSR
#		case $ANSR in
		case $REPLY in
			1 ) 
				clear
				MLOG "- $(date +%D-%H:%M:%S) - you responded with $ANSR - AppArmor will be installed"
				MACCH=APAR
				sleep 2
				;;
			2 )
				clear
				MLOG "- $(date +%D-%H:%M:%S) - you responded with $ANSR - SELinux will be installed"
				MACCH=SEL
				sleep 2
				;;
			0 )
				clear
				WLOG "- $(date +%D-%H:%M:%S) - you responded with $ANSR - No MAC will be installed - ### Manual Remediation Required ### -"
				MACCH=NONE
				sleep 2
				;;
			* )
				clear
				WLOG "- $(date +%D-%H:%M:%S) - you responded with $ANSR - Please Respond with 1, 2, or 0 "
				sleep 2
				;;
		esac
	}
	# End of sub function to determine which MAC to install
	
	if [[ $(dpkg -s apparmor | grep Status) = "Status: install ok installed" ]] && [[ $(dpkg -s apparmor-utils | grep Status) = "Status: install ok installed" ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - AppArmor is already installed on your system - No MAC decisssion required"
		MACDEC=APAR
	elif [[ $(dpkg -s selinux-basics | grep Status) = "Status: install ok installed" ]] && [[ $(dpkg -s selinux-policy-default | grep Status) = "Status: install ok installed" ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - SELinux is already installed on your system - No MAC decisssion required"
		MACDEC=SEL
	else
		MLOG "- $(date +%D-%H:%M:%S) - Neither AppArmor or SELinux is installed - Choice of which one to install required"
		[[ $(dpkg -s apparmor | grep Status) = "Status: install ok installed" ]] && MACCH=APAR
		[[ $(dpkg -s selinux-basics | grep Status) = "Status: install ok installed" ]] && MACCH=SEL
		while [[ -z $MACCH ]]
		do
			FMACCH
		done
		case $MACCH in
			APAR )
				MLOG "- $(date +%D-%H:%M:%S) - User selected to install AppArmor - Installing AppArmor"
				PNA=apparmor
				PNA2=apparmor-utils
				# PNA3={Third Package Name}
				# PNA4={Fourth Package Name}
				FIPKG
				if [[ `dpkg -s apparmor | grep Status` = "Status: install ok installed" ]]
				then
					MLOG "- $(date +%D-%H:%M:%S) - AppArmor install successful"
					MACDEC=APAR
				else
					WLOG "- $(date +%D-%H:%M:%S) - AppArmor install Not Successful - ### Manual Remediation Required ###" 
					MACDEC=NONE
				fi
				;;
			SEL )
				MLOG "- $(date +%D-%H:%M:%S) - User selected to install SELinux - Installing SELinux"
				PNA=selinux-basics
				PNA2=selinux-policy-default
				# PNA3={Third Package Name}
				# PNA4={Fourth Package Name}
				FIPKG
				if [[ `dpkg -s selinux-basics | grep Status` = "Status: install ok installed" ]]
				then
					MLOG "- $(date +%D-%H:%M:%S) - SELinux install successful"
					MACDEC=SEL
				else
					WLOG "- $(date +%D-%H:%M:%S) - SELinux install Not Successful - ### Manual Remediation Required ###"
					MACDEC=NONE
				fi
				;;
			NONE )
				# Manual Remediation Required for Manditory Access Control Recomendations
				WLOG "- $(date +%D-%H:%M:%S) - User selected to not install AppArmor of SELinux - ### Manual Remediation Required ###"
				MACDEC=NONE
				;;
			* )
				FMACCH
				;;
		esac
	fi
}
# End of Function to determine Mandatory Access Control Decision