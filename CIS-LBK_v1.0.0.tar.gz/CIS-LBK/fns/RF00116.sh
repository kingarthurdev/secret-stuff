# Ensure nosuid option set on /dev/shm partition
RF00116()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	SMPN=dev/shm
	OPN=nosuid
	POCK
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure nosuid option set on /dev/shm partition