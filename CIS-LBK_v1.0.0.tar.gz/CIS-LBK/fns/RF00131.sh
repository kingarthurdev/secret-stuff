# Ensure AIDE is installed
RF00131()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	if [[ `dpkg -s aide | grep Status` = "Status: install ok installed" ]]
	then 
		MLOG "- $(date +%D-%H:%M:%S) - AIDE is installed - no remediation required, skipping"
	else
		MLOG "- $(date +%D-%H:%M:%S) - AIDE is not installed - Remediating"
		PNA=aide
		PNA2=aide-common
		FIPKG
		IAIDE=y
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure AIDE is installed