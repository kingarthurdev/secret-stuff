# Ensure loopback traffic is configured
RF00352()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	[[ -n `iptables -L INPUT -v -n | egrep -i "^\s*0\s+0\s+ACCEPT\s+all\s+\-\-\s+lo\s+\*\s+0\.0\.0\.0\/0\s+0\.0\.0\.0\/0\s*$"` ]] && MLOG "- $(date +%D-%H:%M:%S) - INPUT ACCEPT configured - Skipping" || iptables -A INPUT -i lo -j ACCEPT
	[[ -n `iptables -L INPUT -v -n | egrep -i "^\s*0\s+0\s+DROP\s+all\s+\-\-\s+\*\s+\*\s+127\.0\.0\.0\/8\s+0\.0\.0\.0\/0\s*$"` ]] && MLOG "- $(date +%D-%H:%M:%S) - INPUT DROP configured - Skipping" || iptables -A INPUT -s 127.0.0.0/8 -j DROP
	[[ -n `iptables -L OUTPUT -v -n | egrep -i "^\s*0\s+0\s+ACCEPT\s+all\s+\-\-\s+\*\s+lo\s+0\.0\.0\.0\/0\s+0\.0\.0\.0\/0\s*$"` ]] && MLOG "- $(date +%D-%H:%M:%S) - OUTPUT ACCEPT configured - Skipping" || iptables -A OUTPUT -o lo -j ACCEPT
	if [[ -n `iptables -L INPUT -v -n | egrep -i "^\s*0\s+0\s+ACCEPT\s+all\s+\-\-\s+lo\s+\*\s+0\.0\.0\.0\/0\s+0\.0\.0\.0\/0\s*$"` ]] && [[ -n `iptables -L INPUT -v -n | egrep -i "^\s*0\s+0\s+DROP\s+all\s+\-\-\s+\*\s+\*\s+127\.0\.0\.0\/8\s+0\.0\.0\.0\/0\s*$"` ]] && [[ -n `iptables -L OUTPUT -v -n | egrep -i "^\s*0\s+0\s+ACCEPT\s+all\s+\-\-\s+\*\s+lo\s+0\.0\.0\.0\/0\s+0\.0\.0\.0\/0\s*$"` ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - Remediation Successful for $RN $RNA"
	else
		WLOG "- $(date +%D-%H:%M:%S) - Remediation Failed for $RN $RNA - ### Manual Remediation Required ###"
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure loopback traffic is configured