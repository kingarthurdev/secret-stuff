# Ensure rsyslog default file permissions configured
RF00423()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	FDLP # Determins which logging package is being used
	if [[ ! $LCPH = RSL ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - rsyslog is not being used on this system - Skipping"
	else
		SFN=/etc/rsyslog.conf
		MLOG "- $(date +%D-%H:%M:%S) - Starting - Checking $SFN for \$FileCreateMode 0640"
		if [[ -n `egrep "^\s*\S+FileCreateMode\s+0[6420][40]0\s*(\s+#.*)?$" $SFN` ]] && [[ -z `egrep "^\s*#\s*\S+FileCreateMode\s+0[6420][40]0\s*(\s+#.*)?$" $SFN` ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - \$FileCreateMode 0640 set in $SFN"
		else
			MLOG "- $(date +%D-%H:%M:%S) - \$FileCreateMode 0640 not set in $SFN - Remediating"
			FFBK
			[[ -n `egrep "^(\s*)(\S+FileCreateMode\s+)([0-9]{4})(\s*(#.*))?$" $SFN` ]] && [[ -z `egrep "^(\s*)(#\s*)(\S+FileCreateMode\s+)([0-9]{4})(\s*(#.*))?$" $SFN` ]] && sed -ri "s/^(\s*)(\S+FileCreateMode\s+)([0-9]{4})(\s*(#.*))?$/\1\20640\4/" $SFN || echo "\$FileCreateMode 0640" >> $SFN
			[[ -n `egrep "^\s*\S+FileCreateMode\s+0[6420][40]0\s*(\s+#.*)?$" $SFN` ]] && [[ -z `egrep "^\s*#\s*\S+FileCreateMode\s+0[6420][40]0\s*(\s+#.*)?$" $SFN` ]] && MLOG "- $(date +%D-%H:%M:%S) - \$FileCreateMode 0640 set in $SFN - Remediation Successful" || WLOG "- $(date +%D-%H:%M:%S) - \$FileCreateMode 0640 not set in $SFN - Remediation Failed - ### Manual Remediation Required ###"
		fi
		MLOG "- $(date +%D-%H:%M:%S) - Completed - Checking $SFN for \$FileCreateMode 0640"
		if [[ -n `ls /etc/rsyslog.d/*.conf` ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - Starting - Checking /etc/rsyslog.d/*.conf for \$FileCreateMode 0640"
			for SFN in `ls /etc/rsyslog.d/*.conf`
			do
				if [[ -n `egrep "^\s*\S+FileCreateMode\s+0[6420][40]0\s*(\s+#.*)?$" $SFN` ]] && [[ -z `egrep "^\s*#\s*\S+FileCreateMode\s+0[6420][40]0\s*(\s+#.*)?$" $SFN` ]]
				then
					MLOG "- $(date +%D-%H:%M:%S) - \$FileCreateMode 0640 set in $SFN"
				else
					MLOG "- $(date +%D-%H:%M:%S) - \$FileCreateMode 0640 not set in $SFN - Remediating"
					FFBK
					[[ -n `egrep "^(\s*)(\S+FileCreateMode\s+)([0-9]{4})(\s*(#.*))?$" $SFN` ]] && [[ -z `egrep "^(\s*)(#\s*)(\S+FileCreateMode\s+)([0-9]{4})(\s*(#.*))?$" $SFN` ]] && sed -ri "s/^(\s*)(\S+FileCreateMode\s+)([0-9]{4})(\s*(#.*))?$/\1\20640\4/" $SFN || echo "\$FileCreateMode 0640" >> $SFN
					[[ -n `egrep "^\s*\S+FileCreateMode\s+0[6420][40]0\s*(\s+#.*)?$" $SFN` ]] && [[ -z `egrep "^\s*#\s*\S+FileCreateMode\s+0[6420][40]0\s*(\s+#.*)?$" $SFN` ]] && MLOG "- $(date +%D-%H:%M:%S) - \$FileCreateMode 0640 set in $SFN - Remediation Successful" || WLOG "- $(date +%D-%H:%M:%S) - \$FileCreateMode 0640 not set in $SFN - Remediation Failed - ### Manual Remediation Required ###"
				fi
			done
			MLOG "- $(date +%D-%H:%M:%S) - Completed - Checking /etc/rsyslog.d/*.conf for \$FileCreateMode 0640"
		else
			MLOG "- $(date +%D-%H:%M:%S) - no *.conf files exist in /etc/rsyslog.d/ - skipping"
		fi
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure rsyslog default file permissions configured