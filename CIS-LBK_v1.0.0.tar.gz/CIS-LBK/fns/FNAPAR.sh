# Function for MAC not AppArmor
FNAPAR()
{
	case $MACDEC in
		SEL )
			MLOG "- $(date +%D-%H:%M:%S) - SELinux is installed - $RN $RNA not required - skipping"
			;;
		NONE )
			WLOG "- $(date +%D-%H:%M:%S) - User selected to not install a MAC, or install of MAC failed - ### Manual Remediation Required ### for $RN $RNA"
			;;
		* )
			FMACTPE
			;;
	esac
}
# End of Function for MAC not AppArmor