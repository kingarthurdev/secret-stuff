# Function to check and modify /etc/security/limits.conf and /etc/security/limits.d/*
RCKSL()
{
	# RN={Recomendation Number}
	# RNA={Recomendation Name}
	OPU="\*" # If OPU needs to be something other than "*" need to fix this function
	# OPU={Option User (*|root|etc) (if * = \*)}
	# OPL={Option Level (soft|hard)}
	# OPN={Option Name (core)}
	# OPS={Option Setting (0|1|2)}

	MLOG "- $(date +%D-%H:%M:%S) - Starting - Checking /etc/security/limits.conf"
	if [[ -n `egrep "^(\s*)$OPU\s+$OPL\s+$OPN\s+$OPS\s*$" /etc/security/limits.conf` ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - $RNA configured in /etc/security/limits.conf, skipping"
	else
		MLOG "- $(date +%D-%H:%M:%S) - $RNA not configured in /etc/security/limits.conf - Checking files in /etc/security/limits.d"
		if [[ -n `egrep -r "^(\s*)$OPU\s+$OPL\s+$OPN\s+$OPS\s*$" /etc/security/limits.d` ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - $RNA configured in a /etc/security/limits.d/* file, skipping"
		else
			MLOG "- $(date +%D-%H:%M:%S) - $RNA not configured in /etc/security/limits.d/* - Configuring $RNA in /etc/security/limits.conf"
			[[ ! -s /etc/security/limits.conf.bk.cis ]] && MLOG "- $(date +%D-%H:%M:%S) - ### Creating backup ### of /etc/security/limits.conf as /etc/security/limits.conf.bk.cis" && cp /etc/security/limits.conf /etc/security/limits.conf.bk.cis || MLOG "- $(date +%D-%H:%M:%S) - Backup of /etc/security/limits.conf already exists as /etc/security/limits.conf.bk.cis, skipping creation of backup"
			egrep -q "^(\s*)$OPU\s+$OPL\s+$OPN\s+\S+(\s*#.*)?\s*$" /etc/security/limits.conf && sed -ri "s/^(\s*)$OPU\s+$OPL\s+$OPN\s+\S+(\s*#.*)?\s*$/\1* $OPL $OPN $OPS\2/" /etc/security/limits.conf || echo "* $OPL $OPN $OPS" >> /etc/security/limits.conf
			[[ -n `egrep -r "^(\s*)$OPU\s+$OPL\s+$OPN\s+$OPS\s*$" /etc/security/limits.d` ]] && MLOG "- $(date +%D-%H:%M:%S) - $RNA successfully configured in /etc/security/limits.conf" || WLOG "- $(date +%D-%H:%M:%S) - configuring core dumps in /etc/security/limits.conf failed ### Manual Remediation Required ### for 1.5.1 Ensure core dumps are restricted"
		fi
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - Checking /etc/security/limits.conf"
}
# End of Function to check and modify /etc/security/limits.conf and /etc/security/limits.d/*