# Ensure all users last password change date is in the past
RF00549()
{
	PON="last password change date"
	PORX="^\s*Last\s+password\s+change\s+\:\s*(\S+\s*)+(\s+#.*)?$"
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	for MPD in $(egrep ^[^:]+:[^\!*] /etc/shadow | cut -d: -f1)
	do
		DTE=$(chage --list $MPD | egrep -i "$PORX" | cut -d: -f2 | tr -d ",")
		DTE=$(date "+%s" -d "$DTE")
		if [[ $DTE > $(date +%s) ]]
		then
			WLOG "- $(date +%D-%H:%M:%S) - User $MPD $PON is $(date -d @$DTE) - $RN $RNA - ### Manual Remediation Required ###"
		else
			MLOG "- $(date +%D-%H:%M:%S) - User $MPD $PON is $(date -d @$DTE) - Skipping"
		fi
	done
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure all users last password change date is in the past