# Ensure iptables is installed
RF00357()
{
	PNA=iptables
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	FIPKG
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure iptables is installed