# Ensure logging is configured
RF00422()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	FDLP # Determins which logging package is being used
	if [[ ! $LCPH = RSL ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - rsyslog is not being used on this system - Skipping"
	else
		NSR
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure logging is configured