# Ensure remote login warning banner is configured properly
RF00173()
{
	SFN=/etc/issue.net
	BNA="remote login warning banner"
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	FWBU
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure remote login warning banner is configured properly