# Function to set a parameter in the auditd config file /etc/auditd.conf
FSACFP()
{
	# APN={Auditd Config File Parameter Name}
	# APS={Auditd Configfile Parameter Setting }
	# SFN={Source File Name}
	MLOG "- $(date +%D-%H:%M:%S) - Checking $APN"
	if [[ -n `egrep -i "^\s*$APN\s*\=\s*$APS\b.*$" $SFN` ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - $APN already configured - skipping"
	else
		MLOG "- $(date +%D-%H:%M:%S) - $APN not configured"
		MLOG "- $(date +%D-%H:%M:%S) -Starting - Update $APN in $SFN"
		FFBK
		[[ -n `egrep -i "(^s*)($APN\s*=\s*)(\S+\b)(.*)$" $SFN` ]] && sed -ri "s/(^s*)($APN\s*=\s*)(\S+\b)(.*)$/\1\2$APS\4/" $SFN || echo "$APN = $APS" >> $SFN
		[[ -n `egrep -i "^\s*$APN\s*\=\s*$APS\b.*$" $SFN` ]] && MLOG "- $(date +%D-%H:%M:%S) - Successful - updating - APN in $SFN" || WLOG "- $(date +%D-%H:%M:%S) - Failed - updating - $APN in $SFN - ### Manual Remediation Required ###"
		MLOG "- $(date +%D-%H:%M:%S) - Completed - Update $APN in $SFN"
	fi
}
# End of Function to set a parameter in the auditd config file /etc/auditd.conf