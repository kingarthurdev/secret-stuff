# Ensure NFS and RPC are not enabled
RF00211()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	DAEN=nfs-server
	FTDSD
	DAEN=rpcbind
	FTDSD
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure NFS and RPC are not enabled