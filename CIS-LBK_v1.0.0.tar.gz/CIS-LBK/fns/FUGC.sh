# Function to update the Grub(2) configuration
FUGC()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - update the grub2 configuration"
	if [[ $OSN =~ (debian|ubuntu) ]]
	then
		update-grub
	elif [[ $OSN =~ (rhel|centos|al2) ]]
	then
		grub2-mkconfig -o /boot/grub2/grub.cfg
	else
		WLOG "- $(date +%D-%H:%M:%S) - Unable to update grub(2) configuration - $RN $RNA - ### Manual Remediation Required ###"
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - update the grub2 configuration"
	#UG2C=y
}
# End of  Function to update the Grub(2) configuration