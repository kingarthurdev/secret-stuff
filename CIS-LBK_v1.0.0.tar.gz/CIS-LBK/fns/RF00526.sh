# Ensure SSH X11 forwarding is disabled
RF00526()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	SPN=X11Forwarding
	SPS=no
	FSSHS
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure SSH X11 forwarding is disabled