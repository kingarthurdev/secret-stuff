# Ensure syslog-ng default file permissions configured
RF00429()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	FDLP # Determins which logging package is being used
	if [[ ! $LCPH = SLN ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - syslog-ng is not being used on this system - Skipping"
	else
		SFN=/etc/syslog-ng/syslog-ng.conf
		if 	[[ -n `egrep "^\s*options\s+\{\s*(\S+;\s*)*perm\(0[6420][40]0\);\s*(\S+;\s*)*\};\s*(\s+#.*)?$" $SFN` ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - perm option is 0640 or more restrictive - Skipping"
		else
			MLOG "- $(date +%D-%H:%M:%S) - perm option is not 0640 or more restrictive - Remediating"
			FFBK
			[[ -n `egrep "^\s*options\s+\{\s*(\S+;\s*)*perm\([0-9]{4});\s*(\S+;\s*)*\};\s*(\s+#.*)?$" $SFN` ]] && sed -ri "s/^(\s*options\s+\{\s*(\S+;\s*)*)(perm\([0-9]{4});\s*)((\S+;\s*)*\};\s*(\s+#.*)?)$/\1 perm(0640); \3/" $SFN || echo "options { chain_hostnames(off); flush_lines(0); perm(0640); stats_freq(3600); threaded(yes); };" >> $SFN
			[[ -n `egrep "^\s*options\s+\{\s*(\S+;\s*)*perm\(0[6420][40]0\);\s*(\S+;\s*)*\};\s*(\s+#.*)?$" $SFN` ]] && MLOG "- $(date +%D-%H:%M:%S) - Remediation Successful" || WLOG "- $(date +%D-%H:%M:%S) - Remediation Failed - $RN $RNA - ### Manual Remediation Required ###"
		fi
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure syslog-ng default file permissions configured