# Function to display the CIS Linux Build Kit Bannor
FBNR()
{
	clear
	echo ""
	echo ""
	echo ""
	echo "_________________________________________________________________________"
	echo ""
	echo "  .d8888b.  8888888  .d8888b.         888         d8888888b.   888   d8Y"
	echo " d88P  Y88b   888   d88P  Y88b        888         888    Y8b   888  d8Y"
	echo " 888    888   888   Y88b.             888         888    d88   888 d8Y"
	echo " 888          888     Y888b.    8888  888         888888Y8P    888d8Y"
	echo " 888          888        Y88b.  8888  888         8888888b.    888Y8b"
	echo " 888    888   888          888        888         888    Y8b   888 Y8b"
	echo " Y88b  d88P   888   Y88b  d88P        888         888    d88   888  Y8b"
 	echo " .Y8888PY   8888888   Y8888PY         Y88888888   Y8888888Y    888   Y8b"
	echo "_________________________________________________________________________"
	echo ""
	echo "_________________________________________________________________________"
	echo ""
	echo "                         CIS Linux Build Kit                             "
	echo "                         Version 1.0.0 Beta                              "
	echo "                         May 2019                                        "
	echo "_________________________________________________________________________"
	echo ""
	sleep 7
}
# End of Function to display the CIS Linux Build Kit Bannor