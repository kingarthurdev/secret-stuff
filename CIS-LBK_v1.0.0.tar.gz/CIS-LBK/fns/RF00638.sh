# Ensure no duplicate user names exist
RF00638()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	cat /etc/passwd | cut -f1 -d":" | sort -n | uniq -c | while read x
	do
		[ -z "${x}" ] && break
		set - $x
		if [ $1 -gt 1 ]
		then
			UIDS=$(awk -F: '($1 == n) { print $3 }' n=$2 /etc/passwd | xargs)
			WLOG "Duplicate User Name ($2): ${UIDS} - $RN $RNA - ### Manual Remediation Required ###"
		fi
	done
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure no duplicate user names exist