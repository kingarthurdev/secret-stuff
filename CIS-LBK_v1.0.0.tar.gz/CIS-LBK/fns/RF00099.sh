# Ensure mounting of hfs filesystems is disabled
RF00099()
{
	# RN=1.1.1.3
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	FN=hfs
	FSCK
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure mounting of hfs filesystems is disabled