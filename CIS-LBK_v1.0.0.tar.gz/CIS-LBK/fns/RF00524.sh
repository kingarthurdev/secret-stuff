# Ensure SSH Protocol is set to 2
RF00524()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	SFN=/etc/ssh/sshd_config
	if [[ -n `egrep -i "^Protocol\s+2\s*(\s+#.*)?$" $SFN` ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - \"Protocol 2\" - set in $SFN - Skipping"
	else
		MLOG "- $(date +%D-%H:%M:%S) - \"Protocol 2\" - not set in $SFN - Remediating"
		[[ -n `egrep -i "^(\s*)(Protocol\s+)([0-9])\s*((\s+#.*)?)$" $SFN` ]] && sed -ri "s/^(\s*)($SFN\s+)([0-9])\s*((\s+#.*)?)$/\22\4/" $SFN || echo "Protocol 2" >> $SFN
		[[ -n `egrep -i "^Protocol\s+2\s*(\s+#.*)?$" $SFN` ]] && MLOG "- $(date +%D-%H:%M:%S) - Successful - setting \"Protocol 2\" in $SFN" ||  WLOG "- $(date +%D-%H:%M:%S) - Failed - setting \"Protocol 2\" in $SFN - $RN $RNA - ### Manual Remediation Required"
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure SSH Protocol is set to 2