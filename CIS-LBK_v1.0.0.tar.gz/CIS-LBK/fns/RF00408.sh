# Ensure events that modify the system's network environment are collected
RF00408()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	if [[ $(arch) = x86_64 ]]
	then
		ARN="-a always,exit -F arch=b64 -S sethostname -S setdomainname -k system-locale"
		VRX="^\s*-a\s+always,exit\s+-F\s+arch=b64\s+-S\s+sethostname\s+-S\s+setdomainname\s+-k\s+system-locale\s*(#.*)?$"
		FCADR
	fi
	ARN="-a always,exit -F arch=b32 -S sethostname -S setdomainname -k system-locale"
	VRX="^\s*-a\s+always,exit\s+-F\s+arch=b32\s+-S\s+sethostname\s+-S\s+setdomainname\s+-k\s+system-locale\s*(#.*)?$"
	FCADR
	ARN="-w /etc/issue -p wa -k system-locale"
	VRX="^\s*-w\s+\/etc\/issue\s+-p\s+wa\s+-k\s+system-locale\s*(#.*)?$"
	FCADR
	ARN="-w /etc/issue.net -p wa -k system-locale"
	VRX="^\s*-w\s+\/etc\/issue.net\s+-p\s+wa\s+-k\s+system-locale\s*(#.*)?$"
	FCADR
	ARN="-w /etc/hosts -p wa -k system-locale"
	VRX="^\s*-w\s+\/etc\/hosts\s+-p\s+wa\s+-k\s+system-locale\s*(#.*)?$"
	FCADR
	ARN="-w /etc/network -p wa -k system-locale"
	VRX="^\s*-w\s+\/etc\/network\s+-p\s+wa\s+-k\s+system-locale\s*(#.*)?$"
	FCADR
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure events that modify the system's network environment are collected