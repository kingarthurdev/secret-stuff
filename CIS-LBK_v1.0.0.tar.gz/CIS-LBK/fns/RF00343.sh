# Ensure RDS is disabled
RF00343()
{
	FN=rds
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	FMNL
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure RDS is disabled
