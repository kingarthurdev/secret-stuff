# Ensure password creation requirements are configured
RF00541()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	MLOG "- $(date +%D-%H:%M:%S) - Starting - Insure that  the pam_pwquality module is installed"
	PNA=libpam-pwquality
	FIPKG
	MLOG "- $(date +%D-%H:%M:%S) - Completed - Insure that  the pam_pwquality module is installed"
	if [[ $(dpkg -s $PNA | grep Status) = "Status: install ok installed" ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - Starting - verify all password requirements conform to organization policy"
		SFN=/etc/pam.d/common-password	
		PPN=retry # PAM Parameter Name
		PPS=\[1-3\] # PAM Parmaeter "acceptable" Settings
		PPSR=3 # PAM Parameter Recomended setting
		MLOG "- $(date +%D-%H:%M:%S) - Starting - check $PPN"
#		if [[ -n `egrep -i "^\s*$PPN\s*\=\s*$PPS\s*(\s+#.*)?$" $SFN` ]]
		if [[ -n $(egrep -i "^\s*password\s+requisite\s+pam_pwquality\.so\s+retry\=$PPS\s*(\s+\S+\s*)*$" $SFN) ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - $PPN is set correctly in $SFN - Skipping"
		else
			MLOG "- $(date +%D-%H:%M:%S) - $PPN is not set correctly in $SFN - Remediating"
			FFBK
			[[ -n $(egrep -i "^\s*(password\s+)(requisite|required|sufficient)(\s+pam_pwquality\.so\b)(.*)$" $SFN) ]] && sed -ri "^\s*(password\s+)(requisite|required|sufficient)(\s+pam_pwquality\.so\b)(.*)$/\1\requisite\3\4 $PPN=$PPSR/" $SFN || echo "password requisite pam_pwquality.so $PPN=$PPSR" >> $SFN
			[[ -n $(egrep -i "^\s*password\s+requisite\s+pam_pwquality\.so\s+$PPN\=$PPSR\s*(\s+\S+\s*)*$" $SFN) ]] && MLOG "- $(date +%D-%H:%M:%S) - Successful - Updating $SFN with $PPN=$PPSR" || WLOG "- $(date +%D-%H:%M:%S) - Failed - Updating $SFN with $PPN=$PPSR - $RN $RNA - ### Manual Remediation Required ###"
		fi
		MLOG "- $(date +%D-%H:%M:%S) - Completed - check $PPN"
		# SFN=/etc/security/pwquality.conf
		PPN=minlen # PAM Parameter Name
		PPS="[1-9][4-9]" # PAM Parmaeter "acceptable" Settings
		PPSR=14 # PAM Parameter Recomended setting
		MLOG "- $(date +%D-%H:%M:%S) - Starting - check $PPN"
		FCUMP
		MLOG "- $(date +%D-%H:%M:%S) - Completed - check $PPN"
		PPN=dcredit # PAM Parameter Name
		PPS="-[1-9]" # PAM Parmaeter "acceptable" Settings
		PPSR="-1" # PAM Parameter Recomended setting
		MLOG "- $(date +%D-%H:%M:%S) - Starting - check $PPN"
		FCUMP
		MLOG "- $(date +%D-%H:%M:%S) - Completed - check $PPN"
		PPN=lcredit # PAM Parameter Name
		PPS="-[1-9]" # PAM Parmaeter "acceptable" Settings
		PPSR="-1" # PAM Parameter Recomended setting
		MLOG "- $(date +%D-%H:%M:%S) - Starting - check $PPN"
		FCUMP
		MLOG "- $(date +%D-%H:%M:%S) - Completed - check $PPN"
		PPN=ocredit # PAM Parameter Name
		PPS="-[1-9]" # PAM Parmaeter "acceptable" Settings
		PPSR="-1" # PAM Parameter Recomended setting
		MLOG "- $(date +%D-%H:%M:%S) - Starting - check $PPN"
		FCUMP
		MLOG "- $(date +%D-%H:%M:%S) - Completed - check $PPN"
		PPN=ucredit # PAM Parameter Name
		PPS="-[1-9]" # PAM Parmaeter "acceptable" Settings
		PPSR="-1" # PAM Parameter Recomended setting
		MLOG "- $(date +%D-%H:%M:%S) - Starting - check $PPN"
		FCUMP
		MLOG "- $(date +%D-%H:%M:%S) - Completed - check $PPN"
		MLOG "- $(date +%D-%H:%M:%S) - Completed - verify all password requirements conform to organization policy"
	else
		WLOG "- $(date +%D-%H:%M:%S) - $PNA not installed - $RN $RNA - ### Manual Remediation Required ###"
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure password creation requirements are configured