# Ensure telnet client is not installed
RF00234()
{
	PNA=telnet
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	RPKGE
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure telnet client is not installed