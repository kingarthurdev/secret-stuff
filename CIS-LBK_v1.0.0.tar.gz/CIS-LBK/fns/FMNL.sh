# Function to check if a Module is disabled
FMNL()
{
	# RN={Remediation Number}
	# RNA={Remediation Name}
	# FN={Module Name}
	#if [[ -n `]]
	[[ -z $(modprobe -n -v $FN | egrep "^\s*install\s+\/bin\/true.$") ]] && MLOG "- $(date +%D-%H:%M:%S) - Remediating $RN.1 - Ensure kernel module is not loadable" && echo "install $FN /bin/true" >> /etc/modprobe.d/$FN.conf || MLOG "- $(date +%D-%H:%M:%S) - $RN.1 Ensure kernel module is not loadable already complient - skiping"
	[[ -n $(lsmod | grep $FN) ]] && MLOG "- $(date +%D-%H:%M:%S) - Remediating $RN.2 Ensure kernel module $FN is not loaded" && rmmod $FN || MLOG "- $(date +%D-%H:%M:%S) - $RN.2 Ensure kernel module $FN is not loaded already complient - skipping"
}
# End of Function to check if a Module is disabled