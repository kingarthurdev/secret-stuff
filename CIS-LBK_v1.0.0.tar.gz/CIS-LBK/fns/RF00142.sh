# Ensure bootloader password is set
RF00142()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	if [[ -n `grep "^set superusers" /boot/grub/grub.cfg` ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - bootloader password is set - skipping"
	else
		WLOG "- $(date +%D-%H:%M:%S) - $RN $RNA - ### Manual Remediation Required ###"
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure bootloader password is set