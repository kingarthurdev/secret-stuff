# Ensure ntp is configured
RF00204()
{
	SFN=/etc/ntp.conf
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	# FTSTPE # Function to ensure that the TSPDEC variable is set
	if [[ ! `dpkg -s ntp | grep Status` = "Status: install ok installed" ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - ntp is not installed - no configuration required - Skipping"
	else
		MLOG "- $(date +%D-%H:%M:%S) - checking restrictions in $SFN"
		if [[ -n `egrep -i "^\s*restrict\b\s+(-4\s+|\s*)\bdefault\b\s+(\bkod\b|\bnomodify\b|\bnotrap\b|\bnopeer\b|\bnoquery\b)(\s+|\s*\b\S+\b\s*|\s*)(\bkod\b|\bnomodify\b|\bnotrap\b|\bnopeer\b|\bnoquery\b)(\s+|\s*\b\S+\b\s*|\s*)(\bkod\b|\bnomodify\b|\bnotrap\b|\bnopeer\b|\bnoquery\b)(\s+|\s*\b\S+\b\s*|\s*)(\bkod\b|\bnomodify\b|\bnotrap\b|\bnopeer\b|\bnoquery\b)(\s+|\s*\b\S+\b\s*|\s*)(\bkod\b|\bnomodify\b|\bnotrap\b|\bnopeer\b|\bnoquery\b).*$" $SFN` ]] && [[ -n `egrep -i "^\s*restrict\b\s+(-6\s+)\bdefault\b\s+(\bkod\b|\bnomodify\b|\bnotrap\b|\bnopeer\b|\bnoquery\b)(\s+|\s*\b\S+\b\s*|\s*)(\bkod\b|\bnomodify\b|\bnotrap\b|\bnopeer\b|\bnoquery\b)(\s+|\s*\b\S+\b\s*|\s*)(\bkod\b|\bnomodify\b|\bnotrap\b|\bnopeer\b|\bnoquery\b)(\s+|\s*\b\S+\b\s*|\s*)(\bkod\b|\bnomodify\b|\bnotrap\b|\bnopeer\b|\bnoquery\b)(\s+|\s*\b\S+\b\s*|\s*)(\bkod\b|\bnomodify\b|\bnotrap\b|\bnopeer\b|\bnoquery\b).*$" $SFN` ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - restrictions are set in $SFN"
		else
			MLOG "- $(date +%D-%H:%M:%S) - restrictions are not set in $SFN - remediating"
			FFBK
			[[ -n `egrep -i "^\s*restrict\b\s+(-4\s+|\s*)\bdefault\b.*$" $SFN` ]] && sed -ri "s/^(\s*)(restrict\s+)(-4\s+|\s*)(default)(.*)$/\1\2\3\4 kod nomodify notrap nopeer noquery\5/" $SFN || echo "restrict -4 default kod nomodify notrap nopeer noquery" >> $SFN
			[[ -n `egrep -i "^\s*restrict\b\s+(-6\s+)\bdefault\b.*$" $SFN` ]] && sed -ri "s/^(\s*)(restrict\s+)(-6\s+)(default)(.*)$/\1\2\3\4 kod nomodify notrap nopeer noquery\5/" $SFN || echo "restrict -6 default kod nomodify notrap nopeer noquery" >> $SFN
			if [[ -n `egrep -i "^\s*restrict\b\s+(-4\s+|\s*)\bdefault\b\s+(\bkod\b|\bnomodify\b|\bnotrap\b|\bnopeer\b|\bnoquery\b)(\s+|\s*\b\S+\b\s*|\s*)(\bkod\b|\bnomodify\b|\bnotrap\b|\bnopeer\b|\bnoquery\b)(\s+|\s*\b\S+\b\s*|\s*)(\bkod\b|\bnomodify\b|\bnotrap\b|\bnopeer\b|\bnoquery\b)(\s+|\s*\b\S+\b\s*|\s*)(\bkod\b|\bnomodify\b|\bnotrap\b|\bnopeer\b|\bnoquery\b)(\s+|\s*\b\S+\b\s*|\s*)(\bkod\b|\bnomodify\b|\bnotrap\b|\bnopeer\b|\bnoquery\b).*$" $SFN` ]] && [[ -n `egrep -i "^\s*restrict\b\s+(-6\s+)\bdefault\b\s+(\bkod\b|\bnomodify\b|\bnotrap\b|\bnopeer\b|\bnoquery\b)(\s+|\s*\b\S+\b\s*|\s*)(\bkod\b|\bnomodify\b|\bnotrap\b|\bnopeer\b|\bnoquery\b)(\s+|\s*\b\S+\b\s*|\s*)(\bkod\b|\bnomodify\b|\bnotrap\b|\bnopeer\b|\bnoquery\b)(\s+|\s*\b\S+\b\s*|\s*)(\bkod\b|\bnomodify\b|\bnotrap\b|\bnopeer\b|\bnoquery\b)(\s+|\s*\b\S+\b\s*|\s*)(\bkod\b|\bnomodify\b|\bnotrap\b|\bnopeer\b|\bnoquery\b).*$" $SFN` ]]
			then
				MLOG "- $(date +%D-%H:%M:%S) - Successfully set restrictions in $SFN"
			else
				WLOG "- $(date +%D-%H:%M:%S) - Failed to set restrictions in $SFN - ### MANUAL REMEDIATION REQUIRED ###"
			fi
		fi
		MLOG "- $(date +%D-%H:%M:%S) - checking remote server is configured in $SFN"
		[[ -n $(egrep "^(server|pool)\s+\S+.*$" $SFN) ]] && MLOG "- $(date +%D-%H:%M:%S) - A remote server is configured in $SFN" || WLOG "- $(date +%D-%H:%M:%S) - A remote server is not configured in $SFN - ### Manual Remediation Required ###"
		MLOG "- $(date +%D-%H:%M:%S) - checking - ntp is configured to run as the ntp user"
		if [[ -n `egrep "^\s*RUNASUSER\s*=\s*ntp\s*(?:#.*)?$" /etc/init.d/ntp` ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - ntp is configured to run as the ntp user"
		else
			MLOG "- $(date +%D-%H:%M:%S) - ntp is configured to run as the ntp user - remediating"
			SFN=/etc/init.d/ntp
			FFBK
			[[ -n `egrep "^\s*RUNASUSER\s*=.*$" $SFN` ]] && sed -ri "s/(^\s*)(RUNASUSER\s*=\s*)(.*)$/\1\2ntp/" $SFN || echo "RUNASUSER=ntp" >> $SFN
			[[ -n `egrep "^\s*RUNASUSER\s*=\s*ntp\s*(?:#.*)?$" $SFN` ]] && MLOG "- $(date +%D-%H:%M:%S) - Successfully set RUNASUSER in $SFN" || WLOG "- $(date +%D-%H:%M:%S) - Failed to set RUNASUSER in $SFN - ### Manual Remediation Required ###"
		fi
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure ntp is configured