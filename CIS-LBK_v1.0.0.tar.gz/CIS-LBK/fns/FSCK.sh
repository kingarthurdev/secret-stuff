# Function to check if a filesystem is disabled
FSCK()
{
	# RN={Remediation Number}
	# FN={Filesystem Name}
#	MLOG "- $(date +%D-%H:%M:%S) - Starting $RN - Ensure mounting of $FN filesystem is disabled"
	MLOG "- $(date +%D-%H:%M:%S) - Starting - check mounting of $FN filesystem is disabled"
	[[ -z `modprobe -n -v $FN | egrep "^\s*install\s+\/bin\/true.$"` ]] && MLOG "- $(date +%D-%H:%M:%S) - kernel module for $FN is loadable - Remediating" && echo "install $FN /bin/true" >> /etc/modprobe.d/$FN.conf || MLOG "- $(date +%D-%H:%M:%S) - kernel module for $FN is not loadable - Skiping"
	[[ -n `lsmod | grep $FN` ]] && MLOG "- $(date +%D-%H:%M:%S) - kernel module for $FN is loaded - Remediating" && rmmod $FN || MLOG "- $(date +%D-%H:%M:%S) - kernel module for $FN is not loaded - Skipping"
	MLOG "- $(date +%D-%H:%M:%S) - Completed - check mounting of $FN filesystem is disabled"
#	MLOG "- $(date +%D-%H:%M:%S) - Item $RN Ensure mounting of $FN filesystem is disabled complete"
}
# End of Function to check if a filesystem is disabled