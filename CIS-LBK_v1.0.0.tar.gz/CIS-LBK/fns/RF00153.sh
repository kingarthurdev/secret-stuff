# Ensure address space layout randomization (ASLR) is enabled
RF00153()
{
	OPN=kernel.randomize_va_space
	OPS=2
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	RCKSC
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure address space layout randomization (ASLR) is enabled