# Ensure SSH IgnoreRhosts is enabled
RF00528()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	SPN=IgnoreRhosts
	SPS=yes
	FSSHS
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure SSH IgnoreRhosts is enabled