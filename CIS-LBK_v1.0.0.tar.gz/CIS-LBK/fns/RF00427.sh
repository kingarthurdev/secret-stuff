# Ensure syslog-ng service is enabled
RF00427()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	FDLP # Determins which logging package is being used
	if [[ ! $LCPH = SLN ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - syslog-ng is not being used on this system - Skipping"
	else
		DAEN=syslog-ng
		FTESD
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure syslog-ng service is enabled