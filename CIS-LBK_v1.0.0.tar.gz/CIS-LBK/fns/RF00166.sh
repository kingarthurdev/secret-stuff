# Ensure all AppArmor Profiles are enforcing
RF00166()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	MACTPE # Function to ensure that the MACDEC variable is set
	if [[ ! $MACDEC = APAR ]]
	then
		FNAPAR
	else
		if [[ -n `apparmor_status | egrep -i "^\s*0\s+processes\s+are\s+in\s+complain\s+mode\s*[\.\s*]\s*$"` ]] && [[ -n `apparmor_status | egrep -i "^\s*0\s+processes\s+are\s+unconfined\s+but\s+have\s+a\s+profile\s+defined\s*[\.\s*]\s*$"` ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - All AppArmor Profiles are enforcing - Skipping"
		else
			MLOG "- $(date +%D-%H:%M:%S) - Not all AppArmor Profiles are enforcing - Remediating"
			aa-enforce /etc/apparmor.d/*
			if [[ -n `apparmor_status | egrep -i "^\s*0\s+processes\s+are\s+in\s+complain\s+mode\s*[\.\s*]\s*$"` ]] && [[ -n `apparmor_status | egrep -i "^\s*0\s+processes\s+are\s+unconfined\s+but\s+have\s+a\s+profile\s+defined\s*[\.\s*]\s*$"` ]]
			then
				MLOG "- $(date +%D-%H:%M:%S) - Remediation of $RN $RNA Successful"
			else
				WLOG "- $(date +%D-%H:%M:%S) - Remediation of $RN $RNA failed - ### Manual Remediation Required ###"
			fi
		fi
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure all AppArmor Profiles are enforcing