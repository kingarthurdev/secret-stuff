# Ensure packet redirect sending is disabled
RF00302()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	SPN=net.ipv4.conf.all.send_redirects
	SPS=0
	SPF=net.ipv4.route.flush=1
	FSSCP
	SPN=net.ipv4.conf.default.send_redirects
	SPS=0
	SPF=net.ipv4.route.flush=1
	FSSCP
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure packet redirect sending is disabled