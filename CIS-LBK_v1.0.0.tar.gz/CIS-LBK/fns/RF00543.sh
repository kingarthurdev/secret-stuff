# Ensure password reuse is limited
RF00543()
{
	SFN=/etc/pam.d/common-password
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	if [[ -n `egrep -i "^\s*password\s+required\s+pam_pwhistory\.so\s+.*\bremember=([5-9]|[1-9][0-9]+)\b.*$" $SFN` ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - password reuse is limited - Skipping"
	else
		MLOG "- $(date +%D-%H:%M:%S) - password reuse is not limited - Remediating"
		FFBK
		if [[ -n `egrep -i "^\s*password\s+\S+\s+pam_pwhistory\.so\s+.*$" $SFN` ]]
		then
			if [[ -n $(egrep -i "^\s*(password)\s+(\S+)\s+(pam_pwhistory\.so)\s+(.*)(\bremember=\S+\b)(.*)$" $SFN) ]]
			then
				sed -ri "s/^\s*(password)\s+(\S+)\s+(pam_pwhistory\.so)\s+(.*)(\bremember=\S+\b)(.*)$/\1 required\3 \4remember=5 \6/" $SFN
			else
				sed -ri "s/^\s*(password)\s+(\S+)\s+(pam_pwhistory\.so)\s+(.*)$/\1 required \2 remember=5 \4/" $SFN
			fi
#			sed -ri "s/^(\s*password\s+)(\S+)(\s+pam_pwhistory\.so\s+)(\S+|\s*)(\s+#.*)?$/\1required\3remember=5\5/" $SFN
		else
#			echo "password required pam_pwhistory.so remember=5" >> $SFN
			sed -ri '$s/^/password required pam_pwhistory.so remember=5\n/' $SFN
		fi
		if [[ -n `egrep -i "^\s*password\s+required\s+pam_pwhistory\.so\s+remember=([5-9]|[1-9][0-9]+)" $SFN` ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - Successful - password reuse is limited"
		else
			WLOG WLOG "- $(date +%D-%H:%M:%S) - Failed - password reuse is not limited - $RN $RNA - ### Manual Remediation Required ###"
		fi
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure password reuse is limited