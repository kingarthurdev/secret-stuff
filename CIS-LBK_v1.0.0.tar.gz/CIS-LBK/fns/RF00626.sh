# Ensure root PATH Integrity
RF00626()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	MLOG "- $(date +%D-%H:%M:%S) - Starting - Checking for Empty Directory in PATH"
	if [[ ! $(echo $PATH | grep :: ) = "" ]]
	then
		WLOG "- $(date +%D-%H:%M:%S) - Empty Directory in PATH (::) - $RN $RNA - ### Manual Remediation Required ###"
	else
		MLOG "- $(date +%D-%H:%M:%S) - No empty Directory in PATH"
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - Checking for Empty Directory in PATH"
	MLOG "- $(date +%D-%H:%M:%S) - Starting - Checking Trailing : in PATH"
	if [[ ! $(echo $PATH | grep :$) = "" ]]
	then
		WLOG "- $(date +%D-%H:%M:%S) - Trailing : in PATH - $RN $RNA - ### Manual Remediation Required ###"
	else
		MLOG "- $(date +%D-%H:%M:%S) - No trailing : in PATH"
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - Checking Trailing : in PATH"
	PVAR=$(echo $PATH | sed -e 's/::/:/' -e 's/:$//' -e 's/:/ /g')
	for i in $(echo $PVAR)
	do
		MLOG "- $(date +%D-%H:%M:%S) - Starting - Checking for PATH contains ."
		if [[ $i = "." ]]
		then
			WLOG "- $(date +%D-%H:%M:%S) - PATH contains . - $RN $RNA - ### Manual Remediation Required ###"
		fi
		MLOG "- $(date +%D-%H:%M:%S) - Completed - Checking for PATH contains ."
		if [[ -d $i ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - Starting - Checking for  Group Write permission set on directory \"$i\""
			DIRPERM=$(ls -ldH $i | cut -f1 -d" ")			
			if [[ ! $(echo $DIRPERM | cut -c6) = "-" ]]
			then
				MLOG "- $(date +%D-%H:%M:%S) - Group Write permission set on directory \"$i\" - Remediating"
				SFN=$i
				FLOSP
				chmod go-w $i
				if [[ $(echo $(ls -ldH $i | cut -f1 -d" ") | cut -c6) = "-" ]]
				then
					MLOG "- $(date +%D-%H:%M:%S) - Successful - Group Write permission removed from directory \"$i\""
				else
					WLOG "- $(date +%D-%H:%M:%S) - Failed - Group Write permission set on directory \"$i\" - $RN $RNA - ### Manual Remediation Required ###"
				fi
			else
				MLOG "- $(date +%D-%H:%M:%S) - Group Write permission not set on directory \"$i\" - skipping"
			fi
			MLOG "- $(date +%D-%H:%M:%S) - Completed - Checking for  Group Write permission set on directory"
			MLOG "- $(date +%D-%H:%M:%S) - Starting - Checking for Other Write permission set on directory"
			if [[ ! $(echo $(ls -ldH $i | cut -f1 -d" ") | cut -c9) = "-" ]]
			then
				MLOG "- $(date +%D-%H:%M:%S) - Other Write permission set on directory \"$i\" - Remediating"
				SFN=$i
				FLOSP
				chmod go-w $i
				if [[ $(echo $(ls -ldH $i | cut -f1 -d" ") | cut -c9) = "-" ]]
				then
					MLOG "- $(date +%D-%H:%M:%S) - Successful - Other Write permission removed from directory \"$i\""
				else
					WLOG "- $(date +%D-%H:%M:%S) - Failed - Other Write permission set on directory \"$i\" - $RN $RNA - ### Manual Remediation Required ###"
				fi
			else
				MLOG "- $(date +%D-%H:%M:%S) - Other Write permission not set on directory \"$i\" - skipping"
			fi
			MLOG "- $(date +%D-%H:%M:%S) - Completed - Checking for Other Write permission set on directory"
			MLOG "- $(date +%D-%H:%M:%S) - Starting - Checking if directory is not owned by root"
			DIROWN=$(ls -ldH $i | awk '{print $3}')			
			if [[ ! $DIROWN = "root" ]]
			then
				MLOG "- $(date +%D-%H:%M:%S) - \"$i\" is not owned by root - Remediating"
				SFN=$i
				FLOSP
				chown root $i
				if [[ $(ls -ldH $i | awk '{print $3}') = "root" ]]
				then
					MLOG "- $(date +%D-%H:%M:%S) - Successful - \"$i\" is owned by root"
				else
					WLOG "- $(date +%D-%H:%M:%S) - Failed - \"$i\" is owned by $(ls -ldH $i | awk '{print $3}') - $RN $RNA - ### Manual Remediation Required ###"
				fi
			fi
			MLOG "- $(date +%D-%H:%M:%S) - Completed - Checking if directory is not owned by root"
		else
			MLOG "- $(date +%D-%H:%M:%S) - \"$i\" is not a directory - Skipping"
		fi
	done
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure root PATH Integrity