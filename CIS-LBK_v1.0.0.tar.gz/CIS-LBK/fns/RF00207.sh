# Ensure Avahi Server is not enabled
RF00207()
{
	DAEN=avahi-daemon
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	FTDSD
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure Avahi Server is not enabled