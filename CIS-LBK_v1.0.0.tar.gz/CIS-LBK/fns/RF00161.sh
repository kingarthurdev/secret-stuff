# Ensure SELinux is enabled in the bootloader configuration
# This will only work for a Debian Family Distrobution - Updated Should work with all distros
RF00161()
{
	# !!! Need to update to leverage "new" grub parameter check/update function !!! - done
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	MACTPE # Function to ensure that the MACDEC variable is set
	if [[ ! $MACDEC = SEL ]]
	then
		FNSEL
	else
#		if [[ -n `egrep -q "^(GRUB_CMDLINE_LINUX=\")(.*\bselinux=1\b.*\bsecurity=selinux\b.*\benforcing=1\b.*|.*\bselinux=1\b.*\benforcing=1\b.*\bsecurity=selinux\b.*|.*\bsecurity=selinux\b.*\benforcing=1\b.*\bselinux=1\b.*|.*\bsecurity=selinux\b.*\bselinux=1\b.*\benforcing=1\b.*|.*\benforcing=1\b.*\bsecurity=selinux\b.*\bselinux=1\b.*|.*\benforcing=1\b.*\bselinux=1\b.*\bsecurity=selinux\b.*)(\")" ]]
		if [[ -n `egrep "^GRUB_CMDLINE_LINUX=\".*(\bselinux=1\b).*\"\s*$" $GCFL` ]] && [[ -n `egrep "^GRUB_CMDLINE_LINUX=\".*(\bsecurity=selinux\b).*\"\s*$" $GCFL` ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - SELinux is enabled in the bootloader - skipping"
		elif [[ -n `egrep "^GRUB_CMDLINE_LINUX_DEFAULT=\".*(\bselinux=1\b).*\"\s*$" $GCFL` ]] && [[ -n `egrep "^GRUB_CMDLINE_LINUX_DEFAULT=\".*(\bsecurity=selinux\b).*\"\s*$" $GCFL` ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - SELinux is enabled in the bootloader - skipping"
		else
			MLOG "- $(date +%D-%H:%M:%S) - SELinux is not enabled in the bootloader - Remediating"
			SFN=$GCFL
			FFBK
			SFN=/etc/default/grub
			FFBK
			MLOG "- $(date +%D-%H:%M:%S) - Starting - Activating SELinux"
			selinux-activate
			MLOG "- $(date +%D-%H:%M:%S) - Completed - Activating SELinux"
			MLOG "- $(date +%D-%H:%M:%S) - Starting - Adding options to $SFN"
			# Check and add enforcing=1
			[[ -n `egrep "^GRUB_CMDLINE_LINUX=\".*(\benforcing=0\b).*\"\s*$" $SFN` ]] && sed -ri "s/^(GRUB_CMDLINE_LINUX=\")(.*)(\benforcing=[0,1]\b)(.*)(\")\s*$/\1\2enforcing=1 \4\5/" $SFN || sed -ri "s/^(GRUB_CMDLINE_LINUX=\")(.*)(\")\s*$/\1enforcing=1 \2\3/" $SFN
			[[ -n `egrep "^GRUB_CMDLINE_LINUX_DEFAULT=\".*(\benforcing=[0-9]\b).*\"\s*$" $SFN` ]] && sed -ri "s/^(GRUB_CMDLINE_LINUX_DEFAULT=\")(.*)(\benforcing=[0-9]\b)(.*)(\")\s*$/\1\2\4\5/" $SFN
			[[ -n `egrep "^GRUB_CMDLINE_LINUX=\".*(\benforcing=1\b).*\"\s*$" $SFN` ]] && MLOG "- $(date +%D-%H:%M:%S) - enforcing=1 successfully added to $SFN" || WLOG "- $(date +%D-%H:%M:%S) - ### WARNING ### - adding enforcing=1 to $SFN failed - ### Manual Remediation Required ###"
			# Check and add security=selinux
			[[ -n `egrep "^(GRUB_CMDLINE_LINUX=\")(.*)(\bsecurity=\S+\b)(.*)(\")\s*$" $SFN` ]] && sed -ri "s/^(GRUB_CMDLINE_LINUX=\")(.*)(\bsecurity=\S+\b)(.*)(\")\s*$/\1security=selinux \2\4\5/" $SFN || sed -ri "s/^(GRUB_CMDLINE_LINUX=\")(.*)(\")\s*$/\1security=selinux \2\3/"
			[[ -n `egrep "^GRUB_CMDLINE_LINUX_DEFAULT=\".*(\bsecurity=\S+\b).*\"\s*$" $SFN` ]] && sed -ri "s/^(GRUB_CMDLINE_LINUX=\")(.*)(\bsecurity=\S+\b)(.*)(\")\s*$/\1\2\4\5/" $SFN
			[[ -n `egrep "^GRUB_CMDLINE_LINUX=\".*(\bsecurity=selinux\b).*\"\s*$" /etc/dfeault/grub` ]] && MLOG "- $(date +%D-%H:%M:%S) - security=selinux successfully added to $SFN" || WLOG "- $(date +%D-%H:%M:%S) - ### WARNING ### - adding security=selinux to $SFN failed - ### Manual Remediation Required ###"
			# Check and add selinux=1
			[[ -n `egrep "^GRUB_CMDLINE_LINUX=\".*(\bselinux=0\b).*\"\s*$" $SFN` ]] && sed -ri "s/^(GRUB_CMDLINE_LINUX=\")(.*)(\bselinux=[0,1]\b)(.*)(\")\s*$/\1\2selinux=1 \4\5/" $SFN || sed -ri "s/^(GRUB_CMDLINE_LINUX=\")(.*)(\")\s*$/\1selinux=1 \2\3/" $SFN
			[[ -n `egrep "^GRUB_CMDLINE_LINUX_DEFAULT=\".*(\bselinux=[0-9]\b).*\"\s*$" $SFN` ]] && sed -ri "s/^(GRUB_CMDLINE_LINUX_DEFAULT=\")(.*)(\bselinux=[0-9]\b)(.*)(\")\s*$/\1\2\4\5/" $SFN
			[[ -n `egrep "^GRUB_CMDLINE_LINUX=\".*(\bselinux=1\b).*\"\s*$" $SFN` ]] && MLOG "- $(date +%D-%H:%M:%S) - selinux=1 successfully added to $SFN" || WLOG "- $(date +%D-%H:%M:%S) - ### WARNING ### - adding selinux=1 to $SFN failed - ### Manual Remediation Required ###"
			MLOG "- $(date +%D-%H:%M:%S) - Completed - Adding options to $SFN"
#			MLOG "- $(date +%D-%H:%M:%S) - Setting Flag to update the grub2 configuration when remediation is complete"
			FUGC
#			UG2C=y
		fi
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure SELinux is enabled in the bootloader configuration