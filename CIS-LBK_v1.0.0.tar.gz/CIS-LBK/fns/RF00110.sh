# Ensure noexec option set on /var/tmp partition
RF00110()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	SMPN=var/tmp
	OPN=noexec
	POCK
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure nosuid option set on /var/tmp partition