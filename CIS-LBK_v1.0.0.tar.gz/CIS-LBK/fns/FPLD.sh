# Function to determine Profile to run
FPLD()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - profile decision"
	# Sub Function for profile decision
	SFUPD()
	{
		clear
		echo ""
		echo " Which profile would you like to run?"
		echo ""
		echo " Please enter 1 for Server Level 1 "
		echo " Please enter 2 for Server Level 2"
		echo " Please enter 3 for Workstation Level 1"
		echo " Please enter 4 for Workstation Level 2"
		echo " Please enter Q to exit"
		echo ""
		#echo " : "
		#read UPD
		read -p " : " -r
		#$REPLY
	}
	# End of Sub Function for profile decision

	# Sub Function to set PLD variable
	SFPLD()
	{
		while [[ ! $REPLY =~ (1|2|3|4|q|Q) ]]
		do
			SFUPD
		done
		UPD=$(echo $REPLY | tr [A-Z] [a-z])
		case $UPD in
			1 )
				MLOG "- $(date +%D-%H:%M:%S) - Server Level 1 Selected - Running Sever Level 1 Remediation"
				sleep 2
				PLD=SL1
				;;
			2 ) 
				MLOG "- $(date +%D-%H:%M:%S) - Server Level 2 Selected - Running Sever Level 2 Remediation"
				sleep 2
				PLD=SL2
				;;
			3 )
				MLOG "- $(date +%D-%H:%M:%S) - Workstation Level 1 Selected - Running Workstation Level 1 Remediation"
				sleep 2
				PLD=WL1
				;;
			4 )
				MLOG "- $(date +%D-%H:%M:%S) - Workstation Level 2 Selected - Running Workstation Level 2 Remediation"
				sleep 2
				PLD=WL2
				;;
			q )
				MLOG "- $(date +%D-%H:%M:%S) - exit select - Exiting"
				sleep 2
				exit 0
				;;
			* )
				MLOG "- $(date +%D-%H:%M:%S) - Incorrect or no selection made.  Please select \"1, 2, 3 ,4, or Q\""
				sleep 2
				SFUPD
				;;
		esac
	}
	# End of Sub Function to set PLD variable
	while [[ -z $PLD ]]
	do
		SFPLD
	done
	MLOG "- $(date +%D-%H:%M:%S) - Completed - profile decision"
	case $PLD in
		SL1 )
			FSL1
			;;
		SL2 )
			FSL2
			;;
		WL1 )
			FWL1
			;;
		WL2 )
			FWL2
			;;
		* )
			SFUPD
			;;
	esac
}
# End of Function to determine Profile to run