# Function to create file backup if required
FFBK()
{
	# SFN={Absolute Path to Source File} (File to be backed up)
	# BFE={Backup File Extention} (Set as a Global Variable)
	# BKDIR={Full path to the backup directory in CIS-LRK file structure}
	# BKFL={Backed-up files logfile}
	
	FNA=$(echo $SFN | awk -F/ '{print $NF}')
	if [[ -s $BKDIR/$FNA$BFE.orig ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - Backup of original $SFN alread exists as $BKDIR/$FNA$BFE.orig - Skipping Backup original file"
	else
		MLOG "- $(date +%D-%H:%M:%S) - Creating backup of original $SFN as $SFN$BFE.orig"
		cp $SFN $BKDIR/$FNA$BFE.orig
		[[ -s $BKDIR/$FNA$BFE.orig ]] && MLOG "- $(date +%D-%H:%M:%S) - $SFN successfully backed up as $BKDIR/$FNA$BFE.orig" || WLOG "- $(date +%D-%H:%M:%S) - ### WARNING ### - Backup of original $SFN failed"
		if [[ ! -s $BKFL ]]
		then
			echo "- CIS-LRK Backed-up Files Log -" >> $BKFL
			echo "- This log contans the names of files backed up by the CIS-LRK -" >> $BKFL
			echo "- Files ending in .orig are copies of the files before being modified by CIS-LRK -" >> $BKFL
			echo "- Files ending in numbers are copies of the file made before  being updated -" >> $BKFL
			echo "- by the corrasponding recomendation -" >> $BKFL
			echo ""
			echo "- For example: file ending in _1.1.1.5 is a copy of the file before recomendation -" >> $BKFL
			echo "- 1.1.1.5 modified the file -" >> $BKFL
			echo "" >> $BKFL
		else
			echo "- $(date +%D-%H:%M:%S) - original of $SFN backed-up as $BKDIR/$FNA$BFE.org" >> $BKFL
		fi
	fi
	if [[ -s $BKDIR/$FNA$BFE_$RN ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - Backup of $SFN prior to - $RN $RNA - already exists - skipping"
	else
		cp $SFN $BKDIR/$FNA$BFE_$RN
		[[ -s $BKDIR/$FNA$BFE_$RN ]] && MLOG "- $(date +%D-%H:%M:%S) - $SFN successfully backed up as - $BKDIR/$FNA$BFE_$RN - prior to - $RN $RNA" || WLOG "- $(date +%D-%H:%M:%S) - ### WARNING ### - Backup of $SFN prior to - $RN $RNA - failed"
		echo "- $(date +%D-%H:%M:%S) - updated version of $SFN backed-up as $BKDIR/$FNA$BFE_$RN" >> $BKFL
	fi
}
# End of Function to create CIS backup if required