# Confirm user wants to continue
CONFIRM()
{
	read -p "Do you want to continue? y/n [n]: " -r
	RSP=`echo $REPLY | tr [A-Z] [a-z]`
	if [[ ! $RSP =~ ^(yes|y)$ ]]
	then
		echo "You responded with: $RSP exiting... "
		MLOG "- $(date +%D-%H:%M:%S) - user responded with $RSP - exiting Build Kit"
		exit 0
	else
		echo "You responded with: $RSP continuing... "
		MLOG "- $(date +%D-%H:%M:%S) - user responded with $RSP - continuing"
	fi
}
# End of Confirm user wants to continue