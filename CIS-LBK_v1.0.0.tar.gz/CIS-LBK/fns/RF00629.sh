# Ensure users own their home directories
RF00629()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	cat /etc/passwd | egrep -v '^(root|halt|sync|shutdown)' | awk -F: '($7 != "/usr/sbin/nologin" && $7 != "/bin/false") { print $1 " " $6 }' | while read USR UDIR
	do
		if [ ! -d "$UDIR" ]
		then
			WLOG "- $(date +%D-%H:%M:%S) - The home directory ($UDIR) of user $USR does not exist - $RN $RNA - ### Manual Remediation Required ###"
		else
			MLOG "- $(date +%D-%H:%M:%S) - Starting - Checking ownershp on user $USR home directory \"$UDIR\""
			if [[ $(ls -ld $UDIR | cut -d' ' -f3) = $USR ]]
			then
				MLOG "- $(date +%D-%H:%M:%S) - User $USR ownes their home directory \"$UDIR\" - Skipping"
			else
				MLOG "- $(date +%D-%H:%M:%S) - User $(ls -ld $UDIR | cut -d' ' -f3) owns $USR home directory \"$UDIR\" - Remediating"
				SFN=$UDIR
				FLOSP
				chown $USR $UDIR
				[[ $(ls -ld $UDIR | cut -d' ' -f3) = $USR ]] && MLOG "- $(date +%D-%H:%M:%S) - Successful - User $USR owns their home directory \"$UDIR\"" || WLOG "- $(date +%D-%H:%M:%S) - Failed - User $USR doesn't own their home directory \"$UDIR\" - $RN $RNA - ### Manual Remediation Required ###"
			fi
			MLOG "- $(date +%D-%H:%M:%S) - Completed - Checking ownershp on user $USR home directory \"$UDIR\""
		fi
	done
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure users own their home directories