# Ensure events that modify date and time information are collected
RF00406()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	if [[ `arch` = x86_64 ]] 
	then
		ARN="-a always,exit -F arch=b64 -S adjtimex -S settimeofday -k time-change"
		VRX="^\s*-a\s+always,exit\s+-F\s+arch=b64\s+-S\s+adjtimex\s+-S\s+settimeofday\s+-k\s+time-change\s*(#.*)?$"
		FCADR
	fi
	ARN="-a always,exit -F arch=b32 -S adjtimex -S settimeofday -S stime -k time-change"
	VRX="^\s*-a\s+always,exit\s+-F\s+arch=b32\s+-S\s+adjtimex\s+-S\s+settimeofday\s+-S\s+stime\s+-k\s+time-change\s*(#.*)?$"
	FCADR
	if [[ `arch` = x86_64 ]]
	then
		ARN="-a always,exit -F arch=b64 -S clock_settime -k time-change"
		VRX="^\s*-a\s+always,exit\s+-F\s+arch=b64\s+-S\s+clock_settime\s+-k\s+time-change\s*(#.*)?$"
		FCADR
	fi
	ARN="-a always,exit -F arch=b32 -S clock_settime -k time-change"
	VRX="^\s*-a\s+always,exit\s+-F\s+arch=b32\s+-S\s+clock_settime\s+-k\s+time-change\s*(#.*)?$"
	FCADR
	ARN="-w /etc/localtime -p wa -k time-change"
	VRX="^\s*-w\s+\/etc\/localtime\s+-p\s+wa\s+-k\s+time-change\s*(#.*)?$"
	FCADR
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure events that modify date and time information are collected