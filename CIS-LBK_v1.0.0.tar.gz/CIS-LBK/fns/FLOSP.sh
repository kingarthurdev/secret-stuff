# Function to log original file ownership and permissions
FLOSP()
{
	# SFN={Name of file to log ownership and permissions on}
	MLOG "- $(date +%D-%H:%M:%S) - Starting - Log Ownership and permissions on \"$SFN\" to \"$MOFL\""
	if [[ ! -s $MOFL ]]
	then
		echo "- This log contains the ownership and permissions information on -" >> $MOFL
		echo "                - Files modified by the CIS-LRK -" >> $MOFL
		echo "" >> $MOFL
	fi
	echo "- $RN $RNA -" >> $MOFL
	if [[ -n $(file $SFN | egrep "^\S+\:\s+directory\s*$") ]]
	then
		echo "$(ls -ld $SFN)" >> $MOFL
	else
		# echo "- File/Directory \"$SFN\" -" >> $MOFL
		echo "$(ls -l $SFN)" >> $MOFL
	fi
	echo "" >> $MOFL
	MLOG "- $(date +%D-%H:%M:%S) - Completed - Log Ownership and permissions on \"$SFN\" to \"$MOFL\""
}
# End of Function to log original file ownership and permissions