# Function to configure bannor file ownership and permissions
FBFP()
{
	# SFN={source file name} name of the bannor file
	if [[ -n `stat $SFN | egrep -i "^Access\:\s+\(0[46][04][04]\/-r[-w]-[-r]--[-r]--\)\s+Uid\:\s+\(\s+0\/\s+root\)\s+Gid\:\s+\(\s+0\/\s+root\)\s*$"` ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - permissions on $SFN are configured - Skipping"
	else
		MLOG "- $(date +%D-%H:%M:%S) - Updating owner and group to root:root"
		chown root:root $SFN
		MLOG "- $(date +%D-%H:%M:%S) - Updating Access to remove execute from user; and write and execute from group and other"
		chmod 644 $SFN
		if [[ -n `stat $SFN | egrep -i "^Access\:\s+\(0[46][04][04]\/-r[-w]-[-r]--[-r]--\)\s+Uid\:\s+\(\s+0\/\s+root\)\s+Gid\:\s+\(\s+0\/\s+root\)\s*$"` ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - Updating owner, group, and access on $SFN Successful"
		else
			WLOG "- $(date +%D-%H:%M:%S) - Updating owner, group, and access on $SFN failed - ### Manual Remediation Required"
		fi
	fi
}
#End of Function to configure bannor file ownership and permissions