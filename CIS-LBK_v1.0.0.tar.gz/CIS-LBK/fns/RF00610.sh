# Ensure no world writable files exist
RF00610()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	if [[ -z $(df --local -P | awk {'if (NR!=1) print $6'} | xargs -I '{}' find '{}' -xdev -type f -perm -0002) ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - No world writable files exist - Skipping"
	else
		WLOG "- $(date +%D-%H:%M:%S) - World writable files exist - $RN $RNA - ### Manual Remediation Required ###"
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure no world writable files exist