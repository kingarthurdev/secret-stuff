# Ensure nodev option set on /tmp partition
RF00103()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	SMPN=tmp
	OPN=nodev
	POCK
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure nodev option set on /tmp partition