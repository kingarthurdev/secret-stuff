# Ensure system administrator actions (sudolog) are collected
RF00418()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	ARN="-w /var/log/sudo.log -p wa -k actions"
	VRX="^\s*-w\s+\/var\/log\/sudo\.log\s+-p\s+wa\s+-k\s+actions\s*(#.*)?$"
	FCADR
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure system administrator actions (sudolog) are collected