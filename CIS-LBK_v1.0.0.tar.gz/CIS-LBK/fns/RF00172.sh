# Ensure local login warning banner is configured properly
RF00172()
{
	SFN=/etc/issue
	BNA="local login warning banner"
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	FWBU
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure local login warning banner is configured properly