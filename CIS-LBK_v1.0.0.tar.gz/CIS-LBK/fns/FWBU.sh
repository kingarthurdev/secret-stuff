# Function to remove refferences from the bannors
FWBU()
{
	# BNA={Name of the bannor} example Message of the day (Set by upstreen function)
	# SFN={source file name} name of the bannor file (Set by upstreem function)
	# !!! This function needs to be modified for any OS other than Debian !!! Should be Linix Distro Agnostic now
	# OSN={Operating System Name} Set as  global variable
	[[ -z $OSN ]] && OSN=$(egrep "^\s*ID=\S+$" /etc/os-release | cut -d= -f2 | sed "s/\"//g")
	if [[ -s $SFN ]] && [[ -z $(egrep -i "(\\v|\\r|\\m|\\s|$OSN)" $SFN) ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - $BNA is configured properly - Skipping"
	else
		if [[ -s $SFN ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - $BNA is not configured properly - Remediating"
			FFBK
			[[ -n $(egrep -i "^(.*)(\\v\s+)(.*)$" $SFN) ]] && sed -ri "s/^(.*)(\\v\s+)(.*)$/\1\3/" $SFN
			[[ -n $(egrep -i "^(.*)(\\r\s+)(.*)$" $SFN) ]] && sed -ri "s/^(.*)(\\r\s+)(.*)$/\1\3/" $SFN
			[[ -n $(egrep -i "^(.*)(\\m\s+)(.*)$" $SFN) ]] && sed -ri "s/^(.*)(\\m\s+)(.*)$/\1\3/" $SFN
			[[ -n $(egrep -i "^(.*)(\\s\s+)(.*)$" $SFN) ]] && sed -ri "s/^(.*)(\\s\s+)(.*)$/\1\3/" $SFN
#			[[ -n `egrep -i "^(.*)(\b$OSN\b)(.*)$" $SFN` ]] && sed -ri "s/^(.*)(\b$OSN\b)(.*)$//" $SFN
			[[ -n $(egrep -i "^(.*)((.*)($OSNGNU\/Linux|$OSNGNU|$OSN)(.*)$)(.*)$" $SFN) ]] && sed -ri "s/^(.*)((.*)($OSNGNU\/Linux|$OSNGNU|$OSN)(.*)$)(.*)$//" $SFN && echo "Authorized uses only. All activity may be monitored and reported." >> $SFN
#			[[ ! -s $SFN ]] && echo "Authorized uses only. All activity may be monitored and reported." >> $SFN
			[[ -z $(egrep -i "(\\v\s+|\\r\s+|\\m\s+|\\s\s+|$OSN)" $SFN) ]] && MLOG "- $(date +%D-%H:%M:%S) - Remediation of $BNA Successful" || WLOG "- $(date +%D-%H:%M:%S) - Remediation of $BNA failed - ### Manual remediation Required ###"
		else
			MLOG "- $(date +%D-%H:%M:%S) - $BNA doesn't exist - creating generic $BNA as $SFN"
			echo "Authorized uses only. All activity may be monitored and reported." > $SFN
			[[ -s $SFN ]] && MLOG "- $(date +%D-%H:%M:%S) - Creation of $BNA successful" || WLOG "- $(date +%D-%H:%M:%S) - Creation of $BNA failed - ### Manual Remediation Required ###"
		fi
		MLOG "- $(date +%D-%H:%M:%S) - Remediation of $BNA complete"
	fi
}
# End of Function to remove refferences from the bannors