# Ensure auditing for processes that start prior to auditd is enabled
RF00405()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	GPN=audit
	GPS=1
	GPD=ADD
	FCMGC
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure auditing for processes that start prior to auditd is enabled