# Ensure discretionary access control permission modification events are collected
RF00412()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	if [[ `arch` = x86_64 ]]
	then
		ARN="-a always,exit -F arch=b64 -S chmod -S fchmod -S fchmodat -F auid>=1000 -F auid!=4294967295 -k perm_mod"
		VRX="^\s*-a\s+always,exit\s+-F\s+arch=b64\s+-S\s+chmod\s+-S\s+fchmod\s+-S\s+fchmodat\s+-F\s+auid>=1000\s+-F\s+auid!=4294967295\s+-k\s+perm_mod\s*(#.*)?$"
  		FCADR
  	fi
	ARN="-a always,exit -F arch=b32 -S chmod -S fchmod -S fchmodat -F auid>=1000 -F auid!=4294967295 -k perm_mod"
	VRX="^\s*-a\s+always,exit\s+-F\s+arch=b32\s+-S\s+chmod\s+-S\s+fchmod\s+-S\s+fchmodat\s+-F\s+auid>=1000\s+-F\s+auid!=4294967295\s+-k\s+perm_mod\s*(#.*)?$"
	FCADR
	if [[ `arch` = x86_64 ]]
	then 
		ARN="-a always,exit -F arch=b64 -S chown -S fchown -S fchownat -S lchown -F auid>=1000 -F auid!=4294967295 -k perm_mod"
#		VRX="^\s*-a\s+always,exit\s+-F\s+arch=b64\s+-S\s+chown\s+-S\s+fchown\s+-S\s+fchownat\s+-S\s+lchown\s+-F\s+auid>=1000\s+-F\s+auid!=4294967295\s+-k\s+perm_mod\s*(#.*)?$"
		VRX="^\s*-a\s+always,exit\s+-F\s+arch=b64\s+-S\s+(chown\s+-S\s+fchown\s+-S\s+fchownat\s+-S\s+lchown|(lchown|fchown|chown|fchownat),(lchown|fchown|chown|fchownat),(lchown|fchown|chown|fchownat),(lchown|fchown|chown|fchownat))\s+-F\s+auid>=1000\s+-F\s+auid!=4294967295\s+-[Fk]\s+(key=)?perm_mod\s*(#.*)?"
		FCADR
	fi
	ARN="-a always,exit -F arch=b32 -S chown -S fchown -S fchownat -S lchown -F auid>=1000 -F auid!=4294967295 -k perm_mod"
#	VRX="^\s*-a\s+always,exit\s+-F\s+arch=b32\s+-S\s+chown\s+-S\s+fchown\s+-S\s+fchownat\s+-S\s+lchown\s+-F\s+auid>=1000\s+-F\s+auid!=4294967295\s+-k\s+perm_mod\s*(#.*)?$"
	VRX="^\s*-a\s+always,exit\s+-F\s+arch=b32\s+-S\s+(chown\s+-S\s+fchown\s+-S\s+fchownat\s+-S\s+lchown|(lchown|fchown|chown|fchownat),(lchown|fchown|chown|fchownat),(lchown|fchown|chown|fchownat),(lchown|fchown|chown|fchownat))\s+-F\s+auid>=1000\s+-F\s+auid!=(-1|4294967295)\s+-[Fk]\s+(key=)?perm_mod\s*(#.*)?"
	FCADR
	if [[ `arch` = x86_64 ]]
	then
		ARN="-a always,exit -F arch=b64 -S setxattr -S lsetxattr -S fsetxattr -S removexattr -S lremovexattr -S fremovexattr -F auid>=1000 -F auid!=4294967295 -k perm_mod"
		VRX="^\s*-a\s+always,exit\s+-F\s+arch=b64\s+-S\s+setxattr\s+-S\s+lsetxattr\s+-S\s+fsetxattr\s+-S\s+removexattr\s+-S\s+lremovexattr\s+-S\s+fremovexattr\s+-F\s+auid>=1000\s+-F\s+auid!=(-1|4294967295)\s+-k\s+perm_mod\s*(#.*)?$"
		FCADR
	fi
	ARN="-a always,exit -F arch=b32 -S setxattr -S lsetxattr -S fsetxattr -S removexattr -S lremovexattr -S fremovexattr -F auid>=1000 -F auid!=4294967295 -k perm_mod"
	VRX="^\s*-a\s+always,exit\s+-F\s+arch=b32\s+-S\s+setxattr\s+-S\s+lsetxattr\s+-S\s+fsetxattr\s+-S\s+removexattr\s+-S\s+lremovexattr\s+-S\s+fremovexattr\s+-F\s+auid>=1000\s+-F\s+auid!=4294967295\s+-k\s+perm_mod\s*(#.*)?$"
	FCADR
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure discretionary access control permission modification events are collected