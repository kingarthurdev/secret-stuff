# Function for Not Scored Recomendations
NSR()
{
	# RN={Recomendation Number}
	# RNA={Recomendation Name}
	WLOG "- $(date +%D-%H:%M:%S) - $RN $RNA - Not Scored - ### Manual Assessment and Remediation Required ###"
}
# End of Function for Not Scored Recomendations