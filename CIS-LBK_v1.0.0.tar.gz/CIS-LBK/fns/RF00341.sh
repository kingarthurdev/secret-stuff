# Ensure DCCP is disabled
RF00341()
{
	FN=dccp
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	FMNL
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure DCCP is disabled