# Ensure default user shell timeout is 900 seconds or less
RF00553()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	# Sub funftion to check TMOUT in a file
	SFCTO()
	{
		# SFN={Source file name} 
		MLOG "- $(date +%D-%H:%M:%S) - Starting - Checking TMOUT in $SFN"
#		if [[ $(egrep -i "^\s*TMOUT\s*=\s*\S+\s*(\s+#.*)?$" $SFN) =~ "^\s*TMOUT\s*=\s*(900|[1-8][0-9][0-9]|[1-9][0-9]|[1-9])\s*(\s+#.*)?$" ]]
		if [[ -n $(egrep -i "^\s*TMOUT\s*=\s*(900|[1-8][0-9][0-9]|[1-9][0-9]|[1-9])\s*(\s+#.*)?$" $SFN) ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - TMOUT in $SFN is $(egrep -i "^\s*TMOUT\s*=\s*\S+\s*(\s+#.*)?$" $SFN) - Skipping"
		else
			MLOG "- $(date +%D-%H:%M:%S) - TMOUT in $SFN is $(egrep -i "^\s*TMOUT\s*=\s*\S+\s*(\s+#.*)?$" $SFN) - Remediating"
			FFBK
			[[ -n $(egrep -i "^\s*TMOUT\s*=\s*\S+\s*(\s+#.*)?$" $SFN) ]] && sed -ri "s/^(\s*TMOUT\s*)(=\s*\S+\s*)(\s+#.*)?$/\1=600\3/" $SFN || echo "TMOUT=600" >> $SFN
#			if [[ $(egrep -i "^\s*TMOUT\s*=\s*\S+\s*(\s+#.*)?$" $SFN) =~ "^\s*TMOUT\s*=\s*(900|[1-8][0-9][0-9]|[1-9][0-9]|[1-9])\s*(\s+#.*)?$" ]]
			if [[ -n $(egrep -i "^\s*TMOUT\s*=\s*(900|[1-8][0-9][0-9]|[1-9][0-9]|[1-9])\s*(\s+#.*)?$" $SFN) ]]
			then
				MLOG "- $(date +%D-%H:%M:%S) - Successful - TMOUT in $SFN is $(egrep -i "^\s*TMOUT\s*=\s*\S+\s*(\s+#.*)?$" $SFN)"
			else
				MLOG "- $(date +%D-%H:%M:%S) - Failed - TMOUT in $SFN is $(egrep -i "^\s*TMOUT\s*=\s*\S+\s*(\s+#.*)?$" $SFN) - $RN $RNA - ### Manual Remediation Required"
			fi
		fi
		MLOG "- $(date +%D-%H:%M:%S) - Completed - Checking TMOUT in $SFN"
	}
	# End of Sub funftion to check TMOUT in a file

	SFN=/etc/bash.bashrc
	SFCTO
	SFN=/etc/profile
	SFCTO
	for SFN in $(ls /etc/profile.d/*.sh)
	do
		SFCTO
	done
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure default user shell timeout is 900 seconds or less