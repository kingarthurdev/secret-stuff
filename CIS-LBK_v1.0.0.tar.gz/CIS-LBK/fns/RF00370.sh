# Disable IPv6
RF00370()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	if [[ ! $V6S =~ (enabled|disabled) ]]
	then
		FIPV6S
	else
		[[ $V6S = enabled ]] && MLOG "- $(date +%D-%H:%M:%S) - IPv6 is $V6S by choice"
		[[ $V6S = disabled ]] && MLOG "- $(date +%D-%H:%M:%S) - IPv6 is $V6S by choice"
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Disable IPv6