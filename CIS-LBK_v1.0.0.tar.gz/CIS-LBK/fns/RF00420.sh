# Ensure the audit configuration is immutable
RF00420()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	ARF=/etc/audit/audit.rules
	SFN=/etc/audit/rules.d/audit.rules
	ARN="-e 2"
	VRX="^\s*\-e\s+2\s*(#.*)?$"
	if [[ -n $(sed -r '/^\s*(#.*)?$/ d' $ARF | tail -n 1 | egrep "^\s*-e 2\s*(#.*)?$") ]] && [[ -n $(sed -r '/^\s*(#.*)?$/ d' $SFN | tail -n 1 | egrep "^\s*-e 2\s*(#.*)?$") ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - Audit rule exists - Skipping"
	elif [[ -n $(sed -r '/^\s*(#.*)?$/ d' $SFN | tail -n 1 | egrep "^\s*-e 2\s*(#.*)?$") ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - Auditd needs to be updated from $SFN - Flagging auditd to be reloaded"
		RARF=y
	else
		MLOG "- $(date +%D-%H:%M:%S) - $SFN needs to be updated with audit rule"
		FFBK
		echo "$ARN" >> $SFN
		if [[ $(sed -r '/^\s*(#.*)?$/ d' $SFN | tail -n 1 | egrep "^\s*-e 2\s*(#.*)?$") ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - update $SFN with audit rule - successful"
			MLOG "- $(date +%D-%H:%M:%S) - Auditd needs to be updated from $SFN - Flagging auditd to be reloaded"
			RARF=y
		else
			WLOG "- $(date +%D-%H:%M:%S) - update $SFN with audit rule - Failed - ### Manual Remediation Required ###"
		fi
	fi
	# Unset function local variables
	ARF=""
	SFN=""
	ARN=""
	VRX=""
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure the audit configuration is immutable