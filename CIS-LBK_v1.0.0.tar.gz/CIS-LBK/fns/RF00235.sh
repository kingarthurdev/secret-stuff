# Ensure LDAP client is not installed
RF00235()
{
	PNA=ldap-utils
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	RPKGE
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure LDAP client is not installed