# Ensure permissions on /etc/cron.daily are configured
RF00504()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	SFN=/etc/cron.daily
	FCCDP
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure permissions on /etc/cron.daily are configured