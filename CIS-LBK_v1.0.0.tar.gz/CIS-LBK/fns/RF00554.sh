# Ensure access to the su command is restricted
RF00554()
{
	SFN=/etc/pam.d/su
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	MLOG "- $(date +%D-%H:%M:%S) - Starting - Check $SFN"
	if [[ -n $(egrep -i "^\s*auth\s+required\s+pam_wheel.so\s*(\s+#.*)?$" $SFN) ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - $SFN configured correctly - skipping"
	else
		MLOG "- $(date +%D-%H:%M:%S) - $SFN not configured correctly - Remediating"
		FFBK
		[[ -n $(egrep -i "^\s*(\S+\s+)+(pam_wheel.so)\s*(\s+#.*)?$" $SFN) ]] && sed -ri "s/^\s*(\S+\s+)+(pam_wheel.so)\s*(\s+#.*)?$/auth required\3\4/" $SFN || echo "auth required pam_wheel.so" >> $SFN
		[[ -n $(egrep -i "^\s*auth\s+required\s+pam_wheel.so\s*(\s+#.*)?$" $SFN) ]] && MLOG "- $(date +%D-%H:%M:%S) - Successful - $SFN configured correctly" || WLOG "- $(date +%D-%H:%M:%S) - Failed - $SFN not configured correctly - $RN $RNA - ### Manual Remediation Required ###"
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - Check $SFN"
	SFN=/etc/group
	MLOG "- $(date +%D-%H:%M:%S) - Starting - Check $SFN for sudo group user list"
	if [[ -n $(grep ^sudo $SFN) ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - sudo group exists in $SFN"
		WLOG "- $(date +%D-%H:%M:%S) - review userlist \"$(grep -i ^sudo $SFN | cut -d: -f4)\" - $RN $RNA - ### Manual Remediation Required ###"
	else 
		WLOG "- $(date +%D-%H:%M:%S) - sudo group doesn't exist in $SFN - $RN $RNA - ### Manual Remediation Required ###"
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - Check $SFN for sudo group user list"
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure access to the su command is restricted