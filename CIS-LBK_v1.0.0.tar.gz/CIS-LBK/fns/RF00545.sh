# Ensure password expiration is 365 days or less
RF00545()
{
	SFN=/etc/login.defs
	PON=PASS_MAX_DAYS
	PORX="^\s*Maximum\s+number\s+of\s+days\s+between\s+password\s+change\s+\:\s*\S+\s*$"
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	MLOG "- $(date +%D-%H:%M:%S) - Starting - check $PON in $SFN"
#	if [[ -n $(egrep -i "^(\s*PASS_MAX_DAYS)(\s*([1-3][0-6][0-5]|[1-2][0-9][0-9]|[1-9][0-9]|[1-9]))\s*(\s+#.*)?$" $SFN) ]]
	if [[ -n $(egrep -i "^(\s*$PON)(\s*([1-3][0-6][0-5]|[1-3][0-5][0-9]|[1-2][0-9][0-9]|[1-9][0-9]|[1-9]))\s*(\s+#.*)?$" $SFN) ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - password expiration is $(grep -i "^\s*$PON" $SFN | awk '{print $2}') days - Skipping"
	else
		MLOG "- $(date +%D-%H:%M:%S) - password expiration is $(grep -i "^\s*$PON" $SFN | awk '{print $2}') days - Remediating"
		FFBK
		[[ -n $(grep -i "^\s*$PON" $SFN) ]] && sed -ri "s/^(\s*$PON)(\s*\S*\s*)(\s+#.*)?$/\1 90\3/" $SFN || echo "$PON 90" >> $SFN
		if [[ -n $(egrep -i "^(\s*$PON)(\s*([1-3][0-6][0-5]|[1-3][0-5][0-9]|[1-2][0-9][0-9]|[1-9][0-9]|[1-9]))\s*(\s+#.*)?$" $SFN) ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - Successful - password expiration is $(grep -i "^\s*$PON" $SFN | awk '{print $2}') days"
		else
			WLOG "- $(date +%D-%H:%M:%S) - Failed - password expiration is $(grep -i "^\s*$PON" $SFN | awk '{print $2}') days - $RN $RNA - ### Manual Remediation Required ###"
		fi
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - check $PON in $SFN"
	MLOG "- $(date +%D-%H:%M:%S) - Starting - check users $PON"
	SFN=/etc/shadow
	for MPD in $(egrep ^[^:]+:[^\!*] $SFN | cut -d: -f1)
	do
#		if [[ $(chage --list $MPD | egrep -i "$PORX" | awk '{print $9}') < 366 ]]
		if [[ $(grep $MPD $SFN | cut -d: -f5) =~ ([1-3][0-6][0-5]|[1-3][0-5][0-9]|[1-2][0-9][0-9]|[1-9][0-9]|[1-9]) ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - $PON for $MPD is $(chage --list $MPD | egrep -i "$PORX" | awk '{print $9}') - skipping"
		else
			MLOG "- $(date +%D-%H:%M:%S) - $PON for $MPD is $(chage --list $MPD | egrep -i "$PORX" | awk '{print $9}') - Remediating"
			chage --maxdays 90 $MPD
			if [[ $(grep $MPD $SFN | cut -d: -f5) =~ ([1-3][0-6][0-5]|[1-3][0-5][0-9]|[1-2][0-9][0-9]|[1-9][0-9]|[1-9]) ]]
			then
				MLOG "- $(date +%D-%H:%M:%S) - Successful - user $MPD $PON is now $(chage --list $MPD | egrep -i "$PORX" | awk '{print $9}')"
			else
				WLOG "- $(date +%D-%H:%M:%S) - Failed - user $MPD $PON is $(chage --list $MPD | egrep -i "$PORX" | awk '{print $9}') - $RN $RNA - ### Manual Remediation Required ###"
			fi
		fi
	done
	MLOG "- $(date +%D-%H:%M:%S) - Completed - check users $PON"
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure password expiration is 365 days or less