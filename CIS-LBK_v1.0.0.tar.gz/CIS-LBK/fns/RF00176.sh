# Ensure permissions on /etc/issue.net are configured
RF00176()
{
	SFN=/etc/issue.net
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	FBFP
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
#End of Ensure permissions on /etc/issue.net are configured