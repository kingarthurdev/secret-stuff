# Function to check if a seporate partition exists
PECK()
{
	# RN={Remediation Number}
	# MPN={Mount Point}
	# RNA="Ensure a seporate partition exists for "$MPN
	# MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN - $RNA"
#	[[ -z $(mount | grep $MPN) ]] && WLOG " $(date +%D-%H:%M:%S) - Partition $MPN doesn't exist - $RN $RNA - ### Manual Remediation Required ###" || MLOG "- $(date +%D-%H:%M:%S) - Partition $MPN exists.  No remediation required.  Skipping"
	# MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN - $RNA"
	MLOG "- $(date +%D-%H:%M:%S) - Starting - check if partition \"$MPN\" exists"
	if [[ -n $(mount | grep $MPN) ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - Partition \"$MPN\" exists - No remediation required - Skipping"
	else
		WLOG "- $(date +%D-%H:%M:%S) - Partition \"$MPN\" doesn't exist - $RN $RNA - ### Manual Remediation Required ###"
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - check if partition \"$MPN\" exists"
}
# End of Function check if a seporate partition exists