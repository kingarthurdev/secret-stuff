# Function to enable a systemd daemon
FTESD()
{
	# DAEN={daemon name}
	MLOG "- $(date +%D-%H:%M:%S) - Starting - enable daemon $DAEN"
	if [[ $(systemctl is-enabled $DAEN) = enabled ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - daemon $DAEN is enabled - Skipping"
	else
		MLOG "- $(date +%D-%H:%M:%S) - daemon $DAEN not enabled - Remediating"
		systemctl enable $DAEN
		[[ $(systemctl is-enabled $DAEN) = enabled ]] && MLOG "- $(date +%D-%H:%M:%S) - Successful - daemon $DAEN enabled" || WLOG "- $(date +%D-%H:%M:%S) - Failed daemon $DAEN not enabled - ### Manual Remediation Required ###"
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - enable daemon $DAEN"
}
# End of Function to enable a systemd daemon