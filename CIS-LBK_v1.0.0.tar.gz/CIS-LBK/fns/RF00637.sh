# Ensure no duplicate GIDs exist
RF00637()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	cat /etc/group | cut -f3 -d":" | sort -n | uniq -c | while read x
	do
		[ -z "${x}" ] && break
		set - $x
		if [ $1 -gt 1 ]
		then
			GRP=$(awk -F: '($3 == n) { print $1 }' n=$2 /etc/group | xargs)
			WLOG "- $(date +%D-%H:%M:%S) - Duplicate GID ($2): ${GRP} - $RN $RNA - ### Manual Remediation Required ###"
		fi
	done
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure no duplicate GIDs exist