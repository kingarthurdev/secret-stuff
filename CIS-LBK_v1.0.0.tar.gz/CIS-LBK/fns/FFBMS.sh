# Function to determine Benchmark Script to run
FFBMS()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - Determine Benchmark Script to run"
	OSN=$(egrep "^\s*ID=\S+$" /etc/os-release | cut -d= -f2 | sed "s/\"//g")
	OSV=$(egrep "^\s*VERSION_ID=\S+\$" /etc/os-release | cut -d= -f2 | sed "s/\"//g")
	OSP=$OSN$OSV
	case $OSP in
		debian9 )
			MLOG "- $(date +%D-%H:%M:%S) - Platform is $OSP"
			BSTR=$SDIR/CIS_Debian_9.sh
			;;
		* )
			WLOG "- $(date +%D-%H:%M:%S) - Platform is $OSP - CIS-LRK doesn't currently have remediation for this platform - Exiting"
			exit 0
			;;
	esac
	MLOG "- $(date +%D-%H:%M:%S) - Completed - Determine Benchmark Script to run"
}
# End of Function to determine Benchmark Script to run