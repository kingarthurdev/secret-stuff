# Disable Automounting
RF00122()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	if [[ ! `systemctl is-enabled autofs` = enabled ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - Automounting is disabled - no remediation required, skipping"
	else
		MLOG "- $(date +%D-%H:%M:%S) - Automounting is not disabled - starting remediation"
		systemctl disable autofs
		if [[ ! `systemctl is-enabled autofs` = enabled ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - Successful - Automounting is disabled"
		else
			WLOG "- $(date +%D-%H:%M:%S) - Failed - Automounting is not disabled - $RN $RNA - ### Manual Remediation Required ###"
		fi
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Disable Automounting