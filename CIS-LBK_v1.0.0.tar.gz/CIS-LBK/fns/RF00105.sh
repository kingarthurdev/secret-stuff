# Ensure noexec option set on /tmp partition
RF00105()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	SMPN=tmp
	OPN=noexec
	POCK
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure noexec option set on /tmp partition