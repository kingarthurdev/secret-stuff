# Ensure SELinux policy is configured
RF00163()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	MACTPE # Function to ensure that the MACDEC variable is set
	if [[ ! $MACDEC = SEL ]]
	then
		FNSEL
	else
		if [[ -n `egrep "^\s*SELINUXTYPE\s*=\s*(ubuntu|default|mls)\s*(\s+#.*)?$" /etc/selinux/config` ]] && [[ -n `sestatus | egrep -i "^Policy\s+from\s+config\s+file\:\s+default\s*(\s+#.*)?$"` ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - SELinux Policy is Configured - Skipping"
		else
			SFN=/etc/selinux/config
			MLOG "- $(date +%D-%H:%M:%S) - SELinux Policy is not Configured - Remediating"
			if [[ -n $(egrep -i "^\s*SELINUXTYPE\s*=\s*(ubuntu|default|mls)\s*(\s+#.*)?$" $SFN) ]]
			then
				MLOG "- $(date +%D-%H:%M:%S) - SELINUXTYPE is = \"$(grep -i ^SELINUXTYPE $SFN | cut -d= -f2)\" - skipping"
			else
				MLOG "- $(date +%D-%H:%M:%S) - SELINUXTYPE is = $(grep -i ^SELINUXTYPE $SFN | cut -d= -f2) - updating $SFN"
				FFBK
				[[ -n `egrep -i "^\s*SELINUXTYPE=" $SFN` ]] && sed -ri "s/^\s*(SELINUXTYPE\s*=)(\s*\S+)(\s*)((\s+#.*)?)$/\1default\3\4/" $SFN || echo "SELINUXTYPE=default" >> $SFN
				[[ -n `egrep -i "^\s*SELINUXTYPE=\s*(ubuntu|default|mls)\s*(\s+#.*)?$" $SFN` ]] && MLOG "- $(date +%D-%H:%M:%S) - Remediation of $RN $RNA successful" || WLOG "- $(date +%D-%H:%M:%S) - ### Warning ### - Remediation of $RN $RNA failed - ### Manual Remediation Required ###"
			fi
			MLOG "- $(date +%D-%H:%M:%S) - Completed - SELinux Policy is not Configured - Checking $SFN"
		fi
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure SELinux policy is configured