# Platform Check
PLATFORM()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting Platform Check"
	MLOG "- $(date +%D-%H:%M:%S) - ### Script will exit if Platform Check fails ###"
	[[ `egrep "^\s*ID=\S+$" /etc/os-release` =~ ^\s*ID=debian\s*$ ]] && [[ `egrep "^\s*VERSION_ID=\S+\$" /etc/os-release` =~ ^\s*VERSION_ID=\"9\"\s*$ ]] && MLOG "- $(date +%D-%H:%M:%S) - Platform Check Passed - continuing..." || exit 1
 	MLOG "- $(date +%D-%H:%M:%S) - Platform Check successful"
}
# End of Platform Check