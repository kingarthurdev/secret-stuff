# Ensure LDAP server is not enabled
RF00210()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	DAEN=slapd
	FTDSD
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure LDAP Server is not enabled