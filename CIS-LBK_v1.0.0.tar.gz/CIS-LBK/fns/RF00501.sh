# Ensure cron daemon is enabled
RF00501()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	DAEN=cron
	FTESD
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure cron daemon is enabled