# Ensure events that modify the system's Mandatory Access Controls are collected
RF00409()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	MACTPE # Function to ensure that the MACDEC variable is set
	case $MACDEC in
		SEL )
			MLOG "- $(date +%D-%H:%M:%S) - SELinux is installed"
			ARN="-w /etc/selinux/ -p wa -k MAC-policy"
			VRX="^\s*-w\s+\/etc\/selinux\/\s+-p\s+wa\s+-k\s+MAC-policy\s*(#.*)?$"
			FCADR
			ARN="-w /usr/share/selinux/ -p wa -k MAC-policy"
			VRX="^\s*-w\s+\/usr\/share\/selinux\/\s+-p\s+wa\s+-k\s+MAC-policy\s*(#.*)?$"
			FCADR
			;;
		APAR )
			MLOG "- $(date +%D-%H:%M:%S) - AppArmor is installed"
			ARN="-w /etc/apparmor/ -p wa -k MAC-policy"
			VRX="^\s*-w\s+\/etc\/apparmor\/\s+-p\s+wa\s+-k\s+MAC-policy\s*(#.*)?$"
			FCADR
			ARN="-w /etc/apparmor.d/ -p wa -k MAC-policy"
			VRX="^\s*-w\s+\/etc\/apparmor.d\/\s+-p\s+wa\s+-k\s+MAC-policy\s*(#.*)?$"
			FCADR
			;;
		* )
			WLOG "- $(date +%D-%H:%M:%S) - MAC is not installed - ### Manual Remediation Required"
	esac
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure events that modify the system's Mandatory Access Controls are collected