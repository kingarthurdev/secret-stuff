# Ensure separate partition exists for /var/log
RF00111()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	MPN="/var/log"
	PECK
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure separate partition exists for /var/log