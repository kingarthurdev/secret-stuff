# Ensure NIS Client is not installed
RF00231()
{
	PNA=nis
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	RPKGE
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure NIS Client is not installed