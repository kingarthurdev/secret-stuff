# Warning Banner
WARBNR()
{
	clear
	echo " ********************************************************* "
	echo " * *                                                   * * "
	echo " *W* This Build Kit makes changes to your system       *W* "
	echo " *A* These changes could cause loss of functionality!  *A* "
	echo " *R*                                                   *R* "
	echo " *N* Please ensure that this Build Kit is tested       *N* "
	echo " *I* in your testing environment before running it     *I* "
	echo " *N* against a production system.  Failure to employ   *N* "
	echo " *G* proper testing can lead to service interruption!  *G* "
	echo " *                                                       * "
	echo " ********************************************************* "
	sleep 3
	echo ""
	echo " __________________________________________________________"
	echo ""
	echo " If a recommendation is determined to not be appropriate in "
	echo " your environment, automated Implementation of the"
	echo " recommendation can be disabled by adding the recommendation "
	echo " number to the file:"
	echo " $BDIR/exclude_recomendation.lst"
	echo " each recommendation number should be added to its own line"
	echo " in the file"
	echo ""
	echo " If excluding a recommendation or recommendations’ is necessary"
	echo " Please exit by selecting [n], add the appropriate"
	echo " recommendation numbers to the file, and then re-run"
	echo " $BDIR/CIS-LBK.sh"
	echo " __________________________________________________________"

	echo ""
	sleep 3
	CONFIRM
}
# End of Warning Banner