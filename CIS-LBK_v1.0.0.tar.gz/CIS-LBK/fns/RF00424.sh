# Ensure rsyslog is configured to send logs to a remote log host
RF00424()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	FDLP # Determins which logging package is being used
	if [[ ! $LCPH = RSL ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - rsyslog is not being used on this system - Skipping"
	else
		MLOG "- $(date +%D-%H:%M:%S) - Starting - Checking $SFN for remote log host"
		SFN=/etc/rsyslog.conf
		[[ -n `egrep "^\s*\*\.\*\s+@" $SFN` ]] && MLOG "- $(date +%D-%H:%M:%S) - remote log host - `egrep "^\s*\*\.\*\s+@" $SFN` - found in $SFN" || WLOG "- $(date +%D-%H:%M:%S) - remote log host - not found in $SFN - ### Manual Remediation Required ###"
		MLOG "- $(date +%D-%H:%M:%S) - Completed - Checking $SFN for remote log host"
		if [[ -n `ls /etc/rsyslog.d/*.conf` ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - Starting - Checking /etc/rsyslog.d/*.conf for remote log host"
			for SFN in `ls /etc/rsyslog.d/*.conf`
			do
				[ -n `egrep "^\s*\*\.\*\s+@" $SFN` ]] && MLOG "- $(date +%D-%H:%M:%S) - remote log host - `egrep "^\s*\*\.\*\s+@" $SFN` - found in $SFN" || WLOG "- $(date +%D-%H:%M:%S) - remote log host - not found in $SFN - ### Manual Remediation Required ###"
			done
			MLOG "- $(date +%D-%H:%M:%S) - Completed - Checking /etc/rsyslog.d/*.conf for remote log host"
		else
			MLOG "- $(date +%D-%H:%M:%S) - no *.conf files exist in /etc/rsyslog.d/ - skipping"
		fi
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure rsyslog is configured to send logs to a remote log host