# Ensure permissions on /etc/hosts.deny are configured
RF00335()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	if [[ -n `stat /etc/hosts.deny | egrep -i "^Access\:\s+\(0[46][04][04]\/-r[-w]-[-r]--[-r]--\)\s+Uid\:\s+\(\s+0\/\s+root\)\s+Gid\:\s+\(\s+0\/\s+root\)\s*$"` ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - permissions on /etc/hosts.deny are configured - Skipping"
	else
		MLOG "- $(date +%D-%H:%M:%S) - Updating owner and group to root:root"
		SFN=/etc/hosts.deny
		FLOSP
		chown root:root /etc/hosts.deny
		MLOG "- $(date +%D-%H:%M:%S) - Updating Access to remove write, and execute from group and other"
		chmod og-wx /etc/hosts.deny
		if [[ -n `stat /etc/hosts.deny | egrep -i "^Access\:\s+\(0[46][04][04]\/-r[-w]-[-r]--[-r]--\)\s+Uid\:\s+\(\s+0\/\s+root\)\s+Gid\:\s+\(\s+0\/\s+root\)\s*$"` ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - Successful - Ownership and access modified"
		else
			WLOG "- $(date +%D-%H:%M:%S) - Failed - Ownership and access not modified - $RN $RNA - ### Manual Remediation Required ###"
		fi
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure permissions on /etc/hosts.deny are configured