# 4.1.8 Ensure login and logout events are collected
RF00410()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	ARN="-w /var/log/faillog -p wa -k logins"
	VRX="^\s*-w\s+/var/log/faillog\s+-p\s+wa\s+-k\s+logins\s*(#.*)?$"
	FCADR
	ARN="-w /var/log/lastlog -p wa -k logins"
	VRX="^\s*-w\s+/var/log/lastlog\s+-p\s+wa\s+-k\s+logins\s*(#.*)?$"
	FCADR
	ARN="-w /var/log/tallylog -p wa -k logins"
	VRX="^\s*-w\s+/var/log/tallylog\s+-p\s+wa\s+-k\s+logins\s*(#.*)?$"
	FCADR
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure login and logout events are collected