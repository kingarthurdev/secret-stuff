# Ensure changes to system administration scope (sudoers) is collected
RF00417()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	ARN="-w /etc/sudoers -p wa -k scope"
	VRX="^\s*-w\s+\/etc\/sudoers\s+-p\s+wa\s+-k\s+scope\s*(#.*)?$"
	FCADR
	ARN="-w /etc/sudoers.d/ -p wa -k scope"
	VRX="^\s*-w\s+\/etc\/sudoers\.d\/\s+-p\s+wa\s+-k\s+scope\s*(#.*)?$"
	FCADR
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure changes to system administration scope (sudoers) is collected