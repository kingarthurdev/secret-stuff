# Ensure TCP SYN Cookies is enabled
RF00328()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	SPN=net.ipv4.tcp_syncookies
	SPS=1
	SPF=net.ipv4.route.flush=1
	FSSCP
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure TCP SYN Cookies is enabled