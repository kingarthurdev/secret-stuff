# Ensure nodev option set on /dev/shm partition
RF00115()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	SMPN=dev/shm
	OPN=nodev
	POCK
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End ofEnsure nodev option set on /dev/shm partition