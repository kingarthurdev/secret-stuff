# Ensure IMAP and POP3 server is not enabled
RF00215()
{
	PNA=exim4
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	if [[ ! `dpkg -s $PNA | grep Status` = "Status: install ok installed" ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - $PNA is not installed - Skipping"
	else
		MLOG "- $(date +%D-%H:%M:%S) - $PNA is installed - Remediating"
		RPKGE
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure IMAP and POP3 server is not enabled