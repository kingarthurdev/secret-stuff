# Function to determine if IPv6 should be disabled
FIPV6D()
{
	# GCFL={Full path to Grub(2) configuration file (grub.cfg)}

	# Subfunction to request user decision about disableing IPv6
	SFV6C()
	{
		MLOG "- $(date +%D-%H:%M:%S) - Starting - Question - Should IPv6 be disabled"
		clear
		echo "IPv6 is currently $V6S."
		echo "Although IPv6 has many advantages over IPv4, not all organizations have IPv6 or dual stack configurations implemented."
		echo "If IPv6 or dual stack is not to be used, it is recommended that IPv6 be disabled to reduce the attack surface of the system."
		echo "Disabling IPv6 in a Not Scored Level 2 Recomendation"
		echo ""
		echo "Do you want IPv6 disabled?"
		#echo "Yes or No?"
		read -p "Yes or No?: " -r
		#echo ": "
		#read V6AN
		V6AN=$(echo $REPLY | tr [A-Z] [a-z])
		[[ $V6AN =~ (y|yes|n|no) ]] && MLOG "- $(date +%D-%H:%M:%S) - Answer to Should IPv6 be disabled is: $V6AN" && MLOG "- $(date +%D-%H:%M:%S) - Completed - Question - Should IPv6 be disabled" || WLOG "- $(date +%D-%H:%M:%S) - Answer to Should IPv6 be disabled is: $V6AN - This is not a valid responce"
	}
	# End of Subfunction to request user decision about disableing IPv6
	
	MLOG "- $(date +%D-%H:%M:%S) - Starting - Determine if IPv6 should be disabled"
	[[ -n `egrep -i "(^\s*)(\blinux\b\s+).*(\bipv6\.disable\=1\b)(.*)$" $GCFL` ]] && V6S="disabled" || V6S="enabled"
	while [[ ! $V6AN =~ (y|yes|n|no) ]]
	do
		MLOG "- $(date +%D-%H:%M:%S) - Need to determin if IPv6 should be disabled"
		SFV6C
	done
	[[ -n `egrep -i "(^\s*)(\blinux\b\s+).*(\bipv6\.disable\=1\b)(.*)$" $GCFL` ]] && [[ $V6AN =~ (y|yes) ]] && MLOG "- $(date +%D-%H:%M:%S) -IPv6 is $V6S - User selected that IPv6 be $V6S - Skipping"
	[[ -z `egrep -i "(^\s*)(\blinux\b\s+).*(\bipv6\.disable\=1\b)(.*)$" $GCFL` ]] && [[ $V6AN =~ (n|no) ]] && MLOG "- $(date +%D-%H:%M:%S) -IPv6 is $V6S - User selected that IPv6 be $V6S - Skipping"
	if [[ -n `egrep -i "(\blinux\b\s+).*(\bipv6\.disable\=1\b)(.*)$" $GCFL` ]] && [[ $V6AN =~ (n|no) ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - Starting - Enabeling IPv6 in grub"
		SFN=/etc/default/grub
		FFBK
		[[ -n `egrep -i "(^\s*)(GRUB_CMDLINE_LINUX=\").*(ipv6\.disable\=1)(.*)\"(.*)$" $SFN` ]] && sed -ri "s/(^\s*)(GRUB_CMDLINE_LINUX=\")(.*)(\s*ipv6\.disable\=1)(.*)(\")(.*)$/\1\2\3\5\6\7/" $SFN
		[[ -n `egrep -i "(^\s*)(GRUB_CMDLINE_LINUX_DEFAULT=\").*(ipv6\.disable\=1)(.*)\"(.*)$" $SFN` ]] && sed -ri "s/(^\s*)(GRUB_CMDLINE_LINUX_DEFAULT=\")(.*)(\s*ipv6\.disable\=1)(.*)(\")(.*)$/\1\2\3\5\6\7/" $SFN
		[[ -z `egrep -i "(^\s*)(GRUB_CMDLINE_LINUX=\").*(ipv6\.disable\=1)(.*)\"(.*)$" $SFN` ]] && [[ -z `egrep -i "(^\s*)(GRUB_CMDLINE_LINUX_DEFAULT=\").*(ipv6\.disable\=1)(.*)\"(.*)$" $SFN` ]] && MLOG "- $(date +%D-%H:%M:%S) - Enabeling IPv6 in grub successful" || WLOG "- $(date +%D-%H:%M:%S) - Enabeling IPv6 in grub failed - ### Manual Remediation Required ###"
#		MLOG "- $(date +%D-%H:%M:%S) - Setting Flag to update the grub2 configuration when remediation is complete"
		FUGC
#		UG2C=y
		V6S="enabled"
		MLOG "- $(date +%D-%H:%M:%S) - Completed - Enabeling IPv6 in grub"
	fi
	if [[ -z `egrep -i "(^\s*)(GRUB_CMDLINE_LINUX=\").*(ipv6\.disable\=1)(.*)\"(.*)$" $SFN` ]] && [[ $V6AN =~ (y|yes) ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - Starting - Disabling IPv6 in grub"
		SFN=/etc/default/grub
		FFBK
		[[ -n `egrep -i "(^\s*)(GRUB_CMDLINE_LINUX=\")(.*)(\s*ipv6\.disable\=\S*\b)(.*)(\")(.*)$" $SFN` ]] && sed -ri "s/(^\s*)(GRUB_CMDLINE_LINUX=\")(.*)(\s*ipv6\.disable\=\S*\b)(.*)(\")(.*)$/\1\2ipv6.disable=1 \3\5\6\7/" $SFN || sed -ri "s/(^\s*)(GRUB_CMDLINE_LINUX=\")(.*)(\")(.*)$/\1\2ipv6.disable=1 \3\4\5/" $SFN
		[[ -n `egrep -i "(^\s*)(GRUB_CMDLINE_LINUX_DEFAULT=\")(.*)(\s*ipv6\.disable\=\S*\b)(.*)(\")(.*)$" $SFN` ]] && sed -ri "s/(^\s*)(GRUB_CMDLINE_LINUX_DEFAULT=\")(.*)(\s*ipv6\.disable\=\S*\b)(.*)(\")(.*)$/\1\2\3\5\6\7/" $SFN
		[[ -n `egrep -i "(^\s*)(GRUB_CMDLINE_LINUX=\").*(ipv6\.disable\=1)(.*)\"(.*)$" $SFN` ]] && [[ -z `egrep -i "(^\s*)(GRUB_CMDLINE_LINUX_DEFAULT=\")(.*)(\s*ipv6\.disable\=\S*\b)(.*)(\")(.*)$" $SFN` ]] && MLOG "- $(date +%D-%H:%M:%S) - Disabling IPv6 in grub successful" || WLOG "- $(date +%D-%H:%M:%S) - Disabling IPv6 in grub failed - ### Manual Remediation Required ###"
#		MLOG "- $(date +%D-%H:%M:%S) - Setting Flag to update the grub2 configuration when remediation is complete"
		FUGC
#		UG2C=y
		V6S="disabled"
		MLOG "- $(date +%D-%H:%M:%S) - Completed - Disabling IPv6 in grub"
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - Determine if IPv6 should be disabled"
}
# End of # Function to determine if IPv6 should be disabled