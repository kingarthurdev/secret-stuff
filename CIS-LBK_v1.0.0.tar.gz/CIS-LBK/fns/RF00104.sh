# Ensure nosuid option set on /tmp partition
RF00104()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	SMPN=tmp
	OPN=nosuid
	POCK
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure nosuid option set on /tmp partition