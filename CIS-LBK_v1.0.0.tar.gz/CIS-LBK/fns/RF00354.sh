# Ensure firewall rules exist for all open ports
RF00354()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	MLOG "- $(date +%D-%H:%M:%S) - ### WARNING ###- Changing firewall settings while connected over network can result in being locked out of the system."
	MLOG "- $(date +%D-%H:%M:%S) - Do to potential loss of connectivity to a remote system, $RN $RNA will not be remediated"
	WLOG "- $(date +%D-%H:%M:%S) - $RN $RNA - ### Manual Remediation Required ###"
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure firewall rules exist for all open ports