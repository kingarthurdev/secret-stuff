# Ensure source routed packets are not accepted
RF00321()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	SPN=net.ipv4.conf.all.accept_source_route
	SPS=0
	SPF=net.ipv4.route.flush=1
	FSSCP
	SPN=net.ipv4.conf.default.accept_source_route
	SPS=0
	SPF=net.ipv4.route.flush=1
	FSSCP
	SPN=net.ipv6.conf.all.accept_source_route
	SPS=0
	SPF=net.ipv6.route.flush=1
	FSSCP
	SPN=net.ipv6.conf.default.accept_source_route
	SPS=0
	SPF=net.ipv6.route.flush=1
	FSSCP
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure source routed packets are not accepted