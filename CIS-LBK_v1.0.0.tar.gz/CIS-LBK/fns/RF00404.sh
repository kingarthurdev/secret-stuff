# Ensure auditd service is enabled
RF00404()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	MLOG "- $(date +%D-%H:%M:%S) - Starting - Need to ensure that auditd package is installed"
	PNA=auditd
	PNA2=audispd-plugins
	FIPKG
	MLOG "- $(date +%D-%H:%M:%S) - Completed - Need to ensure that auditd package is installed"
	DAEN=auditd
	FTESD
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure auditd service is enabled