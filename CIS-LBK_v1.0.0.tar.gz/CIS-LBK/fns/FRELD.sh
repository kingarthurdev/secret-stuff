# Function to run end of script updates
FRELD()
{
	# Sub Function to re-enable login and reload auditd
	SFEL()
	{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - re-enable login"
	[[ -z $OSN ]] && OSN=$(egrep "^\s*ID=\S+$" /etc/os-release | cut -d= -f2 | sed "s/\"//g")
	if [[ $OSN =~ (debian|ubuntu) ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - Starting - Checking user \"admin\""
		if [[ -n $(egrep -i "^\s*admin\:" /etc/passwd) ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - user \"admin\" exists in \"/etc/passwd\" updateing user \"admin\""
			chage -I -1 -m 0 -M 99999 -E -1 admin
		else
			MLOG "- $(date +%D-%H:%M:%S) - user \"admin\" doesnt exist in \"/etc/passwd\" - Skipping"
		fi
		MLOG "- $(date +%D-%H:%M:%S) - Completed - Checking user \"admin\""
		MLOG "- $(date +%D-%H:%M:%S) - Starting - Checking user \"root\""
		if [[ -n $(egrep "^\s*root\:" /etc/passwd) ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - user \"root\" exists in \"/etc/passwd\" updateing user \"root\""
			chage -I -1 -m 0 -M 99999 -E -1 root
		else
			MLOG "- $(date +%D-%H:%M:%S) - user \"root\" doesn't exist in \"/etc/passwd\" - Skipping"
		fi
		MLOG "- $(date +%D-%H:%M:%S) - Completed - Checking user \"root\""
 	fi
 	MLOG "- $(date +%D-%H:%M:%S) - Completed - re-enable login"
 	}
 	# End of Sub Function to re-enable login and reload auditd

 	# Sub Function to update the Grub(2) configuration
 	SFUG()
	{
		MLOG "- $(date +%D-%H:%M:%S) - Starting - update the grub2 configuration if required"
		if [[ ! $UG2C = y ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - Grub(2) configuraton has not been flagged to be updated - Skipping"	
		else
			MLOG "- $(date +%D-%H:%M:%S) - Grub(2) configuraton has been flagged to be updated - Updating Grub(2)"
			[[ -z $OSN ]] && OSN=$(egrep "^\s*ID=\S+$" /etc/os-release | cut -d= -f2 | sed "s/\"//g")
			if [[ $OSN =~ (debian|ubuntu) ]]
			then
				update-grub
			elif [[ $OSN =~ (rhel|centos|al2) ]]
			then
				grub2-mkconfig -o /boot/grub2/grub.cfg
			else
				WLOG "- $(date +%D-%H:%M:%S) - Unable to update grub(2) configuration - $RN $RNA - ### Manual Remediation Required ###"
			fi
		fi
		MLOG "- $(date +%D-%H:%M:%S) - Completed - update the grub2 configuration if required"
	}
	# End of Sub Function to update the Grub(2) configuration

	# Sub function to re-load auditd
	SFRAD()
	{
	 	MLOG "- $(date +%D-%H:%M:%S) - Starting - reload auditd if required"
 		if [[ ! $RARF = y ]]
 		then
 			MLOG "- $(date +%D-%H:%M:%S) - auditd doesn't need to be reloaded"
 		else
 			MLOG "- $(date +%D-%H:%M:%S) - auditd needs to be reloaded - reloading auditd"
 			auditctl -R /etc/audit/rules.d/audit.rules
 			systemctl restart auditd
 		fi
 		MLOG "- $(date +%D-%H:%M:%S) - Completed - reload auditd if required"
	}

	# Sub function to read system parmeters into the running config
	SFRSC()
	{
		MLOG "- $(date +%D-%H:%M:%S) - Starting - load sysctl if required"
		if [[ ! $SCPR = y ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - sysctl doesn't need to be loaded"
		else
			MLOG "- $(date +%D-%H:%M:%S) - sysctl  needs to be loaded - loading sysctl"
			sysctl -p
		fi
		MLOG "- $(date +%D-%H:%M:%S) - Completed - load sysctl if required"
	}
	# End of Sub function to read system parmeters into the running config

	# Sub Function to re-correct bootloader permissions
	SFFBPL()
	{
		if [[ -z $(stat $GCFL | egrep -i "^Access\:\s+\(0[46]00\/-r[-w]-------\)\s+Uid\:\s+\(\s+0\/\s+root\)\s+Gid\:\s+\(\s+0\/\s+root\)\s*$") ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - Bootloader permissions need to be updated"
			SFN=$GCFL
			MLOG "- $(date +%D-%H:%M:%S) - Updating owner and group on \"$GCFL\" to root:root"
			FLOSP
			chown root:root $GCFL
			MLOG "- $(date +%D-%H:%M:%S) - Updating Access to remove read, write, and execute from group and other on \"$GCFL\""
			chmod o-rwx $GCFL
			chmod g-rwx $GCFL
			chmod u-x $GCFL
			if [[ -n $(stat $GCFL | egrep -i "^Access\:\s+\(0[46]00\/-r[-w]-------\)\s+Uid\:\s+\(\s+0\/\s+root\)\s+Gid\:\s+\(\s+0\/\s+root\)\s*$") ]]
			then
				MLOG "- $(date +%D-%H:%M:%S) - Successful - Permissions on \"$GCFL\" are $(stat $GCFL | grep "Access: (" | cut -d' ' -f2)"
			else
				WLOG "- $(date +%D-%H:%M:%S) - Fialed - Permissions on \"$GCFL\" are $(stat $GCFL | grep "Access: (" | cut -d' ' -f2) - ### Manual Remediation Required ###"
			fi
		fi
	}

#	SFEL
	SFUG
	SFRAD
	SFRSC
	SFFBPL
}
# End of Function to run end of script updates