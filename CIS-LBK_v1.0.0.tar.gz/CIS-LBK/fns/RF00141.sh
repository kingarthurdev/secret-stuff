# Ensure permissions on bootloader config are configured
RF00141()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	SFN=$GCFL
	if [[ -n `stat $GCFL | egrep -i "^Access\:\s+\(0[46]00\/-r[-w]-------\)\s+Uid\:\s+\(\s+0\/\s+root\)\s+Gid\:\s+\(\s+0\/\s+root\)\s*$"` ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - Ownership and permissions on bootloader config \"$GCFL\" are configured - Skipping"
	else
		MLOG "- $(date +%D-%H:%M:%S) - Updating owner and group on \"$GCFL\" to root:root"
		FLOSP
		chown root:root $GCFL
		MLOG "- $(date +%D-%H:%M:%S) - Updating Access to remove read, write, and execute from group and other on \"$GCFL\""
		chmod o-rwx $GCFL
		chmod g-rwx $GCFL
		chmod u-x $GCFL
		if [[ -n `stat $GCFL | egrep -i "^Access\:\s+\(0[46]00\/-r[-w]-------\)\s+Uid\:\s+\(\s+0\/\s+root\)\s+Gid\:\s+\(\s+0\/\s+root\)\s*$"` ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - Successful - Permissions on \"$GCFL\" are $(stat $GCFL | grep "Access: (" | cut -d' ' -f2)"
		else
			WLOG "- $(date +%D-%H:%M:%S) - Fialed - Permissions on \"$GCFL\" are $(stat $GCFL | grep "Access: (" | cut -d' ' -f2) - $RN $RNA - ### Manual Remediation Required ###"
		fi
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure permissions on bootloader config are configured