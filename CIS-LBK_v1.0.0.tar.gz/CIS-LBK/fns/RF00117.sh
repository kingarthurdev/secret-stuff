# Ensure noexec option set on /dev/shm partition
RF00117()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	SMPN=dev/shm
	OPN=noexec
	POCK
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure noexec option set on /dev/shm partition