# Function to check for an option being set on a partition
POCK()
{
	# Variables that need to be set before calling this function
#	RN={Recomendation Number} # example: 1.1.3
#	SMPN={Partition Name} # example: var/log/audit - DO NOT include the leading "/"
#	OPN={Name of the option on the partition} # example: nodev
	
	# Variables for testing within the function
	MPN=\/$SMPN
	MPNM=${SMPN//"/"/_}
	VAR1="^[^#]\S+\s+"
	#VAR2="\/"
	VAR2=${MPN//"/"/"\/"}
	VAR3="\s+.*$"
	#MPL=\"$VAR1$VAR2$SMPN$VAR3\"
	MPL=\"$VAR1$VAR2$VAR3\"
	TST1=\`egrep\ $MPL\ /etc/fstab\`
	VAR4="^\s*[Oo]ptions\=\S+[=,]"
	VAR5="[,\s*][a-z\s]*$"
	OPL=\"$VAR4$OPN$VAR5\"
#	TST2=\`egrep\ -q\ $OPL\ /etc/systemd/system/local-fs.target.wants$MPN.mount\`
	TST2=\`egrep\ $OPL\ /etc/systemd/system/local-fs.target.wants\/$MPNM.mount\`

#	echo " $(date +%D-%H:%M:%S) - Starting $RN - Ensure $OPN set on $MPN partition"  >> $LOG
	MLOG "- $(date +%D-%H:%M:%S) - Starting - Check \"$OPN\" set on \"$MPN\" partition"
	[[ -z $(mount | grep $MPN) ]] && ASR=1
#	[[ -n $TST1 ]] && ASR=2
	[[ -n $(grep $MPN /etc/fstab) ]] && ASR=2
	[[ ! $ASR = 2 ]] && [[ -s /etc/systemd/system/local-fs.target.wants/$MPNM.mount ]] && ASR=3
	case $ASR in
		1 )
			MLOG "- $(date +%D-%H:%M:%S) - Partition $MPN doesn't exist. ### Manual Remediation Required ### Recomendation $RN not required for a non-existant partition for Level 1 complience. If looking for Level 2 complience, this will need to be re-checked after the partition is created."
			;;
		2 )
			MLOG "- $(date +%D-%H:%M:%S) - $MPN is configured in /etc/fstab - checking /etc/fstab for $OPN option"
			if [[ -n $(grep $MPN /etc/fstab | grep $OPN) ]] 
			then
				MLOG "- $(date +%D-%H:%M:%S) - Partition $MPN exists and $OPN is set.  No remediation required - Skipping" 
			else
				MLOG "- $(date +%D-%H:%M:%S) - Partition $MPN exists and is configured in /etc/fstab - $OPN not set - adding $OPN to $MPN in /etc/fstab"
				SFN=/etc/fstab
				FFBK
#				[[ ! -s /etc/fstab.bk.cis ]] && echo " $(date +%D-%H:%M:%S) - *** creating backup *** of /etc/fstab as /etc/fstab.bk.cis" >> $LOG && cp /etc/fstab /etc/fstab.bk.cis || echo " $(date +%D-%H:%M:%S) - backup of /etc/fstab already exists as /etc/fstab.bk.cis - skipping creation of backup" >> $LOG
				sed -ri "s/^(\s*\S+\s+)$VAR2(\s+\S+\s+\S+)(\s+\S+\s+\S+)(\s*#.*)?\s*$/\1$VAR2\2\,$OPN\3\4/" $SFN
				[[ -n $(grep $MPN $SFN | grep $OPN) ]] && MLOG "- $(date +%D-%H:%M:%S) - OPN has been successfully added for $MPN in $SFN" || MLOG "- $(date +%D-%H:%M:%S) - Adding $OPN for $MPN in $SFN failed - $RN $RNA - ### Manual Remediation Required ###"
			fi
			;;
		3 )
			MLOG "- $(date +%D-%H:%M:%S) - $MPN is configured in /etc/systemd/system/local-fs.target.wants/$MPNM.mount - checking /etc/systemd/system/local-fs.target.wants/$MPNM.mount for $OPN option"
			if [[ -n $TST2 ]] 
			then 
				MLOG "- $(date +%D-%H:%M:%S) - Partition $MPN exists and $OPN is set - No remediation required - Skipping"
			else
				MLOG "- $(date +%D-%H:%M:%S) - Partition $MPN exists and is configured in /etc/systemd/system/local-fs.target.wants/$MPNM.mount - $OPN not set.  adding $OPN to $MPN in /etc/systemd/system/local-fs.target.wants/$MPNM.mount"
				sed -ri "s/^([Oo]ptions\=)(mode\=[0-9]{1,4})(\,strictatime|\s*)(\,\S+|\s+)\s*$/\1\2\3\,$OPN\4/" /etc/systemd/system/local-fs.target.wants/$MPNM.mount
				[[ -n $TST2 ]] && MLOG "- $(date +%D-%H:%M:%S) - $OPN has been successfully added for $MPN in /etc/systemd/system/local-fs.target.wants/$MPNM.mount" || MLOG "- $(date +%D-%H:%M:%S) - Adding $OPN for $MNP in /etc/systemd/system/local-fs.target.wants/$MPNM.mount failed - $RN $RNA - ### Manual Remediation Required ###"
			fi
			;;
		* ) 
			MLOG "- $(date +%D-%H:%M:%S) - Partition $MPN exists, but is not configured in /etc/fstab or /etc/systemd/system/local-fs.target.wants/$MPNM.mount - ### Manual Remediation Required ### - please review your $MPN configuration"
			;;
	esac
	MLOG "- $(date +%D-%H:%M:%S) - Completed - Check \"$OPN\" set on \"$MPN\" partition"
}
# End of function to check if an option is set on a partition