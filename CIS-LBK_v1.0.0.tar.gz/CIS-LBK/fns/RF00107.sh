# Ensure separate partition exists for /var/tmp
RF00107()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	MPN="/var/tmp"
	PECK
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure separate partition exists for /var/tmp