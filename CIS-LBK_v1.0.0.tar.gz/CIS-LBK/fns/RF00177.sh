# Ensure GDM login banner is configured
RF00177()
{
	SFN=/etc/gdm3/greeter.dconf-defaults
	BNA="GDM login banner"
	PNA=gdm3
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	if [[ ! `dpkg -s $PNA | grep Status` = "Status: install ok installed" ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - $PNA is not installed - skipping"
	else
		MLOG "- $(date +%D-%H:%M:%S) - $PNA is installed - Checking $SFN"
		if [[ -s $SFN ]] && [[ -n `egrep -i "^\s*banner\-message\-enable\=true\b(\s+#.*)?$" $SFN` ]] && [[ -n `egrep -i "^\s*banner\-message\-text\=\S+\b.*$" $SFN` ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - $BNA is configured - Skipping"
		else
			if [[ -s $SFN ]]
			then
				MLOG "- $(date +%D-%H:%M:%S) - $BNA is not configured - Remediating"
				FFBK
				[[ -n `egrep -i "^\s*banner\-message\-enable\=.*$" $SFN` ]] && sed -ri "s/^(\s*)(banner\-message\-enable\=)(.*)$/\2true/" $SFN || echo "banner-message-enable=true" >> $SFN
				[[ -n `egrep -i "^\s*banner\-message\-text\=.*$" $SFN` ]]	&& sed -ri "s/^(.*)(banner\-message\-text\=)(.*)$/\2\'Authorized uses only\. All activity may be monitored and reported\.\'" $SFN || echo "banner-message-text='Authorized uses only. All activity may be monitored and reported.'" >> $SFN
				[[ -n `egrep -i "^\s*banner\-message\-enable\=true\b(\s+#.*)?$" $SFN` ]] && [[ -n `egrep -i "^\s*banner\-message\-text\=\S+\b.*$" $SFN` ]] && MLOG "- $(date +%D-%H:%M:%S) - configuration of $BNA successful" || WLOG "- $(date +%D-%H:%M:%S) - configuration of $BNA failed - ### Manual Remediation Required"
			else
				MLOG "- $(date +%D-%H:%M:%S) - $BNA does not exist - Remediating"
				echo "[org/gnome/login-screen]" > $SFN
				echo "banner-message-enable=true" >> $SFN
				echo "banner-message-text='<banner message>'" >> $SFN
				[[ -s $SFN ]] && MLOG "- $(date +%D-%H:%M:%S) - creation of $SFN successful - Remediation Complete" || WLOG "Creation of $SFN Failed - ### Manual Remediation Required ###"
			fi
		fi
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
#End of Ensure GDM login banner is configured