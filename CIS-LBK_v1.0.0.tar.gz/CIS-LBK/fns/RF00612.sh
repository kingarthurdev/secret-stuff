# Ensure no ungrouped files or directories exist
RF00612()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	if [[ -z $(df --local -P | awk {'if (NR!=1) print $6'} | xargs -I '{}' find '{}' -xdev -nogroup) ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - No ungrouped files or directories exist - Skipping"
	else
		WLOG "- $(date +%D-%H:%M:%S) - Ungrouped files or directories exist - $RN $RNA - ### Manual Remediation Required ###"
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure no ungrouped files or directories exist