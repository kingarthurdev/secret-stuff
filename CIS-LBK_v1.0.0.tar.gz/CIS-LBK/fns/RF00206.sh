# Ensure X Window System is not installed
RF00206()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	if [[ -z `dpkg -l xserver-xorg* | egrep -i "^\s*ii\s+xserver-xorg"` ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - X Window System is not installed - Skipping"
	else
		MLOG "- $(date +%D-%H:%M:%S) - X Window System is installed - Remediating"
		PNA=1
		while  [[ ! $PNA = "" ]]
		do
			PNA=`dpkg -l xserver-xorg* | egrep -i "^\s*ii\s+xserver-xorg" |  awk '{print $2}'`
			PNA=`echo $PNA | awk '{print $1}'`
			MLOG "- $(date +%D-%H:%M:%S) - Removing Package: $PNA"
			RPKGE
		done
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure X Window System is not installed