# Ensure SSH PermitUserEnvironment is disabled
RF00532()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	SPN=PermitUserEnvironment
	SPS=no
	FSSHS
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure SSH PermitUserEnvironment is disabled