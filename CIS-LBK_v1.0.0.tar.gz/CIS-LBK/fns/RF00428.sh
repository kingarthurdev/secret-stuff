# Ensure logging is configured
RF00428()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	FDLP # Determins which logging package is being used
	if [[ ! $LCPH = SLN ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - syslog-ng is not being used on this system - Skipping"
	else
		NSR
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure logging is configured