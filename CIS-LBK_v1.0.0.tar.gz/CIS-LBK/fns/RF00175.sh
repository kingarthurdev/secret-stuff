# Ensure permissions on /etc/issue are configured
RF00175()
{
	SFN=/etc/issue
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	FBFP
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
#End of Ensure permissions on /etc/issue are configured