# Function to writh to both the warning log and standard out
WLOG()
{
	echo $1
	echo $1 >> $LOG
	echo $1 >> $WRNL
}
# End of Function to writh to both the warning log and standard out