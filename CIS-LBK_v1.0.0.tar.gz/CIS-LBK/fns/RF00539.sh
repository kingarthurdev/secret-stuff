# Ensure SSH warning banner is configured
RF00539()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	SPN=Banner
	SPS=/etc/issue.net
	FSSHS
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure SSH warning banner is configured