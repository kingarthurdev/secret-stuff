# Ensure separate partition exists for /home
RF00113()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	MPN="/home"
	PECK
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure separate partition exists for /home