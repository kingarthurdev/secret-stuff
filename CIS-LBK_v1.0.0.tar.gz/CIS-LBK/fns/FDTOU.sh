# Function to display the Terms of Use
FDTOU()
{
	clear
	MLOG "- $(date +%D-%H:%M:%S) - Display the Terms of Use"
	cat $MDIR/CIS_TOU.txt
	echo ""
	echo ""
	CONFIRM
}
# End of Function to display the Terms of Use