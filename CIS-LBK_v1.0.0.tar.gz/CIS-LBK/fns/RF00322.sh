# Ensure ICMP redirects are not accepted
RF00322()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	SPN=net.ipv4.conf.all.accept_redirects
	SPS=0
	SPF=net.ipv4.route.flush=1
	FSSCP
	SPN=net.ipv4.conf.default.accept_redirects
	SPS=0
	SPF=net.ipv4.route.flush=1
	FSSCP
	SPN=net.ipv6.conf.all.accept_redirects
	SPS=0
	SPF=net.ipv6.route.flush=1
	FSSCP
	SPN=net.ipv6.conf.default.accept_redirects
	SPS=0
	SPF=net.ipv6.route.flush=1
	FSSCP
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure ICMP redirects are not accepted