# Ensure authentication required for single user mode
RF00143()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	if [[ -z `grep ^root:[*\!]: /etc/shadow` ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - Authentication is required for single user mode, skipping"
	else
		WLOG "- $(date +%D-%H:%M:%S) - $RN $RNA - ### Manual Remediation Required ###"
		WLOG "- $(date +%D-%H:%M:%S) - ### Please run the command: passwd root ### to require authentication for single user mode"
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure authentication required for single user mode