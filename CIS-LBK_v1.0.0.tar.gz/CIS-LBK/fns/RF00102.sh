# Ensure /tmp is configured
RF00102()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	if [[ -n $(systemctl is-enabled tmp.mount | grep enabled) ]] && [[ -s /etc/systemd/system/local-fs.target.wants/tmp.mount ]] || [[ -n $(egrep -i "^\s*\S+\s+\/tmp\s+\S+\s*.*$" /etc/fstab) ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - /tmp is configured - Skipping"
	else
		MLOG "- $(date +%D-%H:%M:%S) - /tmp is not configured - Remediating"
		MLOG "- $(date +%D-%H:%M:%S) - Starting - Configure /tmp with /etc/fstab"
		if [[ -d /tmp ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - directory /tmp already exists"
		else
			MLOG "- $(date +%D-%H:%M:%S) - directory /tmp doesn't exist - creating /tmp"
			mkdir /tmp
		fi

		if [[ -d /tmp ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - Successful - directory /tmp created or already existed"
			SFN=/etc/fstab
			FFBK
			MLOG "- $(date +%D-%H:%M:%S) - Starting - create entry in $SFN for /tmp"
			echo "tmpfs	/tmp	tmpfs     defaults,rw,nosuid,nodev,noexec,relatime  0 0" >> $SFN
			if [[ -n $(egrep -i "^\s*\S+\s+\/tmp\s+\S+\s*.*$" $SFN) ]]
			then
				 MLOG "$(date +%D-%H:%M:%S) - Successful - created entry in $SFN for /tmp"
				 mount -o remount,nosuid,nodev,noexec /tmp
			else
				WLOG "$(date +%D-%H:%M:%S) - Failed - created entry in $SFN for /tmp - $RN $RNA - ### Manual Remediation Required ###"
			fi
		else
			WLOG "- $(date +%D-%H:%M:%S) - Failed - directory  /tmp not created - $RN $RNA - ### Manual Remediation Required ###"
		fi
		MLOG "- $(date +%D-%H:%M:%S) - Completed - Configure /tmp with /etc/fstab"
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure /tmp is configured