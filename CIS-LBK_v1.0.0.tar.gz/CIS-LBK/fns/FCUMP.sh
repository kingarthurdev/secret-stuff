# Function to check, update, or modify PAM
FCUMP()
{
	# PPN={PAM Parameter Name}
	# PPS={PAM Parmaeter "acceptable" Settings}
	# PPSR={PAM Parameter Recomended setting}
	SFN=/etc/security/pwquality.conf
	MLOG "- $(date +%D-%H:%M:%S) - Starting - check $PPN"
	if [[ -n `egrep -i "^\s*$PPN\s*\=\s*$PPS\s*(\s+#.*)?$" $SFN` ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - $PPN is set correctly in $SFN - Skipping"
	else
		MLOG "- $(date +%D-%H:%M:%S) - $PPN is not set correctly in $SFN - Remediating"
		FFBK
		[[ -n `egrep -i "^\s*$PPN" $SFN` ]] && sed -ri "s/^(\s*)($PPN)(\s*\=)(\s*\S+\b)(\s*(\s+#.*)?)$/\1\2\3 $PPSR\5/" $SFN || echo "$PPN = $PPSR" >> $SFN
		[[ -n `egrep -i "^\s*$PPN\s*\=\s*$PPS\s*(\s+#.*)?$" $SFN` ]] && MLOG "- $(date +%D-%H:%M:%S) - Successful - Updating $SFN with $PPN = $PPSR" || WLOG "- $(date +%D-%H:%M:%S) - Failed - Updating $SFN with $PPN = $PPSR - $RN $RNA - ### Manual Remediation Required ###"
	fi
	MLOG "- $(date +%D-%H:%M:%S) -Completed - check $PPN"
}
# End of Function to check, update, or modify PAM