BANR()
{
	echo "    ###################################################### "
	echo "    # Platform Remediation Kit for Debian Linux 9 v1.0.0 # "
	echo "    # This Remediation Kit works in conjunction with     # "
	echo "    # CIS Debian Linux 9 Benchmark v1.0.0                # "
	echo "    # This script is the property of:                    # "
	echo "    # Center for Internet Security (CIS)                 # "
	echo "    ###################################################### "
}
# End of print bannor to Screen