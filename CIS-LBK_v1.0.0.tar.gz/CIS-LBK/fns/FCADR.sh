# Function to check auditd rules
FCADR()
{
	# VRX={Regex to search for}
	# ARN={Audit rule Name}
	ARF=/etc/audit/audit.rules
	SFN=/etc/audit/rules.d/audit.rules
	MLOG "- $(date +%D-%H:%M:%S) - Starting - check for auditd rule - \"$ARN\""
	[[ ! -f $SFN ]] && touch $SFN
#	if [[ -n `auditctl -l | egrep "$VRX"` ]] && [[ -n `egrep "$VRX" $ARF` ]] && [[ -n `egrep "$VRX" $SFN` ]]
	if [[ -n $(egrep "$VRX" $ARF) ]] && [[ -n $(egrep "$VRX" $SFN) ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - Audit rule exists - Skipping"
	elif [[ -n $(egrep "$VRX" $SFN) ]] && [[ -z $(egrep "$VRX" $ARF) ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - Auditd needs to be updated from $SFN - Flagging auditd to be reloaded"
		RARF=y
	else
		MLOG "- $(date +%D-%H:%M:%S) - $SFN needs to be updated with audit rule"
		FFBK
		echo "$ARN" >> $SFN
		if [[ -n $(egrep "$VRX" $SFN) ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - update $SFN with audit rule - successful"
			MLOG "- $(date +%D-%H:%M:%S) - Auditd needs to be updated from $SFN - Flagging auditd to be reloaded"
			RARF=y
		else
			WLOG "- $(date +%D-%H:%M:%S) - update $SFN with audit rule - Failed - ### Manual Remediation Required ###"
		fi
	fi
	# Unset function local variables
	ARF=""
	SFN=""
	MLOG "- $(date +%D-%H:%M:%S) - Completed - check for auditd rule - \"$ARN\""
}
# End of Function to check auditd rules