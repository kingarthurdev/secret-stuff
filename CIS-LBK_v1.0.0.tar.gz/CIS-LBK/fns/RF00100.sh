# Ensure mounting of hfsplus filesystems is disabled
RF00100()
{
	#RN=1.1.1.4
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	FN=hfsplus
	FSCK
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure mounting of hfsplus filesystems is disabled