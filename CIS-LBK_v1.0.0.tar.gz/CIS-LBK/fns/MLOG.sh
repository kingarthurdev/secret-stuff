# Function to wite to both the main log and standard out
MLOG()
{
	echo $1
	echo $1 >> $LOG
}
# End of Function to wite to both the main log and standard out