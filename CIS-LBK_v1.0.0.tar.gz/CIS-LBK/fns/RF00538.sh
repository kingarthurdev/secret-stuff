# Ensure SSH access is limited
RF00538()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	# SPN=LoginGraceTime
	# SPS="([1-9]|[1-5][0-9]|60)"
	SNF=/etc/ssh/sshd_config
	MLOG "- $(date +%D-%H:%M:%S) - Starting - Check if SSH access is limited"
	if [[ -n $(sshd -T | egrep "^(allowusers|allowgroups|denyusers|denygroups)\s+(\S+).*$") ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - $(sshd -T | egrep "^(allowusers|allowgroups|denyusers|denygroups)\s+(\S+).*$") - is configured - skipping"
	else
		WLOG "- $(date +%D-%H:%M:%S) - SSH access is not limited - $RN $RNA - ### Manual Remediation Required ###"
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure SSH access is limited