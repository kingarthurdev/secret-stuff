# Ensure only strong MAC algorithms are used
RF00534()
{
	# Black list and whit list are maintained as seporate files for ease of updating in case of changes
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	SFN=/etc/ssh/sshd_config
	SPN=MACs
	[[ -z $OSSHV ]] && FDOSV
	MLOG "- $(date +%D-%H:%M:%S) - System is running openSSH version $OSSHV"
	if [[ ! $OSSHV < 7.0 ]]
	then 
		BFN=ssh7_mblacklist.txt
		WFN=ssh7_mwlist.txt
	elif [[ $OSSHV < 7.0 && $OSSHV > 6.4 ]]
	then
		BFN=ssh6.5_mblacklist.txt
		WFN=ssh6.5_mwlist.txt
	else
		BFN=ssh6_mblacklist.txt
		WFN=ssh6_mwlist.txt
	fi
	for SPS in $(cat $MDIR/$BFN)
	do
		MLOG "- $(date +%D-%H:%M:%S) - Starting - Check $SFN $SPN for blacklisted $SPS"
		SPS=${SPS/"."/"\."}
#		if [[ -n $(sshd -T | egrep -i "^\s*($SPN\s+)(\S*)($SPS[,\s*])(\S*)(\s+#.*)?$") ]]
		if [[ -n $(sshd -T | egrep -i "^\s*$SPN\s+" | grep -i $SPS) ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - Blacklisted $SPS exists - Remediating"
			FFBK
			[[ -n $(grep -i "^$SPN" $SFN) ]] && sed -ri "s/^\s*($SPN\s+)(\S*)($SPS(,|\s*))(\S*)(\s+#.*)?$/\1\2\5\6/" $SFN || echo "$SPN $(cat $MDIR/$WFN)" >> $SFN
			[[ -z $(sshd -T | egrep -i "^\s*($SPN\s+)(\S*)($SPS[,\s*])(\S*)(\s+#.*)?$") ]] && MLOG "- $(date +%D-%H:%M:%S) - Successful - Blacklisted $SPS removed" || WLOG "- $(date +%D-%H:%M:%S) - Failed - Blacklisted $SPS still exists - $RN $RNA - ### Manual Remediation Required ###"
		else
			MLOG "- $(date +%D-%H:%M:%S) - Blacklisted $SPS doesn't exist - Skipping"
		fi
		MLOG "- $(date +%D-%H:%M:%S) - Completed - Check $SFN $SPN for blacklisted $SPS"
	done
	MLOG "- $(date +%D-%H:%M:%S) - Starting - Add $SPN to $SFN"
	if [[ -n $(grep -i ^$SPN $SFN) ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - $SPN exists in $SFN - Skipping"
	else
		MLOG "- $(date +%D-%H:%M:%S) - $SPN doesn't exist in $SFN - adding current $SPN to $SFN"
		echo "$SPN $(sshd -T | grep -i $SPN | cut -d' ' -f2)" | sed "s/,*$//" >> $SFN
		[[ -n $(grep -i ^$SPN $SFN) ]] && MLOG "- $(date +%D-%H:%M:%S) - Successful - $SPN added to $SFN" || WLOG "- $(date +%D-%H:%M:%S) - Failed - $SPN  not added to $SFN - $RN $RNA - ### Manual Remediation Required ###"
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - Add $SPN to $SFN"
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure only strong MAC algorithms are used