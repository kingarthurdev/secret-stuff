# Ensure permissions on /etc/hosts.allow are configured
RF00334()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	if [[ -n `stat /etc/hosts.allow | egrep -i "^Access\:\s+\(0[46][04][04]\/-r[-w]-[-r]--[-r]--\)\s+Uid\:\s+\(\s+0\/\s+root\)\s+Gid\:\s+\(\s+0\/\s+root\)\s*$"` ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - permissions on /etc/hosts.allow are configured - Skipping"
	else
		MLOG "- $(date +%D-%H:%M:%S) - Updating owner and group to root:root"
		SFN=/etc/hosts.allow
		FLOSP
		chown root:root /etc/hosts.allow
		MLOG "- $(date +%D-%H:%M:%S) - Updating Access to remove write, and execute from group and other"
		chmod og-wx /etc/hosts.allow
		if [[ -n `stat /etc/hosts.allow | egrep -i "^Access\:\s+\(0[46][04][04]\/-r[-w]-[-r]--[-r]--\)\s+Uid\:\s+\(\s+0\/\s+root\)\s+Gid\:\s+\(\s+0\/\s+root\)\s*$"` ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - Successful - ownership and access successful modified"
		else
			WLOG "- $(date +%D-%H:%M:%S) - Failed - ownership and access not modified - $RN $RNA - ### Manual Remediation Required ###"
		fi
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure permissions on /etc/hosts.allow are configured