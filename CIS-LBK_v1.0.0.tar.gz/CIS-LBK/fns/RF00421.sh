# Ensure rsyslog Service is enabled
RF00421()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	FDLP # Determins which logging package is being used
	if [[ ! $LCPH = RSL ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - rsyslog is not being used on this system - Skipping"
	else
		DAEN=rsyslog
		FTESD
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure rsyslog Service is enabled