# Ensure permissions on /etc/cron.monthly are configured
RF00506()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	SFN=/etc/cron.monthly
	FCCDP
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure permissions on /etc/cron.monthly are configured