# Ensure bogus ICMP responses are ignored
RF00326()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	SPN=net.ipv4.icmp_ignore_bogus_error_responses
	SPS=1
	SPF=net.ipv4.route.flush=1
	FSSCP
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure bogus ICMP responses are ignored