# Ensure events that modify user/group information are collected
RF00407()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	ARN="-w /etc/group -p wa -k identity"
	VRX="^\s*-w\s+\/etc\/group\s+-p\s+wa\s+-k\s+identity\s*(#.*)?$"
	FCADR
	ARN="-w /etc/passwd -p wa -k identity"
	VRX="^\s*-w\s+/etc/passwd\s+-p\s+wa\s+-k\s+identity\s*(#.*)?$"
	FCADR
	ARN="-w /etc/gshadow -p wa -k identity"
	VRX="^\s*-w\s+\/etc\/gshadow\s+-p\s+wa\s+-k\s+identity\s*(#.*)?$"
	FCADR
	ARN="-w /etc/shadow -p wa -k identity"
	VRX="^\s*-w\s+\/etc\/shadow\s+-p\s+wa\s+-k\s+identity\s*(#.*)?$"
	FCADR
	ARN="-w /etc/security/opasswd -p wa -k identity"
	VRX="^\s*-w\s+\/etc\/security\/opasswd\s+-p\s+wa\s+-k\s+identity\s*(#.*)?$"
	FCADR
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure events that modify user/group information are collected