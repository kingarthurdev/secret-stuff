# Ensure core dumps are restricted
RF00151()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	OPU="\*"
	OPL=hard
	OPN=core
	OPS=0
	RCKSL
	OPN=fs.suid_dumpable
	OPS=0
	RCKSC
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure core dumps are restricted

