# Ensure session initiation information is collected
RF00411()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	ARN="-w /var/run/utmp -p wa -k session"
	VRX="^\s*-w\s+\/var\/run\/utmp\s+-p\s+wa\s+-k\s+session\s*(#.*)?$"
	FCADR
	ARN="-w /var/log/wtmp -p wa -k logins"
	VRX="^\s*-w\s+\/var\/log\/wtmp\s+-p\s+wa\s+-k\s+logins\s*(#.*)?$"
	FCADR
	ARN="-w /var/log/btmp -p wa -k logins"
	VRX="^\s*-w\s+\/var\/log\/btmp\s+-p\s+wa\s+-k\s+logins\s*(#.*)?$"
	FCADR
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure session initiation information is collected