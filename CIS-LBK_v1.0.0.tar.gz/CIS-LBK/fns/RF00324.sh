# Ensure suspicious packets are logged
RF00324()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	SPN=net.ipv4.conf.all.log_martians
	SPS=1
	SPF=net.ipv4.route.flush=1
	FSSCP
	SPN=net.ipv4.conf.default.log_martians
	SPS=1
	SPF=net.ipv4.route.flush=1
	FSSCP
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure suspicious packets are logged