# Ensure root is the only UID 0 account
RF00625()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	if [[ $(cat /etc/passwd | awk -F: '($3 == 0) { print $1 }') = "root" ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - root is the only UID 0 account - Skipping"
	else
		WLOG "- $(date +%D-%H:%M:%S) - root is not the only UID 0 account - $RN $RNA - ### Manual Remediation Required ###"
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure root is the only UID 0 account