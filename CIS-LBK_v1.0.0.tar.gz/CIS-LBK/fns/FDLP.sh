# Function to determine which logging package is used
FDLP()
{
	
	SFSLP()
	{
		MLOG "- $(date +%D-%H:%M:%S) - Starting - Logging Package Selection"
		clear
		echo "  either no logging package is installed or" 
		echo "  both rsyslog and syslog-ng are installed on this system"
		echo "  Please select which Logging package you would like to use"
		echo ""
		echo "  Please enter 1 for rsyslog"
		echo "  Please enter 2 for syslog-ng"
		echo "  Please enter 0 if you don't want either logging package"
		echo " [1|2|0] : "
		read ANSR
		case $ANSR in
			1 ) 
				clear
				MLOG "- $(date +%D-%H:%M:%S) - you responded with $ANSR - rsyslog will be installed and/or configured"
				MLOG "- $(date +%D-%H:%M:%S) - syslog-ng will be removed if it exists on the system"
				LPCH=RSL
				sleep 2
				;;
			2 )
				clear
				MLOG "- $(date +%D-%H:%M:%S) - you responded with $ANSR - syslog-ng will be installed and/or configured"
				MLOG "- $(date +%D-%H:%M:%S) - rsyslog will be removed if it exists on the system"
				LPCH=SLN
				sleep 2
				;;
			0 )
				clear
				WLOG "- $(date +%D-%H:%M:%S) - you responded with $ANSR - No logging package will be installed/configured - ### Manual Remediation Required ### -"
				LPCH=NONE
				sleep 2
				;;
			* )
				clear
				WLOG "- $(date +%D-%H:%M:%S) - you responded with $ANSR - Please Respond with 1, 2, or 0 "
				sleep 2
				;;
		esac
		MLOG "- $(date +%D-%H:%M:%S) - Completed - Logging Package Selection"
	}
	# Subfunction to determine logging package
	SFILP()
	{
		MLOG "- $(date +%D-%H:%M:%S) - Starting - Determine Logging Package"
		if [[ -n `dpkg -s rsyslog | egrep -i "^\s*Status\:\s+install\s+ok\s+installed\s*$"` ]] && [[ -n `dpkg -s syslog-ng | egrep -i "^\s*Status\:\s+install\s+ok\s+installed\s*$"` ]]
		then
			SFSLP
			[[ $LPCH = RSL ]] && PNA=syslog-ng && RPKGE
			[[ $LPCH = SLN ]] && PNA=rsyslog &&	RPKGE
		fi
		[[ -n `dpkg -s rsyslog | egrep -i "^\s*Status\:\s+install\s+ok\s+installed\s*$"` ]] && [[ -z `dpkg -s syslog-ng | egrep -i "^\s*Status\:\s+install\s+ok\s+installed\s*$"` ]] && LPCH=RSL
		[[ -z `dpkg -s rsyslog | egrep -i "^\s*Status\:\s+install\s+ok\s+installed\s*$"` ]] && [[ -n `dpkg -s syslog-ng | egrep -i "^\s*Status\:\s+install\s+ok\s+installed\s*$"` ]] && LPCH=SLN
		if [[ -z `dpkg -s rsyslog | egrep -i "^\s*Status\:\s+install\s+ok\s+installed\s*$"` ]] && [[ -z `dpkg -s syslog-ng | egrep -i "^\s*Status\:\s+install\s+ok\s+installed\s*$"` ]] ||  [[ -z $LPCH ]]
		then
			SFSLP
			[[ $LPCH = RSL ]] && PNA=rsyslog && FIPKG
			[[ $LPCH = SLN ]] && PNA=syslog-ng && FIPKG
		fi
		case $LPCH in
			RSL )
				MLOG "- $(date +%D-%H:%M:%S) - rsyslog wil be configured on your system"
				;;
			SLN )
				MLOG "- $(date +%D-%H:%M:%S) - syslog-ng wil be configured on your system"
				;;
			NONE )
				WLOG "- $(date +%D-%H:%M:%S) - no logging wil be configured on your system - ### Manual Remediation Required ###"
				;;
			* )
				;;
		esac
		MLOG "- $(date +%D-%H:%M:%S) - Completed - Determine Logging Package"
	}
	# End of Subfunction to determine logging package
	while [[ -z $LPCH ]]
	do
		SFILP
	done
}
# End of Function to determine which logging package is used