# Ensure mounting of jffs2 filesystems is disabled
RF00098()
{
	#RN=1.1.1.2
	FN=jffs2
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	FSCK
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure mounting of jffs2 filesystems is disabled