# Ensure openbsd-inetd is not installed
RF00202()
{
	PNA=openbsd-inetd
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	RPKGE
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure openbsd-inetd is not installed