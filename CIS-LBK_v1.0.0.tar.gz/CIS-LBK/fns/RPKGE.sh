# Function to remove a package
RPKGE()
{
	# RN={Recomendation Number}
	# RNA={"Recomendation Name"}
	# PNA={Package Name}
	MLOG "- $(date +%D-%H:%M:%S) - Starting - Removal of package $PNA"
	if [[ ! `dpkg -s $PNA | grep Status` = "Status: install ok installed" ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - $PNA is not installed - skipping"
	else
		MLOG "- $(date +%D-%H:%M:%S) - $PNA is installed - Remediating - removing package $PNA"
		dpkg -s $PNA && apt-get -y purge $PNA
		if [[ ! `dpkg -s $PNA | grep Status` = "Status: install ok installed" ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - $PNA removial successful"
		else
			WLOG "- $(date +%D-%H:%M:%S) - $PNA removial failed - ### Manual Remediation Required ###"
		fi
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - Removial of package $PNA"
}
# End of function to remove a package