# Function to check and set a /etc/sysctl.conf parameter
FSSCP()
{
	# SPN={Name of parameter to check and/or set in /etc/sysctl.conf}
	# SPS={Setting for the parameter in /etc/sysctl.conf}
	# SPF={route to flish ie net.ipv6.conf.all.forwarding=0}
	SCN=/etc/sysctl.conf
	SDP="/etc/sysctl.d/*"
	
	MLOG "- $(date +%D-%H:%M:%S) - Starting - verifying that $SPN is set"
	if [[ -n $(egrep -i "^\s*$SPN\s*\=\s*$SPS" $SCN) ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - $SPN = $SPS is set in $SCN - Loading into running config"
	elif [[ -n $(egrep -i -d skip "^\s*$SPN\s*\=\s*$SPS" $SDP) ]] && SFN=$(egrep -i -d skip "^\s*$SPN\s*\=\s*$SPS" $SDP | cut -d: -f1)
	then
		MLOG "- $(date +%D-%H:%M:%S) - $SPN = $SPS is set in $SFN - Loading into running config"
	else
		MLOG "- $(date +%D-%H:%M:%S) - $SPN = $SPS not is set - updating $SCN"
		SFN=$SCN
		FFBK
		if [[ -n $(egrep -i "^\s*(#)\s*($SPN\s*)(=)(\s*\S+\b).*$" $SCN) ]]
		then
			sed -ri "s/^\s*(#)\s*($SPN\s*)(=)(\s*\S+\b).*$/\2 = $SPS/" $SFN
		elif [[ -n $(egrep -i "^\s*($SPN\s*)(=)(\s*\S+\b).*$" $SCN) ]]
		then
			sed -ri "s/^\s*($SPN\s*)(=)(\s*\S+\b).*$/\1 = $SPS/" $SFN
		else
			echo "$SPN = $SPS" >> $SFN
		fi
		if [[ -n $(egrep -i "^\s*$SPN\s*\=\s*$SPS" $SCN) ]] || [[ -n $(egrep -i -d skip "^\s*$SPN\s*\=\s*$SPS" $SDP) ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - Update of $SFN with $SPN = $SPS successful"
#			SCPR=y
		else
			WLOG "- $(date +%D-%H:%M:%S) - Update of $SFN with $SPN = $SPS failed - ### Manual Remediation Required"
		fi
	fi
	sysctl -w $SPN=$SPS
	sysctl -w $SPF
	MLOG "- $(date +%D-%H:%M:%S) - Starting - verifying that $SPN is set"
}
# End of # Function to check and set a /etc/sysctl.conf parameter