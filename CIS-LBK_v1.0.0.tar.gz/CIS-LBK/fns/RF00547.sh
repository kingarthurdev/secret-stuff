# Ensure password expiration warning days is 7 or more
RF00547()
{
	SFN=/etc/login.defs
	PON=PASS_WARN_AGE
	PORX="^\s*Number\s+of\s+days\s+of\s+warning\s+before\s+password\s+expires\s+\:\s*\S+\s*$"
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	MLOG "- $(date +%D-%H:%M:%S) - Starting - check $PON in $SFN"
	if [[ $(egrep -i "^\s*$PON\s+\S+\s*(\s+#.*)?$" $SFN | cut -f2) > 6 ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - password expiration warning days is \"$(egrep -i "^\s*$PON\s+\S+\s*(\s+#.*)?$" $SFN | cut -f2)\" - Skipping update $SFN"
	else
		MLOG "- $(date +%D-%H:%M:%S) - password expiration warning days is \"$(egrep -i "^\s*$PON\s+\S+\s*(\s+#.*)?$" $SFN | cut -f2)\" - Remediating"
		FFBK
		[[ -n $(egrep -i "^\s*$PON\s+\S+\s*(\s+#.*)?$" $SFN) ]] && sed -ri "s/^(\s*$PON)(\s+\S+)\s*(\s+#.*)?$/\1 7\3/" $SFN || echo "$PON 7" >> $SFN
		if [[ $(egrep -i "^\s*$PON\s+\S+\s*(\s+#.*)?$" $SFN | cut -f2) > 6 ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - Successful - $PON updated to \"$(egrep -i "^\s*$PON\s+\S+\s*(\s+#.*)?$" $SFN | cut -f2)\" in $SFN"
		else
			WLOG "- $(date +%D-%H:%M:%S) - Failed - $PON currently \"$(egrep -i "^\s*$PON\s+\S+\s*(\s+#.*)?$" $SFN | cut -f2)\" in $SFN - $RN $RNA - ### Manual Remediation Required ###"
		fi
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - check $PON in $SFN"
	MLOG "- $(date +%D-%H:%M:%S) - Starting - check users $PON"
	for MPD in $(egrep ^[^:]+:[^\!*] /etc/shadow | cut -d: -f1)
	do
		if [[ $(chage --list $MPD | egrep -i "$PORX" | awk '{print $10}') > 6 ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - $PON for $MPD is $(chage --list $MPD | egrep -i "$PORX" | awk '{print $10}') - skipping"
		else
			MLOG MLOG "- $(date +%D-%H:%M:%S) - $PON for $MPD is $(chage --list $MPD | egrep -i "$PORX" | awk '{print $10}') - Remediating"
			chage --warndays 7 $MPD
			if [[ $(chage --list $MPD | egrep -i "$PORX" | awk '{print $10}') > 6 ]]
			then
				MLOG "- $(date +%D-%H:%M:%S) - Successful - user $MPD $PON is now $(chage --list $MPD | egrep -i "$PORX" | awk '{print $10}')"
			else
				WLOG "- $(date +%D-%H:%M:%S) - Failed - user $MPD $PON is $(chage --list $MPD | egrep -i "$PORX" | awk '{print $10}') - $RN $RNA - ### Manual Remediation Required ###"
			fi
		fi
	done
	MLOG "- $(date +%D-%H:%M:%S) - Completed - check users $PON"
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure password expiration warning days is 7 or more