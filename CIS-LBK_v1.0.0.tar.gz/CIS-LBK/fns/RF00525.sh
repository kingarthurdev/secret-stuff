# Ensure SSH LogLevel is appropriate
RF00525()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	SPN=LogLevel
	SPS="(VERBOSE|INFO)"
	SNF=/etc/ssh/sshd_config
	MLOG "- $(date +%D-%H:%M:%S) - Starting - Check if $SPN is set to $SPS"
	if [[ -n `sshd -T | egrep -i "^\s*$SPN\s+$SPS\s*(\s+#.*)?$"` ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - $SPN corectly set to $SPS - Skipping"
	else
		MLOG "- $(date +%D-%H:%M:%S) - $SPN not corectly set to $SPS - Remediating"
		FFBK
		[[ -n `egrep -i "^(\s*)($SPN\s+)(\S+\s*)((\s+#.*)?)$"` ]] && sed -ri "s/^(\s*)($SFN\s+)(\S+\s*)((\s+#.*)?)$/\1\2VERBOSE\4/" $SFN || echo "$SPN VERBOSE" >> $SFN
		RSSHD=y
		[[ -n `egrep -i "^\s*$SPN\s+$SPS\s*(\s+#.*)?$" $SFN` ]] && MLOG "- $(date +%D-%H:%M:%S) - Successful - $SPN corectly set to $SPS" || WLOG "- $(date +%D-%H:%M:%S) - FAILED - $SPN corectly not set to $SPS - $RN $RNA - ### Manual Remediation Required ###"
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - Check if $SPN is set to $SPS"
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure SSH LogLevel is appropriate