# Functon to check/modify sshd parameters
FSSHS()
{
	# RN={Remediation Number}
	# RNA={Remediation Name}
	# SPN={SSHD Parameter name}
	# SPS={SSHD Parameter Setting}
	SFN=/etc/ssh/sshd_config
	MLOG "- $(date +%D-%H:%M:%S) - Starting - Check if $SPN is set to $SPS"
	if [[ -n $(sshd -T | egrep -i "^\s*$SPN\s+$SPS\s*(\s+#.*)?$") ]] && [[ -n $(egrep -i "^\s*$SPN\s+$SPS\s*(\s+#.*)?$" $SFN) ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - $SPN corectly set to $(sshd -T | egrep -i "^\s*$SPN\s+$SPS\s*(\s+#.*)?$" | cut -d' ' -f2) - Skipping"
	else
		MLOG "- $(date +%D-%H:%M:%S) - $SPN set to $(sshd -T | egrep -i "^\s*$SPN\s+$SPS\s*(\s+#.*)?$" | cut -d' ' -f2) - Remediating"
		FFBK
		[[ -n $(egrep -i "^(\s*)($SPN\s+)(\S+\s*)((\s+#.*)?)$" $SFN) ]] && sed -ri "s/^(\s*)($SPN\s+)(\S+\s*)((\s+#.*)?)$/\1\2$SPS\4/" $SFN || echo "$SPN $SPS" >> $SFN
		RSSHD=y
		[[ -n $(egrep -i "^\s*$SPN\s+$SPS\s*(\s+#.*)?$" $SFN) ]] && MLOG "- $(date +%D-%H:%M:%S) - Successful - $SPN corectly set to $(sshd -T | egrep -i "^\s*$SPN\s+$SPS\s*(\s+#.*)?$" | cut -d' ' -f2)" || WLOG "- $(date +%D-%H:%M:%S) - FAILED - $SPN corectly set to $(sshd -T | egrep -i "^\s*$SPN\s+$SPS\s*(\s+#.*)?$" | cut -d' ' -f2) - $RN $RNA - ### Manual Remediation Required ###"
	fi
	RSSHD=y
	MLOG "- $(date +%D-%H:%M:%S) - Completed - Check if $SPN is set to $SPS"
}
# End of Functon to check/modify sshd parameters