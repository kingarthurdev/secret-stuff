# Ensure use of privileged commands is collected
RF00414()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	for FNA in `find / -xdev \( -perm -4000 -o -perm -2000 \) -type f`
	do
		ARN="-a always,exit -F path=$FNA -F perm=x -F auid>=1000 -F auid!=4294967295 -k privileged"
		FNA=$(echo $FNA | sed 's#/#\\/#g')
		VRX="^\s*-a\s+(always,exit|exit,always)\s+-F\s+path=$FNA\s+-F\s+perm=x\s+-F\s+auid>=1000\s+-F\s+auid!=4294967295\s+-k\s+privileged\s*(#.*)?$"
		FCADR
	done
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure use of privileged commands is collected