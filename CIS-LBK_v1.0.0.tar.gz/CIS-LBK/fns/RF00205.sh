# Ensure chrony is configured
RF00205()
{
	SFN=/etc/chrony/chrony.conf
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	# FTSTPE # Function to ensure that the TSPDEC variable is set
	if [[ ! $(dpkg -s chrony | grep Status) = "Status: install ok installed" ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - chrony is not installed - no configuration required - Skipping"
	else
		MLOG "- $(date +%D-%H:%M:%S) - checking remote server is configured in $SFN"
		[[ -n $(egrep -i "^(server|pool)\s+\S+.*$" $SFN) ]] && MLOG "- $(date +%D-%H:%M:%S) - A remote server is configured in $SFN" || WLOG "- $(date +%D-%H:%M:%S) - A remote server is not configured in $SFN - ### Manual Remediation Required ###"
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure chrony is configured