# Ensure AppArmor is enabled in the bootloader configuration
# !!! May require updating to support Fedora and SUSE family distros !!!
RF00165()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	MACTPE # Function to ensure that the MACDEC variable is set
	if [[ ! $MACDEC = APAR ]]
	then
		FNAPAR
	else
#		if [[ -n $(egrep "^GRUB_CMDLINE_LINUX=\".*(\bapparmor=1\b).*\"\s*$" $GCFL) ]] && [[ -n $(egrep "^GRUB_CMDLINE_LINUX=\".*(\bsecurity=apparmor\b).*\"\s*$" $GCFL) ]]
		if [[ -n $(egrep "^\s*\blinux\b.*(\bapparmor=1\b).*$" $GCFL) ]] && [[ -n $(egrep "^\s*\blinux\b.*(\bsecurity=apparmor\b).*$" $GCFL) ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - AppArmor is enabled in the bootloader configuration - Skipping"
#		elif [[ -n $(egrep "^GRUB_CMDLINE_LINUX_DEFAULT=\".*(\bapparmor=1\b).*\"\s*$" $GCFL) ]] && [[ -n $(egrep "^GRUB_CMDLINE_LINUX_DEFAULT=\".*(\bsecurity=apparmor\b).*\"\s*$" $GCFL) ]]
#		then
#			MLOG "- $(date +%D-%H:%M:%S) - AppArmor is enabled in the bootloader configuration - Skipping"
		else
			MLOG "- $(date +%D-%H:%M:%S) - AppArmor is not enabled in the bootloader configuration - Remediating"
			SFN=$GCFL
			FFBK
			SFN=/etc/default/grub
			FFBK
			MLOG "- $(date +%D-%H:%M:%S) - Starting - Adding options to $SFN"
			# Check and add security=apparmor
			[[ -n $(egrep "^(GRUB_CMDLINE_LINUX=\")(.*)(\bsecurity=\S+\b)(.*)(\")\s*$" $SFN) ]] && sed -ri "s/^(GRUB_CMDLINE_LINUX=\")(.*)(\bsecurity=\S+\b)(.*)(\")\s*$/\1security=apparmor \2\4\5/" $SFN || sed -ri "s/^(GRUB_CMDLINE_LINUX=\")(.*)(\")\s*$/\1security=apparmor \2\3/" $SFN
			[[ -n $(egrep "^GRUB_CMDLINE_LINUX_DEFAULT=\".*(\bsecurity=\S+\b).*\"\s*$" $SFN) ]] && sed -ri "s/^(GRUB_CMDLINE_LINUX=\")(.*)(\bsecurity=\S+\b)(.*)(\")\s*$/\1\2\4\5/" $SFN
			[[ -n $(egrep "^GRUB_CMDLINE_LINUX=\".*(\bsecurity=apparmor\b).*\"\s*$" $SFN) ]] && MLOG "- $(date +%D-%H:%M:%S) - security=apparmor successfully added to $SFN" || WLOG "- $(date +%D-%H:%M:%S) - ### WARNING ### - adding security=apparmor to $SFN failed - ### Manual Remediation Required ###"
			# Check and add apparmor=1
			[[ -n $(egrep "^GRUB_CMDLINE_LINUX=\".*(\bapparmor=0\b).*\"\s*$" $SFN) ]] && sed -ri "s/^(GRUB_CMDLINE_LINUX=\")(.*)(\bapparmor=[0,1]\b)(.*)(\")\s*$/\1\2apparmor=1 \4\5/" $SFN || sed -ri "s/^(GRUB_CMDLINE_LINUX=\")(.*)(\")\s*$/\1apparmor=1 \2\3/" $SFN
			[[ -n $(egrep "^GRUB_CMDLINE_LINUX_DEFAULT=\".*(\bapparmor=[0-9]\b).*\"\s*$" $SFN) ]] && sed -ri "s/^(GRUB_CMDLINE_LINUX_DEFAULT=\")(.*)(\bapparmor=[0-9]\b)(.*)(\")\s*$/\1\2\4\5/" $SFN
			[[ -n $(egrep "^GRUB_CMDLINE_LINUX=\".*(\bapparmor=1\b).*\"\s*$" $SFN) ]] && MLOG "- $(date +%D-%H:%M:%S) - apparmor=1 successfully added to $SFN" || WLOG "- $(date +%D-%H:%M:%S) - ### WARNING ### - adding apparmor=1 to $SFN failed - ### Manual Remediation Required ###"
			MLOG "- $(date +%D-%H:%M:%S) - Completed - Adding options to $SFN"
			#MLOG "- $(date +%D-%H:%M:%S) - Setting Flag to update the grub2 configuration when remediation is complete"
			MLOG "- $(date +%D-%H:%M:%S) - Starting - update the grub2 configuration"
#			if [[ $OSN =~ (debian|ubuntu) ]]
#			then
#				update-grub
#			elif [[ $OSN =~ (rhel|centos|al2) ]]
#			then
#				grub2-mkconfig -o /boot/grub2/grub.cfg
#			else
#				WLOG "- $(date +%D-%H:%M:%S) - Unable to update grub(2) configuration - $RN $RNA - ### Manual Remediation Required ###"
#			fi
#			MLOG "- $(date +%D-%H:%M:%S) - Completed - update the grub2 configuration"
			#UG2C=y
			FUGC
		fi
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure AppArmor is enabled in the bootloader configuration