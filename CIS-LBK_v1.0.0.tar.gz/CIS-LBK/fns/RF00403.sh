# Ensure audit logs are not automatically deleted
RF00403()
{
	SFN=/etc/audit/auditd.conf
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	APN=max_log_file_action
	APS=keep_logs
	[[ -n `egrep -i "^\s*$APN\s*\=\s*$APS\b.*$" $SFN` ]] && MLOG "- $(date +%D-%H:%M:%S) - $RNA already configured - Skipping" || FSACFP
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure audit logs are not automatically deleted