# Function to check and/or modify grub configuration
FCMGC()
{
	# RN={Recomendation Number}
	# RNA={Recomendation Name}
	# GCFL={Grub Configuration File Location} ### Set as a "global" variable in the benchmark script
	# GPN={Grub parameter name}
	# GPS={Grub parameter setting}
	# GPD={Grub Parameter Decesion} MUST be ADD for add or DEL for remove

	MLOG "- $(date +%D-%H:%M:%S) - Starting - Checking for $GPN=$GPS in Grub configuration"
	SFN=/etc/default/grub
	if [[ $GPD = ADD ]]
	then
		if [[ -z `cat $GCFL | grep "^\s*linux" | egrep -v "^\s*linux\s+.*\b$GPN=$GPS\b.*$"` ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - $GPN=$GPS is set in the current Grub config"
			MLOG "- $(date +%D-%H:%M:%S) - Checking if $GPN=$GPS is set in $SFN"
			if [[ -n $(egrep -i "^\s*GRUB_CMDLINE_LINUX=\".*\b$GPN=$GPS\b.*\".*$" $SFN) ]]
			then
				MLOG "- $(date +%D-%H:%M:%S) - $GPN=$GPS is set in $SFN - Skipping"
			else
				MLOG "- $(date +%D-%H:%M:%S) - Starting - Update $SFN with $GPN=$GPS"
				FFBK
				[[ -z `egrep -i "^\s*GRUB_CMDLINE_LINUX=\".*\".*$" $SFN` ]] && echo "GRUB_CMDLINE_LINUX=\"\"" >> $SFN
				[[ -n `egrep -i "^(\s*GRUB_CMDLINE_LINUX=\")(.*)($GPN=)(\S+\b)(.*\")(.*)$" $SFN` ]] && sed -ri "s/^(\s*GRUB_CMDLINE_LINUX=\")(.*)($GPN=)(\S+\b)(.*\")(.*)$/\1\3$GPS \2\5\6/" $SFN || sed -ri "s/^(\s*GRUB_CMDLINE_LINUX=\")(.*)(\")(.*)$/\1$GPN=$GPS \2\3\4/" $SFN
				[[ -n `egrep -i "^(\s*GRUB_CMDLINE_LINUX_DEFAULT=\")(.*)($GPN=\S+\b)(.*\")(.*)$" $SFN` ]] && sed -ri "s/^(\s*GRUB_CMDLINE_LINUX_DEFAULT=\")(.*)($GPN=\S+\b\s*)(.*\")(.*)$/\1\2\4\5/" $SFN
				[[ -n `egrep -i "^\s*GRUB_CMDLINE_LINUX=\".*\b$GPN=$GPS\b.*\".*$" $SFN` ]] && MLOG "- $(date +%D-%H:%M:%S) - Update $SFN with $GPN=$GPS - Successful" || WLOG "- $(date +%D-%H:%M:%S) - Update $SFN with $GPN=$GPS - Failed - ### Manual Remediation Required ###"
#				MLOG "- $(date +%D-%H:%M:%S) - Flagging to update grub at the end of the system Remediation"
				FUGC
#				UG2C=y
				MLOG "- $(date +%D-%H:%M:%S) - Completed - Update $SFN with $GPN=$GPS"
			fi
		else
			MLOG "- $(date +%D-%H:%M:%S) - $GPN=$GPS is not set in the current Grub config"
			MLOG "- $(date +%D-%H:%M:%S) - Checking if $GPN=$GPS is set in $SFN"
			if [[ -n $(egrep -i "^\s*GRUB_CMDLINE_LINUX=\".*\b$GPN=$GPS\b.*\".*$" $SFN) ]]
			then
#				MLOG "- $(date +%D-%H:%M:%S) - $GPN=$GPS is set in $SFN - Flagging to update grub at the end of the system Remediation"
				FUGC
#				UG2C=y		
			else
				MLOG "- $(date +%D-%H:%M:%S) - Starting - Update $SFN with $GPN=$GPS"
				FFBK
				[[ -z `egrep -i "^\s*GRUB_CMDLINE_LINUX=\".*\".*$" $SFN` ]] && echo "GRUB_CMDLINE_LINUX=\"\"" >> $SFN
				[[ -n `egrep -i "^(\s*GRUB_CMDLINE_LINUX=\")(.*)($GPN=)(\S+\b)(.*\")(.*)$" $SFN` ]] && sed -ri "s/^(\s*GRUB_CMDLINE_LINUX=\")(.*)($GPN=)(\S+\b)(.*\")(.*)$/\1\3$GPS \2\5/" $SFN || sed -ri "s/^(\s*GRUB_CMDLINE_LINUX=\")(.*)(\")(.*)$/\1$GPN=$GPS \2\3\4/" $SFN
				[[ -n `egrep -i "^(\s*GRUB_CMDLINE_LINUX_DEFAULT=\")(.*)($GPN=\S+\b)(.*\")(.*)$" $SFN` ]] && sed -ri "s/^(\s*GRUB_CMDLINE_LINUX_DEFAULT=\")(.*)($GPN=\S+\b)(.*\")(.*)$/\1\2\4\5/" $SFN
				[[ -n `egrep -i "^\s*GRUB_CMDLINE_LINUX=\".*\b$GPN=$GPS\b.*\".*$" $SFN` ]] && MLOG "- $(date +%D-%H:%M:%S) - Update $SFN with $GPN=$GPS - Successful" || WLOG "- $(date +%D-%H:%M:%S) - Update $SFN with $GPN=$GPS - Failed - ### Manual Remediation Required ###"
#				MLOG "- $(date +%D-%H:%M:%S) - Flagging to update grub at the end of the system Remediation"
				FUGC
#				UG2C=y
				MLOG "- $(date +%D-%H:%M:%S) - Completed - Update $SFN with $GPN=$GPS"
			fi
		fi	
	elif [[ $GPD = DEL ]]
	then
		if [[ -z `egrep -i "^\s*linux\s+.*\b$GPN=$GPS\b.*$"` ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - $GPN=$GPS is not set in the current Grub config"
			MLOG "- $(date +%D-%H:%M:%S) - Checking if $GPN=$GPS is set in $SFN"
			if [[ -z `egrep -i "^\s*GRUB_CMDLINE_LINUX(_DEFAULT=\"|=\").*\".*$" $SFN` ]]
			then
				MLOG "- $(date +%D-%H:%M:%S) - $GPN=$GPS is not set in $SFN - Skipping"
			else
				MLOG "- $(date +%D-%H:%M:%S) - Starting - Update $SFN to remove $GPN=$GPS"
				FFBK
				[[ -n `egrep -i "^(\s*GRUB_CMDLINE_LINUX=\")(.*)($GPN=$GPS\b)(.*\")(.*)$" $SFN` ]] && sed -ri "s/^(\s*GRUB_CMDLINE_LINUX=\")(.*)($GPN=$GPS\b\s*)(.*\")(.*)$/\1\2\4\5/" $SFN
				[[ -n `egrep -i "^(\s*GRUB_CMDLINE_LINUX_DEFAULT=\")(.*)($GPN=$GPS\b)(.*\")(.*)$" $SFN` ]] && sed -ri "s/^(\s*GRUB_CMDLINE_LINUX_DEFAULT=\")(.*)($GPN=$GPS\b\s*)(.*\")(.*)$/\1\2\4\5/" $SFN
				[[ -z `egrep -i "^(\s*GRUB_CMDLINE_LINUX=\")(.*)($GPN=$GPS\b)(.*\")(.*)$" $SFN` ]] && [[ -z `egrep -i "^(\s*GRUB_CMDLINE_LINUX_DEFAULT=\")(.*)($GPN=$GPS\b)(.*\")(.*)$" $SFN` ]] && MLOG "- $(date +%D-%H:%M:%S) - Update $SFN to remove $GPN=$GPS - Successful" || WLOG "- $(date +%D-%H:%M:%S) - Update $SFN to remove $GPN=$GPS - Failed - ### Manual Remediation Required ###"
#				MLOG "- $(date +%D-%H:%M:%S) - Flagging to update grub at the end of the system Remediation"
				FUGC
#				UG2C=y
				MLOG "- $(date +%D-%H:%M:%S) - Completed - Update $SFN to remove $GPN=$GPS"
			fi
		else
			MLOG "- $(date +%D-%H:%M:%S) - $GPN=$GPS is set in the current Grub config"
			MLOG "- $(date +%D-%H:%M:%S) - Checking if $GPN=$GPS is set in $SFN"
			if [[ -z `egrep -i "^\s*GRUB_CMDLINE_LINUX=\".*\b$GPN=$GPS\b.*\".*$"` ]] && [[ -z `egrep -i "^\s*GRUB_CMDLINE_LINUX_DEFAULT=\".*\b$GPN=$GPS\b.*\".*$"` ]]
			then
#				MLOG "- $(date +%D-%H:%M:%S) - $GPN=$GPS is not set in $SFN - Flagging to update grub at the end of the system Remediation"
				FUGC
#				UG2C=y
			else
				MLOG "- $(date +%D-%H:%M:%S) - Starting - Update $SFN to remove $GPN=$GPS"
				FFBK
				[[ -n `egrep -i "^(\s*GRUB_CMDLINE_LINUX=\")(.*)($GPN=$GPS\b)(.*\")(.*)$" $SFN` ]] && sed -ri "s/^(\s*GRUB_CMDLINE_LINUX=\")(.*)($GPN=$GPS\b\s*)(.*\")(.*)$/\1\2\4\5/" $SFN
				[[ -n `egrep -i "^(\s*GRUB_CMDLINE_LINUX_DEFAULT=\")(.*)($GPN=$GPS\b)(.*\")(.*)$" $SFN` ]] && sed -ri "s/^(\s*GRUB_CMDLINE_LINUX_DEFAULT=\")(.*)($GPN=$GPS\b\s*)(.*\")(.*)$/\1\2\4\5/" $SFN
				[[ -z `egrep -i "^(\s*GRUB_CMDLINE_LINUX=\")(.*)($GPN=$GPS\b)(.*\")(.*)$" $SFN` ]] && [[ -z `egrep -i "^(\s*GRUB_CMDLINE_LINUX_DEFAULT=\")(.*)($GPN=$GPS\b)(.*\")(.*)$" $SFN` ]] && MLOG "- $(date +%D-%H:%M:%S) - Update $SFN to remove $GPN=$GPS - Successful" || WLOG "- $(date +%D-%H:%M:%S) - Update $SFN to remove $GPN=$GPS - Failed - ### Manual Remediation Required ###"
#				MLOG "- $(date +%D-%H:%M:%S) - Flagging to update grub at the end of the system Remediation"
				FUGC
#				UG2C=y
				MLOG "- $(date +%D-%H:%M:%S) - Completed - Update $SFN to remove $GPN=$GPS"
			fi
		fi
	else
		WLOG "- $(date +%D-%H:%M:%S) - Variable GPD not set - $RN $RNA - ### Manual Remediation Required ###"
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - Checking for $GPN=$GPS in Grub configuration"
}
# End of Function to check and/or modify grub configuration