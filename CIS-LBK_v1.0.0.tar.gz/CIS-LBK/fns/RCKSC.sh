# Function to check and modify /etc/sysctl.conf and /etc/sysctl.d/*
RCKSC()
{
	# RN={Recomendation Number}
	# RNA={Recomendation Name}
	# OPN={Option Name (ex: fs.suid_dumpable)}
	# OPS={Option Setting (0|1|2|y|n)}

	MLOG "- $(date +%D-%H:%M:%S) - Starting - Checking /etc/sysctl.conf"
	if [[ -n `egrep "^\s*$OPN\s*\=\s*$OPS\s*$" /etc/sysctl.conf` ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - $RNA configured in /etc/sysctl.conf, skipping"
	else
		if [[ -n `egrep -r "^\s*$OPN\s*\=\s*$OPS\s*$" /etc/sysctl.d` ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - $RNA configured in a /etc/sysctl.d/* file, skipping"
		else
			[[ ! -s /etc/sysctl.conf.bk.cis ]] && MLOG "- $(date +%D-%H:%M:%S) - ### Creating backup ### of /etc/sysctl.conf as /etc/sysctl.conf.bk.cis" && cp /etc/sysctl.conf /etc/sysctl.conf.bk.cis || MLOG "- $(date +%D-%H:%M:%S) - Backup of /etc/sysctl.conf already exists as /etc/sysctl.conf.bk.cis, skipping creation of backup"
			egrep -q "^(\s*)$OPN\s*=\s*\S+(\s*#.*)?\s*$" /etc/sysctl.conf && sed -ri "s/^(\s*)$OPN\s*=\s*\S+(\s*#.*)?\s*$/\1$OPN = $OPS\2/" /etc/sysctl.conf || echo "$OPN = $OPS" >> /etc/sysctl.conf
			[[ -n `egrep "^\s*$OPN\s*\=\s*$OPS\s*$" /etc/sysctl.conf` ]] && MLOG "- $(date +%D-%H:%M:%S) - $RNA successfully configured in /etc/sysctl.conf" || WLOG "- $(date +%D-%H:%M:%S) - configuring $RNA in /etc/sysctl.conf failed ### Manual Remediation Required ### for $RN $RNA"
		fi
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - Checking /etc/sysctl.conf"
	# MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Function to check and modify /etc/sysctl.conf and /etc/sysctl.d/*