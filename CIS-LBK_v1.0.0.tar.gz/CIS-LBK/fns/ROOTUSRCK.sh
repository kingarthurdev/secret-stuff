# Root user check
ROOTUSRCK()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting user check"
	MLOG "- $(date +%D-%H:%M:%S) -  Verifying that this Remediation Kit is being run as the root user"
	MLOG "- $(date +%D-%H:%M:%S) -  ### Script will exit if it's not being run as root ###"
	[[ $(id -u) = 0 ]] && MLOG "- $(date +%D-%H:%M:%S) - User is root - continuing..." || exit 1
	MLOG "- $(date +%D-%H:%M:%S) - root user verification successful"
}
# End of Root user check