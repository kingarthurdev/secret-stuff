# Ensure permissions on /etc/gshadow are configured
RF00605()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	SFN=/etc/gshadow
	if [[ -n `stat $SFN | egrep -i "^\s*Access\:\s+\(0[0-6][04]0\/-[-r][-w]-[-r]-----\)\s+Uid\:\s+\(\s+0\/\s+root\)\s+Gid\:\s+\(\s+\S+\/\s+shadow\)\s*$"` ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - Owner, Group, and permissions set correctly on $SFN - Skipping"
	else
		MLOG "- $(date +%D-%H:%M:%S) - Owner, Group, and permissions not set correctly on $SFN - Remediating"
		FLOSP
		chmod o-rwx,g-wx $SFN
		chown root:shadow $SFN
		if [[ -n `stat $SFN | egrep -i "^\s*Access\:\s+\(0[0-6][04]0\/-[-r][-w]-[-r]-----\)\s+Uid\:\s+\(\s+0\/\s+root\)\s+Gid\:\s+\(\s+\S+\/\s+shadow\)\s*$"` ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - Successful - Setting Owner, Group, and permissions on $SFN"
		else
			WLOG "- $(date +%D-%H:%M:%S) - Failed - Setting Owner, Group, and permissions on $SFN - $RN $RNA - ### Maunal Remediation Required ###"
		fi
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure permissions on /etc/gshadow are configured