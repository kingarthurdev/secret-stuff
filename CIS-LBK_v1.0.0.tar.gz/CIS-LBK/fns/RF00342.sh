# Ensure SCTP is disabled
RF00342()
{
	FN=sctp
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	FMNL
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure SCTP is disabled