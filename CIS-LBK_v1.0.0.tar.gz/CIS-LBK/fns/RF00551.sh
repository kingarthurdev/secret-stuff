# Ensure default group for the root account is GID 0
RF00551()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	if [[ $(grep "^root:" /etc/passwd | cut -f4 -d:) = 0 ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - default group for the root account is GID $(grep "^root:" /etc/passwd | cut -f4 -d:) - Skipping"
	else
		MLOG "- $(date +%D-%H:%M:%S) - default group for the root account is GID $(grep "^root:" /etc/passwd | cut -f4 -d:) - Remediating"
		usermod -g 0 root
		[[ $(grep "^root:" /etc/passwd | cut -f4 -d:) = 0 ]] && MLOG "- $(date +%D-%H:%M:%S) - Successful - default group for the root account is GID $(grep "^root:" /etc/passwd | cut -f4 -d:)" || WLOG "- $(date +%D-%H:%M:%S) - Failed - default group for the root account is GID $(grep "^root:" /etc/passwd | cut -f4 -d:) - $RN $RNA - ### Manual Remediation Required ###"
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure default group for the root account is GID 0