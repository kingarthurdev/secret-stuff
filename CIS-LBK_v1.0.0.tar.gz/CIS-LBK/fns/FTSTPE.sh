# Function to determine which time synchronization package is being used
FTSTPE()
{	
	# Sub Function to determine time synchronization package
	FTADEC()
	{
		# Sub function to determine which Time synchronization package to install
		FTSPCH()
		{
			/usr/bin/clear
			echo "  Neither ntp or chrony is installed on this system"
			echo "  Please select which time synchronization package you would like installed"
			echo ""
			echo "  Please enter 1 for ntp"
			echo "  Please enter 2 for chrony"
			echo "  Please enter 0 if you don't want either time synchronization package Installed"
			#echo "  : "
			#read ANSR
			read -p ": " -r
			#$REPLY
			#case $ANSR in
			case $REPLY in
				1 ) 
					/usr/bin/clear
					MLOG "- $(date +%D-%H:%M:%S) - you responded with $REPLY - ntp will be installed"
					TSPCH=NTPP
					sleep 2
					;;
				2 )
					/usr/bin/clear
					MLOG "- $(date +%D-%H:%M:%S) - you responded with $REPLY - chrony will be installed"
					TSPCH=CRYP
					sleep 2
					;;
				0 )
					/usr/bin/clear
					WLOG "- $(date +%D-%H:%M:%S) - you responded with $REPLY - No time synchronization package will be installed - $RN $RNA - ### Manual Remediation Required ### "
					TSPCH=NONE
					sleep 2
					;;
				* )
					/usr/bin/clear
					WLOG "- $(date +%D-%H:%M:%S) - you responded with $REPLY - Please Respond with 1, 2, or 0 "
					sleep 2
					;;
			esac
		}
		# End of Sub function to determine which Time synchronization package to install

		if [[ `dpkg -s ntp | grep Status` = "Status: install ok installed" ]]
		then
			TSPDEC=NTPP
		else
			if [[ `dpkg -s chrony | grep Status` = "Status: install ok installed" ]]
			then
				TSPDEC=CRYP 
			else
				MLOG "- $(date +%D-%H:%M:%S) - Neither ntp or chrony is installed - Choice of which one to install required"
				FTSPCH
				case $TSPCH in
					NTPP )
						MLOG "- $(date +%D-%H:%M:%S) - User selected to install ntp - Installing ntp"
						PNA=ntp
						# PNA2={Second Package Name}
						# PNA3={Third Package Name}
						# PNA4={Fourth Package Name}
						FIPKG
						if [[ `dpkg -s ntp | grep Status` = "Status: install ok installed" ]]
						then
							MLOG "- $(date +%D-%H:%M:%S) - ntp install successful"
							TSPDEC=NTPP
						else
							WLOG "- $(date +%D-%H:%M:%S) - ntp install Not Successful - ### Manual Remediation Required ###" 
							TSPDEC=NONE
						fi
						;;
					CRYP )
						MLOG "- $(date +%D-%H:%M:%S) - User selected to install crony - Installing crony"
						PNA=chrony
						# PNA2={Second Parkage Name}
						# PNA3={Third Package Name}
						# PNA4={Fourth Package Name}
						FIPKG
						if [[ `dpkg -s crony | grep Status` = "Status: install ok installed" ]]
						then
							MLOG "- $(date +%D-%H:%M:%S) - chrony install successful"
							TSPDEC=CRYP
						else
							WLOG "- $(date +%D-%H:%M:%S) - chrony install Not Successful - ### Manual Remediation Required ###"
							TSPDEC=NONE
						fi
						;;
					NONE )
						# Manual Remediation Required for Manditory Access Control Recomendations
						WLOG "- $(date +%D-%H:%M:%S) - User selected to not install ntp or chrony - ### Manual Remediation Required ###"
						TSPDEC=NONE
						;;
					* )
						FTSPCH
						;;
				esac
			fi
		fi
	}
	# End of Sub Function to determine time synchronization package
	while [[ $TSPDEC = "" ]]
	do
		MLOG "- $(date +%D-%H:%M:%S) - Need to determin if ntp, chrony, or a different methiod is being used for time synchronization"
		FTADEC
	done
}
# End of Function to determine which time synchronization package is being used