# Ensure permissions on /etc/motd are configured
RF00174()
{
	SFN=/etc/motd
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	FBFP
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
#End of Ensure permissions on /etc/motd are configured