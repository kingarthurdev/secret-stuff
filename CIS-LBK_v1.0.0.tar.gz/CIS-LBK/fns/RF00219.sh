# Ensure mail transfer agent is configured for local-only mode
# !!! This check is NOT using the deprecated netstat - check for usability on non-Debian systems!!!
RF00219()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	if [[ -z `ss -a4n | grep :25 | awk '{print $5}' | cut -d: -f1-4` ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - System is not listening on port 25 - skipping"
	elif [[ `ss -a4n | grep :25 | awk '{print $5}' | cut -d: -f1-4` = 127.0.0.1:25 ]] || [[ `ss -a4n | grep :25 | awk '{print $5}' | cut -d: -f1-4` = ::1:25 ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - System is configured for local-only mode - skipping"
	else
		MLOG "- $(date +%D-%H:%M:%S) - System is not configured for local-only mode - Remediating"
		SFN=/etc/postfix/main.cf
		FFBK
		[[ -n `egrep -i "^\s*inet_interfaces\s*=\s*\S+.*$" $SFN` ]] && sed -ri "s/^(\s*)(inet_interfaces\s*)(=\s*)\S+.*$/\1\2\3localhost/" $SFN || echo "inet_interfaces = localhost" >> $SFN
		service postfix restart
		if [[ -z `ss -a4n | grep :25 | awk '{print $5}' | cut -d: -f1-4` ]] || [[ `ss -a4n | grep :25 | awk '{print $5}' | cut -d: -f1-4` = 127.0.0.1:25 ]] || [[ `ss -a4n | grep :25 | awk '{print $5}' | cut -d: -f1-4` = ::1:25 ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - $RNA - remediation successful"
		else
			WLOG "- $(date +%D-%H:%M:%S) - $RNA - remediation failed - ### Manual Remediation Required ###"
		fi
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure mail transfer agent is configured for local-only mode