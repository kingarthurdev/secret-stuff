# Ensure inactive password lock is 30 days or less
RF00548()
{
	#SFN=/etc/login.defs
	PON="inactive password lock days"
	PORX="^\s*Password\s+inactive\s+\:\s*\S+\s*$"
	SFN=/etc/shadow
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	MLOG "- $(date +%D-%H:%M:%S) -- Starting - check default $PON"
	if [[ -n $(useradd -D | egrep -i "^\s*INACTIVE\s*=\s*(30|[1-2][0-9]|[0-9])\s*(\s+#.*)?$") ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) -- default $PON is \"$(useradd -D | grep INACTIVE | cut -d= -f2)\" - Skipping"
	else
		MLOG "- $(date +%D-%H:%M:%S) -- default $PON is \"$(useradd -D | grep INACTIVE | cut -d= -f2)\" - Remediating"
		useradd -D -f 30
		if [[ -n $(useradd -D | egrep -i "^\s*INACTIVE\s*=\s*(30|[1-2][0-9]|[0-9])\s*(\s+#.*)?$") ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) -- Successful - default $PON updated to \"$(useradd -D | grep INACTIVE | cut -d= -f2)\""
		else
			WLOG "- $(date +%D-%H:%M:%S) -- Failed - default $PON currently \"$(useradd -D | grep INACTIVE | cut -d= -f2)\" - $RN $RNA - ### Manual Remediation Required ###"
		fi
	fi
	MLOG "- $(date +%D-%H:%M:%S) -- Completed - check default $PON"
	MLOG "- $(date +%D-%H:%M:%S) -- Starting - check users $PON"
	for MPD in $(egrep ^[^:]+:[^\!*] $SFN | cut -d: -f1)
	do
		if [[ -n $(egrep -i "^\s*$MPD\:\S*\:\S*\:\S*\:\S*\:\S*\:(30|[1-2][0-9]|[0-9])\:\s*\:(\S*|\s*)$" $SFN) ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) -- $PON for $MPD is \"$(grep -i ^$MPD: $SFN | cut -d: -f7)\" days - skipping"
		elif [[ $MPD = "root" ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) -- $PON for $MPD is \"$(grep -i ^$MPD: $SFN | cut -d: -f7)\" days - user is root - skipping"
		else
			MLOG "- $(date +%D-%H:%M:%S) -- $PON for $MPD is \"$(grep -i ^$MPD: $SFN | cut -d: -f7)\" days - Remediating"
			chage --inactive 30 $MPD
			if [[ -n $(egrep -i "^\s*$MPD\:\S*\:\S*\:\S*\:\S*\:\S*\:(30|[1-2][0-9]|[0-9])\:\s*\:(\S*|\s*)$" $SFN) ]]
			then
				MLOG "- $(date +%D-%H:%M:%S) -- Successful - user $MPD $PON is now \"$(grep -i ^$MPD: $SFN | cut -d: -f7)\" days"
			else
			WLOG "- $(date +%D-%H:%M:%S) -- Failed - user $MPD $PON is \"$(grep -i ^$MPD: $SFN | cut -d: -f7)\" days - $RN $RNA - ### Manual Remediation Required ###"
			fi
		fi
	done
	MLOG "- $(date +%D-%H:%M:%S) -- Completed - check users $PON"
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure inactive password lock is 30 days or less