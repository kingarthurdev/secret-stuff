# Ensure prelink is disabled
RF00154()
{
	PNA=prelink
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	RPKGE
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure prelink is disabled