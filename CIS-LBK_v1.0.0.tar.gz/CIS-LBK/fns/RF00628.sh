# Ensure users' home directories permissions are 750 or more restrictive
RF00628()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	cat /etc/passwd | egrep -v '^(root|halt|sync|shutdown)' | awk -F: '($7 != "/usr/sbin/nologin" && $7 != "/bin/false") { print $1 " " $6 }' | while read USR UDIR
	do
		if [ ! -d "$UDIR" ]
		then
			WLOG "- $(date +%D-%H:%M:%S) - The home directory ($UDIR) of user $USR does not exist - $RN $RNA - ### Manual Remediation Required ###"
		else
			MLOG "- $(date +%D-%H:%M:%S) - Starting - Checking ownershp on user $USR home directory \"$UDIR\""
			if [[ $(ls -ld $UDIR | cut -d' ' -f3) = $USR ]]
			then
				MLOG "- $(date +%D-%H:%M:%S) - User $USR ownes their home directory \"$UDIR\" - Skipping"
			else
				MLOG "- $(date +%D-%H:%M:%S) - User $(ls -ld $UDIR | cut -d' ' -f3) owns $USR home directory \"$UDIR\" - Remediating"
				SFN=$UDIR
				FLOSP
				chown $USR $UDIR
				[[ $(ls -ld $UDIR | cut -d' ' -f3) = $USR ]] && MLOG "- $(date +%D-%H:%M:%S) - Successful - User $USR owns their home directory \"$UDIR\"" || WLOG "- $(date +%D-%H:%M:%S) - Failed - User $USR doesn't own their home directory \"$UDIR\" - $RN $RNA - ### Manual Remediation Required ###"
			fi
			MLOG "- $(date +%D-%H:%M:%S) - Completed - Checking ownershp on user $USR home directory \"$UDIR\""
			MLOG "- $(date +%D-%H:%M:%S) - Starting - Checking Permissions on user's home directory \"$UDIR\""
			if [[ -n $(stat $UDIR | egrep -i "^\s*Access\:\s+\(0[750][50]0\/d[-r][-w][-x][-r]-[-x]---\)\s+Uid\:\s+\(\s+\S+\/\s+$USR\)\s+Gid\:\s+\(\s+\S+\/\s+\S+\)\s*$") ]]
			then
				MLOG "- $(date +%D-%H:%M:%S) - Permissions on user $USR home directory \"$UDIR\" set correctly - Skipping"
			else
				MLOG "- $(date +%D-%H:%M:%S) - Permissions on user $USR home directory \"$UDIR\" are \"$(ls -ld $UDIR | cut -d' ' -f1)\" - Remediating"
				SFN=$UDIR
				FLOSP
				chmod g-w $UDIR
				chmod o-wrx $UDIR
				if [[ -n $(stat $UDIR | egrep -i "^\s*Access\:\s+\(0[750][50]0\/d[-r][-w][-x][-r]-[-x]---\)\s+Uid\:\s+\(\s+\S+\/\s+$USR\)\s+Gid\:\s+\(\s+\S+\/\s+\S+\)\s*$") ]]
				then
					MLOG "- $(date +%D-%H:%M:%S) - Successful - Permissions on user $USR home directory \"$UDIR\" are \"$(ls -ld $UDIR | cut -d' ' -f1)\""
				else
					WLOG "- $(date +%D-%H:%M:%S) - Failed - Permissions on user $USR home directory \"$UDIR\" are \"$(ls -ld $UDIR | cut -d' ' -f1)\" - $RN $RNA - ### Manual Remediation Required ###"
				fi
			fi
			MLOG "- $(date +%D-%H:%M:%S) - Completed - Checking Permissions on user's home directory \"$UDIR\""
		fi	
	done
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure users' home directories permissions are 750 or more restrictive