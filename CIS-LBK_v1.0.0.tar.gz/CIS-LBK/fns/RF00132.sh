# Ensure filesystem integrity is regularly checked
RF00132()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	if [[ -n $(crontab -u root -l | egrep aide) ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - Filesystem integrity is regularly checked - skipping"
	else
		MLOG "- $(date +%D-%H:%M:%S) - Filesystem integrity is not regularly checked - Remediating"
		MLOG "- $(date +%D-%H:%M:%S) - Creating a backup of root's crontab as \"$BKDIR/root_cron$BFE_$RN\""
		crontab -l -u root >> $BKDIR/root_cron$BFE_$RN
		echo "0 5 * * * /usr/bin/aide.wrapper --config /etc/aide/aide.conf --check" | crontab -u root -
		if [[ -n $(crontab -u root -l | egrep aide) ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - Successful - Filesystem integrity is regularly checked"
		else
			WLOG "- $(date +%D-%H:%M:%S) - Failed - Filesystem integrity is not regularly checked - $RN $RNA - ### Manual Remediation Required ###"
		fi
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure filesystem integrity is regularly checked