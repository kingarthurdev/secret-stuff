# Ensure default user umask is 027 or more restrictive
RF00552()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	# Sub funftion to check umask in a file
	SFCUM()
	{
		# SFN={Source file name} 
		MLOG "- $(date +%D-%H:%M:%S) - Starting - Checking umask in $SFN"
#		if [[ $(egrep -i "^\s*umask\s+\S+\s*(\s+#.*)?$" $SFN) =~ "^\s*umask\s+[0-7][2-7]7\s*(\s+#.*)?$" ]]
		if [[ -n $(egrep -i "^\s*umask\s+[0-7][2-7]7\s*(\s+#.*)?$" $SFN) ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - umask in $SFN is $(egrep -i "^\s*umask\s+\S+\s*(\s+#.*)?$" $SFN) - Skipping"
		else
			MLOG "- $(date +%D-%H:%M:%S) - umask in $SFN is $(egrep -i "^\s*umask\s+\S+\s*(\s+#.*)?$" $SFN) - Remediating"
			FFBK
			[[ -n $(egrep -i "^\s*umask\s+\S+\s*(\s+#.*)?$" $SFN) ]] && sed -ri "s/^(\s*umask)(\s+\S+\s*)(\s+#.*)?$/\1 027\3/" $SFN || echo "umask 027" >> $SFN
#			if [[ $(egrep -i "^\s*umask\s+\S+\s*(\s+#.*)?$" $SFN) =~ "^\s*umask\s+[0-7][2-7]7\s*(\s+#.*)?$" ]]
			if [[ -n $(egrep -i "^\s*umask\s+[0-7][2-7]7\s*(\s+#.*)?$" $SFN) ]]
			then
				MLOG "- $(date +%D-%H:%M:%S) - Successful - umask in $SFN is $(egrep -i "^\s*umask\s+\S+\s*(\s+#.*)?$" $SFN)"
			else
				MLOG "- $(date +%D-%H:%M:%S) - Failed - umask in $SFN is $(egrep -i "^\s*umask\s+\S+\s*(\s+#.*)?$" $SFN) - $RN $RNA - ### Manual Remediation Required"
			fi
		fi
		MLOG "- $(date +%D-%H:%M:%S) - Completed - Checking umask in $SFN"
	}
	# End of Sub funftion to check umask in a file

	SFN=/etc/bash.bashrc
	SFCUM
	SFN=/etc/profile
	SFCUM
	for SFN in $(ls /etc/profile.d/*.sh)
	do
		SFCUM
	done
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure default user umask is 027 or more restrictive