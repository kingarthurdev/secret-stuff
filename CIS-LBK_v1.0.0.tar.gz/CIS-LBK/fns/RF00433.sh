# Ensure rsyslog or syslog-ng is installed
RF00433()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	FDLP # Determins which logging package is being used
	case $LCPH in
		RSL )
			MLOG "- $(date +%D-%H:%M:%S) - rsyslog package is installed"
			;;
		SLN )
			MLOG "- $(date +%D-%H:%M:%S) - syslog-ng package is installed"
			;;
		NONE )
			WLOG "- $(date +%D-%H:%M:%S) - Neither the rsyslog or syslog-ng package are installed - user selected - $RN $RNA - ### Manual Remediation Required ###"
			;;
		* )
			WLOG "- $(date +%D-%H:%M:%S) - error occured - $RN $RNA - ### Manual Remediation Required ###"
			;;
	esac
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure rsyslog or syslog-ng is installed