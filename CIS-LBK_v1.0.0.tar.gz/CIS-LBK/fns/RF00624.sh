# Ensure no legacy "+" entries exist in /etc/group
RF00624()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	SFN=/etc/group
	if [[ -z $(grep '^\+:' $SFN) ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - no legacy \"+\" entries exist in $SFN - Skipping"
	else
		WLOG "- $(date +%D-%H:%M:%S) - legacy \"+\" entries exist in $SFN - $RN $RNA - ### Manual Remediation Required ###"
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure no legacy "+" entries exist in /etc/group