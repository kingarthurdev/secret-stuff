# Ensure nodev option set on /var/tmp partition
RF00108()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	SMPN=var/tmp
	OPN=nodev
	POCK
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure nodev option set on /var/tmp partition