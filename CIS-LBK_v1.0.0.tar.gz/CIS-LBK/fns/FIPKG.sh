# Function to install a package or packages
FIPKG()
{
	# PNA={Package Name}
	# PNA2={Second Package Name}
	# PNA3={Thisd Package Name}
	# PNA4={Fourth Package Name}

	MLOG "- $(date +%D-%H:%M:%S) - Starting - Install Package(s) $PNA $PNA2 $PNA3 $PNA4"
	if [[ `dpkg -s $PNA | grep Status` = "Status: install ok installed" ]]
	then 
		MLOG "- $(date +%D-%H:%M:%S) - $PNA is installed - no installation required, skipping"
	else
		MLOG "- $(date +%D-%H:%M:%S) - $PNA is not installed - installing $PNA $PNA2 $PNA3 $PNA4"
		apt-get -y install $PNA $PNA2 $PNA3 $PNA4
		if [[ `dpkg -s $PNA | grep Status` = "Status: install ok installed" ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - Successfully installed $PNA $PNA2 $PNA3 $PNA4"
		else
			WLOG "- $(date +%D-%H:%M:%S) - Failed to install $PNA $PNA2 $PNA3 $PNA4 - $RN $RNA - ### Manual Remediation Required ###"
		fi
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Compledted Install Package(s) $PNA $PNA2 $PNA3 $PNA4"
	PNA2=""
	PNA3=""
	PNA4=""
}
# End of Function to install a package or packages