# Ensure sticky bit is set on all world-writable directories
RF00121()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	if [[ -z $(df --local -P | awk {'if (NR!=1) print $6'} | xargs -I '{}' find '{}' -xdev -type d \( -perm -0002 -a ! -perm -1000 \) 2>/dev/null) ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - sticky bit is set on all world-writable directories - no remediation required, skipping"
	else
		MLOG "- $(date +%D-%H:%M:%S) - sticky bit not set on all world-writable directories - starting remediation"
		df --local -P | awk {'if (NR!=1) print $6'} | xargs -I '{}' find '{}' -xdev -type d -perm -0002 2>/dev/null | xargs chmod a+t
		if [[ -z $(df --local -P | awk {'if (NR!=1) print $6'} | xargs -I '{}' find '{}' -xdev -type d \( -perm -0002 -a ! -perm -1000 \) 2>/dev/null) ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - Successful - setting stickybit on all world-writable directories"
		else
			WLOG "- $(date +%D-%H:%M:%S) - Failed - $RN $RNA - ### Manual Remediation Required ###"
		fi
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure sticky bit is set on all world-writable directories