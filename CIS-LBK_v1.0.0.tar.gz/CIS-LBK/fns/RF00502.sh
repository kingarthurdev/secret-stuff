# Ensure permissions on /etc/crontab are configured
RF00502()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	SFN=/etc/crontab
	if [[ -n `stat $SFN | egrep -i "^\s*Access\:\s+\(0[642]00\/-[-r][-w]-------\)\s+Uid\:\s+\(\s+0\/\s+root\)\s+Gid\:\s+\(\s+0\/\s+root\)\s*$"` ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - Owner, Group, and permissions set correctly on $SFN - Skipping"
	else
		MLOG "- $(date +%D-%H:%M:%S) - Owner, Group, and permissions not set correctly on $SFN - Remediating"
		chown root:root $SFN
		chmod og-rwx $SFN
		if [[ -n `stat $SFN | egrep -i "^\s*Access\:\s+\(0[642]00\/-[-r][-w]-------\)\s+Uid\:\s+\(\s+0\/\s+root\)\s+Gid\:\s+\(\s+0\/\s+root\)\s*$"` ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - Successful - Setting Owner, Group, and permissions on $SFN"
		else
			WLOG "- $(date +%D-%H:%M:%S) - Failed - Setting Owner, Group, and permissions on $SFN - $RN $RNA - ### Maunal Remediation Required ###"
		fi
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure permissions on /etc/crontab are configured