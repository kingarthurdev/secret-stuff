# Ensure rsh client is not installed
RF00232()
{
	PNA=rsh-client
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	RPKGE
	PNA=rsh-redone-client
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure rsh client is not installed