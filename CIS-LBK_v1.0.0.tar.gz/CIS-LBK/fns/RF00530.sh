# Ensure SSH root login is disabled
RF00530()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	SPN=PermitRootLogin
	SPS=no
	FSSHS
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure SSH root login is disabled