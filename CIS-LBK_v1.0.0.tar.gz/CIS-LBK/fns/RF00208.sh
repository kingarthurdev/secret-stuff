# Ensure CUPS is not enabled
RF00208()
{
	DAEN=cups
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	FTDSD
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure CUPS is not enabled