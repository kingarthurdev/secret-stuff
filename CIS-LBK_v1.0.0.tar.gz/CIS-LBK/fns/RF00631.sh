# Ensure no users have .forward files
RF00631()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	UHFN=".forward"
	cat /etc/passwd | egrep -v '^(root|halt|sync|shutdown)' | awk -F: '($7 != "/usr/sbin/nologin" && $7 != "/bin/false") { print $1 " " $6 }' | while read USR UDIR
	do
		if [ ! -d "$UDIR" ]
		then
			WLOG "- $(date +%D-%H:%M:%S) - The home directory ($UDIR) of user $USR does not exist - $RN $RNA - ### Manual Remediation Required ###"
		else
			if [ ! -h "$UDIR/$UHFN" -a -f "$UDIR/$UHFN" ]
			then
				MLOG "- $(date +%D-%H:%M:%S) - user $USR has a $UHFN file \"$UDIR/$UHFN\" - Remediating"
				SFN=$UDIR/$UHFN
				FFBK
				rm $UDIR/$UHFN
				[ ! -h "$UDIR/$UHFN" -a -f "$UDIR/$UHFN" ] && MLOG "- $(date +%D-%H:%M:%S) - Successful - $UHFN file $SFN has been removed" || WLOG "- $(date +%D-%H:%M:%S) - Successful - user $USR has $UHFN file $SFN - $RN $RNA - ### Manual Remediation Required ###"
				SFN=""
			fi
		fi
	done
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure no users have .forward files