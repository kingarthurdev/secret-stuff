# Ensure permissions on all logfiles are configured
RF00434()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	for SFN in `find /var/log -type f`
	do
		if [[ -n `stat $SFN | egrep -i "^\s*Access\:\s+\(0[6420][420]0\/-[-r][-w]-[-r]-----\)\s+Uid\:\s+\(\s+\S+\/\s+\S+\)\s+\S+\:\s+\(\s+\S+\/\s+\S+\)\s*$"` ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - Permissions correct on - $SFN"
		else
			MLOG "- $(date +%D-%H:%M:%S) - Permissions on - $SFN - are - `stat $SFN | egrep -i "^\s*Access\:\s+\([0-7]{4}\/[-rwx]{10}\)\s+Uid\:\s+\(\s+\S+\/\s+\S+\)\s+\S+\:\s+\(\s+\S+\/\s+\S+\)\s*$"` - Remediating $SFN"
			chmod o-rwx $SFN
			chmod g-wx $SFN
			if [[ -n `stat $SFN | egrep -i "^\s*Access\:\s+\(0[6420][420]0\/-[-r][-w]-[-r]-----\)\s+Uid\:\s+\(\s+\S+\/\s+\S+\)\s+\S+\:\s+\(\s+\S+\/\s+\S+\)\s*$"` ]]
			then
				MLOG "- $(date +%D-%H:%M:%S) - Sucessfully modified Permissions on - $SFN"
			else
				WLOG "- $(date +%D-%H:%M:%S) - Failed to modify Permissions on - $SFN - $RN $RNA - ### Manual Remediation Required ###"
			fi
		fi
	done
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure permissions on all logfiles are configured