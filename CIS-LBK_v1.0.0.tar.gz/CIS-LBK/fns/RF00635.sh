# Ensure all groups in /etc/passwd exist in /etc/group
RF00635()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	cat /etc/passwd | awk -F: '{print $1 " " $4}' | while read USR GNB
	do
		for VAR in $GNB
		do
			grep -q -P "^.*?:[^:]*:$VAR:" /etc/group
			if [ $? -ne 0 ]
			then
				WLOG "- $(date +%D-%H:%M:%S) - Group \"$GNB\" for user $USR is refferenced in /etc/passwd but not in /etc/group - $RN $RNA - ### Manual Remediation Required ###"
			else
				MLOG "- $(date +%D-%H:%M:%S) - Group \"$GNB\" for user $USR is refferenced in /etc/group - Skipping"
			fi
		done
	done
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure all groups in /etc/passwd exist in /etc/group