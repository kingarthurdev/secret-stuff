# Ensure mounting of freevxfs filesystems is disabled
RF00097()
{
	# RN=1.1.1.1
	FN=freevxfs
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	FSCK
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure mounting of freevxfs filesystems is disabled