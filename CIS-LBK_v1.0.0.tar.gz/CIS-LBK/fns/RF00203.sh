# Ensure time synchronization is in use
RF00203()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	FTSTPE
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure time synchronization is in use