# Ensure message of the day is configured properly
RF00171()
{
	SFN=/etc/motd
	BNA="message of the day"
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	FWBU
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure message of the day is configured properly