# Function to determine if IPv6 is disabled status
FIPV6S()
{
	while [[ ! $V6S =~ (enabled|disabled) ]]
	do
		MLOG "- $(date +%D-%H:%M:%S) - Need to determin if IPv6 should be disabled"
		sleep 1
		FIPV6D
	done
}
# End of Function to determine if IPv6 is disabled status