# Ensure no users have .rhosts files
RF00634()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	UHFN=".rhosts"
	cat /etc/passwd | egrep -v '^(root|halt|sync|shutdown)' | awk -F: '($7 != "/usr/sbin/nologin" && $7 != "/bin/false") { print $1 " " $6 }' | while read USR UDIR
	do
		if [ ! -d "$UDIR" ]
		then
			WLOG "- $(date +%D-%H:%M:%S) - The home directory ($UDIR) of user $USR does not exist - $RN $RNA - ### Manual Remediation Required ###"
		else
			for SFN in $UDIR/$UHFN
			do
				if [ ! -h "$UDIR/$UHFN" -a -f "$UDIR/$UHFN" ]
				then
					MLOG "- $(date +%D-%H:%M:%S) - user $USR has a $UHFN file \"$SFN\" - Remediating"
					FFBK
					rm $SFN
					[ -h "$UDIR/$UHFN" -a -f "$UDIR/$UHFN" ] && MLOG "- $(date +%D-%H:%M:%S) - Successful - $UHFN file $SFN has been removed" || WLOG "- $(date +%D-%H:%M:%S) - Failed - user $USR has $UHFN file $SFN - $RN $RNA - ### Manual Remediation Required ###"
				else
					MLOG "- $(date +%D-%H:%M:%S) - user $USR doesn't have a $UHFN file \"$SFN\""
				fi
			done
		fi
	done
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure no users have .rhosts files