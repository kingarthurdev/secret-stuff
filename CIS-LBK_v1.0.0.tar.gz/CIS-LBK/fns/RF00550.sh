# Ensure system accounts are non-login
RF00550()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	MLOG "- $(date +%D-%H:%M:%S) - Starting - Check if system accuonts have non-login shell"
	if [[ -z $(egrep -v "^\+" /etc/passwd | awk -F: '($1!="root" && $1!="sync" && $1!="shutdown" && $1!="halt" && $3<1000 && $7!="/usr/sbin/nologin" && $7!="/bin/false") {print}') ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - all system accuonts have non-login shell - Skipping"
	else
		for SAN in $(egrep -v "^\+" /etc/passwd | awk -F: '($1!="root" && $1!="sync" && $1!="shutdown" && $1!="halt" && $3<1000 && $7!="/usr/sbin/nologin" && $7!="/bin/false") {print $1}')
		do
			MLOG "- $(date +%D-%H:%M:%S) - $(grep ^$SAN /etc/passwd | awk -F: '{print "user " $1 " login shell is " $7}') - Remediating"
			usermod -s /usr/sbin/nologin $SAN
			[[ $(grep ^$SAN /etc/passwd | awk -F: '{print $7}') = /usr/sbin/nologin ]]  && MLOG "- $(date +%D-%H:%M:%S) - Successful - $(grep ^$SAN /etc/passwd | awk -F: '{print "user " $1 " login shell is " $7}')" || WLOG "- $(date +%D-%H:%M:%S) - Failed - $(grep ^$SAN /etc/passwd | awk -F: '{print "user " $1 " login shell is " $7}') - $RN $RNA - ### Manual Remediation Required ###"
		done
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - Check if system accuonts have non-login shell"
	MLOG "- $(date +%D-%H:%M:%S) - Starting - Check if system accuonts are locked"
	for SAN in $(awk -F: '($1!="root" && $3 < 1000) {print $1 }' /etc/passwd)
	do
		if [[ ! $SAN = "root" && ! $SAN = "sync" && ! $SAN = "shutdown" && ! $SAN = "halt" && ! $(passwd -S $SAN | awk -F ' ' '{print $2}') = "L" ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - user $SAN status is $(passwd -S $SAN | awk -F ' ' '{print $2}') - Remediating"
			usermod -L $SAN
			if [[ ! $SAN = "root" && ! $SAN = "sync" && ! $SAN = "shutdown" && ! $SAN = "halt" && ! $(passwd -S $SAN | awk -F ' ' '{print $2}') = "L" ]]
			then
				MLOG "- $(date +%D-%H:%M:%S) - Successful - user $SAN status is $(passwd -S $SAN | awk -F ' ' '{print $2}')"
			else
				WLOG "- $(date +%D-%H:%M:%S) - Successful - user $SAN status is $(passwd -S $SAN | awk -F ' ' '{print $2}') - $RN $RNA - ### Manual Remediation Required"
			fi
		else
			MLOG "- $(date +%D-%H:%M:%S) - user $SAN status is $(passwd -S $SAN | awk -F ' ' '{print $2}') - Skipping"
		fi
	done
	MLOG "- $(date +%D-%H:%M:%S) - Completed - Check if system accuonts are locked"
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure system accounts are non-login