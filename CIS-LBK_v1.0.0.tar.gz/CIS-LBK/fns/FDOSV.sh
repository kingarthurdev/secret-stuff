# Function to determine openSSH version
FDOSV()
{
	# Fedora Family Methiod
	# OSSHV=$(rpm -q openssh-server | cut -d- -f3 | cut -dp -f1)
	# !!! Fedora check needs to be tested !!!
	[[ `egrep "^\s*ID=\S+$" /etc/os-release` =~ ^\s*ID=(\"centos\"|\"rhel\"|\"al2\")\s*$ ]] && OSSHV=$(rpm -q openssh-server | cut -d- -f3 | cut -dp -f1)
	#Debian Family method
	[[ `egrep "^\s*ID=\S+$" /etc/os-release` =~ ^\s*ID=(debian|ubuntu)\s*$ ]] && OSSHV=$(dpkg -s openssh-server | grep ^Version: | cut -d: -f3 | cut -d- -f1 | cut -dp -f1)
}
# End of Function to determine openSSH version