# Ensure all users' home directories exist
RF00627()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	MLOG "- $(date +%D-%H:%M:%S) - Starting - Checking for user home directories"
	cat /etc/passwd | egrep -v '^(root|halt|sync|shutdown)' | awk -F: '($7 != "/usr/sbin/nologin" && $7 != "/bin/false") { print $1 " " $6 }' | while read USR UDIR
	do
		if [ ! -d "$UDIR" ]
		then
			MLOG "- $(date +%D-%H:%M:%S) - The home directory ($UDIR) of user $USR does not exist - Remediating"
			if [[ $(echo $UDIR | cut -d/ -f2) = home ]]
			then
				mkdir $UDIR
				chown $USR $UDIR
				[[ -d $UDIR ]] && MLOG "- $(date +%D-%H:%M:%S) - Successful - created home directory \"$UDIR\" for user \"$DSR\"" || WLOG "- $(date +%D-%H:%M:%S) - Failed - home directory for user \"$USR\" not created - $RN $RNA - ### Manual Remediation Required ###"
			else
				WLOG "- $(date +%D-%H:%M:%S) - The home directory ($UDIR) of user $USR does not exist and is not in the \"/home\" directory - $RN $RNA - ### Manual Remediation Required ###"
			fi
		else
			MLOG "- $(date +%D-%H:%M:%S) - The home directory for user $USR is \"$UDIR\" - Skipping"
		fi
	done
	MLOG "- $(date +%D-%H:%M:%S) - Completed - Checking for user home directories"
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure all users' home directories exist