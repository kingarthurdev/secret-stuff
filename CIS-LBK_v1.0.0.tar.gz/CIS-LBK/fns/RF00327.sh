# Ensure Reverse Path Filtering is enabled
RF00327()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	SPN=net.ipv4.conf.all.rp_filter
	SPS=1
	SPF=net.ipv4.route.flush=1
	FSSCP
	SPN=net.ipv4.conf.default.rp_filter
	SPS=1
	SPF=net.ipv4.route.flush=1
	FSSCP
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure Reverse Path Filtering is enabled