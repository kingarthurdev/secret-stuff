# Ensure users' dot files are not group or world writable
RF00630()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	cat /etc/passwd | egrep -v '^(root|halt|sync|shutdown)' | awk -F: '($7 != "/usr/sbin/nologin" && $7 != "/bin/false") { print $1 " " $6 }' | while read USR UDIR
	do
		if [ ! -d "$UDIR" ]
		then
			WLOG "- $(date +%D-%H:%M:%S) - The home directory ($UDIR) of user $USR does not exist - $RN $RNA - ### Manual Remediation Required ###"
		else
			for SFN in $UDIR/.[A-Za-z0-9]*
			do
				if [[ -n $(ls -ld $SFN | cut -d' ' -f1 | egrep -i "^\s*-[-r][-w][-x][-r]--[-r]--\s*$") ]]
				then
					MLOG "- $(date +%D-%H:%M:%S) - User $USR file \"$SFN\" has permissions \"$(ls -ld $SFN | cut -d' ' -f1)\" - Skipping"
				else
					MLOG "- $(date +%D-%H:%M:%S) - User $USR file \"$SFN\" has permissions \"$(ls -ld $SFN | cut -d' ' -f1)\" - Remediating"
					chmod go-w $SFN
					if [[ -n $(ls -ld $SFN | cut -d' ' -f1 | egrep -i "^\s*-[-r][-w][-x][-r]--[-r]--\s*$") ]]
					then
						MLOG "- $(date +%D-%H:%M:%S) - Successful - User $USR file \"$SFN\" has permissions \"$(ls -ld $SFN | cut -d' ' -f1)\""
					else
						WLOG "- $(date +%D-%H:%M:%S) - Failed - User $USR file \"$SFN\" has permissions \"$(ls -ld $SFN | cut -d' ' -f1)\" - $RN $RNA - ### Manual Remediation Required ###"
					fi
				fi
			done
		fi
	done
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure users' dot files are not group or world writable