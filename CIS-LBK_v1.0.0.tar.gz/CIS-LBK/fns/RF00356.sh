# Ensure IPv6 loopback traffic is configured
RF00356()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	FIPV6S
	if [[ $V6S = disabled ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - IPv6 is $V6S - ip6tables not required - Skipping"
	else
		[[ -n $(ip6tables -L INPUT -v -n | egrep -i "^\s*0\s+0\s+ACCEPT\s+all\s+lo\s+\*\s+\:\:\/0\s+\:\:\/0\s*$") ]] && MLOG "- $(date +%D-%H:%M:%S) - INPUT ACCEPT configured - Skipping" || ip6tables -A INPUT -i lo -j ACCEPT
		[[ -n $(ip6tables -L INPUT -v -n | egrep -i "^\s*0\s+0\s+DROP\s+all\s+\*\s*\*\s+\:\:1\s+\:\:\/0\s*$") ]] && MLOG "- $(date +%D-%H:%M:%S) - INPUT DROP configured - Skipping" || ip6tables -A INPUT -s ::1 -j DROP
		[[ -n $(ip6tables -L OUTPUT -v -n | egrep -i "^\s*0\s+0\s+ACCEPT\s+all\s+\*\s+lo\s+\:\:\/0\s+\:\:\/0\s*$") ]] && MLOG "- $(date +%D-%H:%M:%S) - OUTPUT ACCEPT configured - Skipping" || ip6tables -A OUTPUT -o lo -j ACCEPT
		if [[ -n $(ip6tables -L INPUT -v -n | egrep -i "^\s*0\s+0\s+ACCEPT\s+all\s+lo\s+\*\s+\:\:\/0\s+\:\:\/0\s*$") ]] && [[ -n $(ip6tables -L INPUT -v -n | egrep -i "^\s*0\s+0\s+DROP\s+all\s+\*\s*\*\s+\:\:1\s+\:\:\/0\s*$") ]] && [[ -n $(ip6tables -L OUTPUT -v -n | egrep -i "^\s*0\s+0\s+ACCEPT\s+all\s+\*\s+lo\s+\:\:\/0\s+\:\:\/0\s*$") ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - Remediation Successful for $RN $RNA"
		else
			WLOG "- $(date +%D-%H:%M:%S) - Remediation Failed for $RN $RNA - ### Manual Remediation Required ###"
		fi
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure IPv6 loopback traffic is configured