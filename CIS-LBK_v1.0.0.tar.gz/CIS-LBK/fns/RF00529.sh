# Ensure SSH HostbasedAuthentication is disabled
RF00529()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	SPN=HostbasedAuthentication
	SPS=no
	FSSHS
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure SSH HostbasedAuthentication is disabled