# Ensure lockout for failed password attempts is configured
RF00542()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	SFN=/etc/pam.d/common-auth
	if [[ -n $(egrep -i "^\s*auth\s+required\s+pam_tally2.so\s+onerr=fail\s+audit\s+silent\s+deny=[1-5]\s+unlock_time=(900|[1-8][0-9][0-9]|[1-9][0-9]|[1-9])\s*(\s+#.*)?$" $SFN) ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - password creation requirements are configured - Skipping"
	else
		MLOG "- $(date +%D-%H:%M:%S) - password creation requirements are not configured - Remediating"
		FFBK
		if [[ -n $(egrep -i "^\s*auth\s+\S+\s+pam_tally2.so" $SFN) ]]
		then
			TST1=$(egrep -i "^\s*auth\s+\S+\s+pam_tally2\.so\s+.*(deny=)(\S+).*$" $SFN | sed -r "s/^\s*auth\s+\S+\s+pam_tally2\.so\s+.*(deny=)(\S+).*$/\2/")
			[[ -n $TST1 ]] && [[ $TST1 < 6 && $TST1 > 0 ]] && DVS=$TST1 || DVS=5
			TST2=$(egrep -i "^\s*auth\s+\S+\s+pam_tally2\.so\s+.*(unlock_time=)(\S+).*$" $SFN | sed -r "s/^\s*auth\s+\S+\s+pam_tally2\.so\s+.*(unlock_time=)(\S+).*$/\2/")
			[[ -n $TST2 ]] && [[ $TST2 < 901 && $TST2 > 0 ]] && UTS=$TST2 || UTS=900
			sed -ri "s/^\s*auth\s+\S+\s+pam_tally2\.so\b.*$/auth required pam_tally2.so onerr=fail audit silent deny=$DVS unlock_time=$UTS/" $SFN
#			sed -ri "s/^(\s*auth\s+)(required|\S*)(\s+pam_tally2.so\s+)(onerr=fail|\S+)(\s+audit|\S+)(\s+silent|\S+)(\s+deny=[1-5]|\S+)(\s+unlock_time=([1-9][0-9][0-9][0-9]|[9][0-9][0-9])\s*)(\s+#.*)?$/\1required\3onerr=fail audit silent deny=5 unlock_time=900\10/" $SFN
		else
	#		echo "auth required pam_tally2.so onerr=fail audit silent deny=5 unlock_time=900" >> $SFN
			sed -ri '$s/^/auth required pam_tally2.so onerr=fail audit silent deny=5 unlock_time=900\n/' $SFN
		fi
		if [[ -n $(egrep -i "^\s*auth\s+required\s+pam_tally2.so\s+onerr=fail\s+audit\s+silent\s+deny=[1-5]\s+unlock_time=(900|[1-8][0-9][0-9]|[1-9][0-9]|[1-9])\s*(\s+#.*)?$" $SFN) ]]
		then
			MLOG "- $(date +%D-%H:%M:%S) - Successful - password creation requirements are configured"
		else
			WLOG "- $(date +%D-%H:%M:%S) - Failed - password creation requirements are not configured - $RN $RNA - ### Manual Remediation Required ###"
		fi
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure lockout for failed password attempts is configured