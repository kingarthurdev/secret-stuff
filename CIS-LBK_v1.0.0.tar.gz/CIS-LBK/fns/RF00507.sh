# Ensure permissions on /etc/cron.d are configured
RF00507()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	SFN=/etc/cron.d
	FCCDP
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure permissions on /etc/cron.d are configured are configured