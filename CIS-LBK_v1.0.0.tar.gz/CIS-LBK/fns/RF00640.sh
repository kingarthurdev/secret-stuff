# Ensure shadow group is empty
RF00640()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	SGID=$(grep ^shadow: /etc/group | cut -d: -f3)
	if [[ -z $(egrep "^\s*\S+\:\S+\:\S+\:$SGID\:.*$" /etc/passwd) ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - shadow group is empty - Skipping"
	else
		for USR in $(egrep "^\s*\S+\:\S+\:\S+\:$SGID\:.*$" /etc/passwd)
		do
			MLOG "- $(date +%D-%H:%M:%S) - User $(echo $USR | cut -d: -f1) is in shodow group - locking user $(echo $USR | cut -d: -f1)"
			usermod -L $(echo $USR | cut -d: -f1)
			WLOG "- $(date +%D-%H:%M:%S) - User $(cut -d: -f1 $USR) is in shodow group - $RN $RNA - ### Manual Remediation Required"
		done
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure shadow group is empty