# Ensure IP forwarding is disabled
RF00301()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	SPN=net.ipv4.ip_forward
	SPS=0
	SPF=net.ipv4.route.flush=1
	FSSCP
	SPN=net.ipv6.conf.all.forwarding
	SPS=0
	SPF=net.ipv6.route.flush=1
	FSSCP
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure IP forwarding is disabled