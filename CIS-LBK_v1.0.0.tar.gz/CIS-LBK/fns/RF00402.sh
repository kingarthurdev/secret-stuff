# Ensure system is disabled when audit logs are full
RF00402()
{
	SFN=/etc/audit/auditd.conf
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	if [[ -n `egrep -i "^\s*space_left_action\s*\=\s*email\b.*$" $SFN` ]] && [[ -n `egrep -i "^\s*action_mail_account\s*\=\s*root\b.*$" $SFN` ]] && [[ -n `egrep -i "^\s*admin_space_left_action\s*\=\s*halt\b.*$" $SFN` ]]
	then
		MLOG "- $(date +%D-%H:%M:%S) - $RNA already configured - Skipping"
	else
		APN=space_left_action
		APS=email
		FSACFP
		APN=action_mail_acct
		APS=root
		FSACFP
		APN=admin_space_left_action
		APS=halt
		FSACFP
	fi
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure system is disabled when audit logs are full