# Ensure SELinux or AppArmor are installed
RF00167()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	MACTPE # Function to ensure that the MACDEC variable is set
	case $MACDEC in
		SEL )
			MLOG "- $(date +%D-%H:%M:%S) - SELinux is installed"
			;;
		APAR )
			MLOG "- $(date +%D-%H:%M:%S) - AppArmor is installed"
			;;
		NONE )
			WLOG "- $(date +%D-%H:%M:%S) - You have chosen not to install a MAC or instalation of a MAC has failed - ### Manual Remediation Required ###"
			;;
		* )
			WLOG "- $(date +%D-%H:%M:%S) - instalation of a MAC has failed - ### Manual Remediation Required"
	esac
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure SELinux or AppArmor are installed