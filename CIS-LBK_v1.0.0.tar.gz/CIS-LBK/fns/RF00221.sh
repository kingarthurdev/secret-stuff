# Ensure NIS Server is not enabled
RF00221()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	DAEN=rsync
	FTDSD
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure NIS Server is not enabled