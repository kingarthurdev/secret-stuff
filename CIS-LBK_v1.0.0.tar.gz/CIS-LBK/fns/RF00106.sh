# Ensure separate partition exists for /var
RF00106()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	MPN="/var"
	PECK
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure separate partition exists for /var