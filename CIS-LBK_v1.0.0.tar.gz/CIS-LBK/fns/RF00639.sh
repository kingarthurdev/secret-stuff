# Ensure no duplicate group names exist
RF00639()
{
	MLOG "- $(date +%D-%H:%M:%S) - Starting - $RN $RNA"
	cat /etc/group | cut -f1 -d":" | sort -n | uniq -c | while read x
	do
		[ -z "${x}" ] && break
		set - $x
		if [ $1 -gt 1 ]
		then
			GIDS=$(gawk -F: '($1 == n) { print $3 }' n=$2 /etc/group | xargs)
			WLOG "Duplicate Group Name ($2): ${GIDS} - $RN $RNA - ### Manual Remediation Required ###"
		fi
	done
	MLOG "- $(date +%D-%H:%M:%S) - Completed - $RN $RNA"
}
# End of Ensure no duplicate group names exist